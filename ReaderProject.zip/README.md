# Reader

PDF reader with real page-curl animation. Native Android (Kotlin + Jetpack Compose).

- Min Android 7.0 (API 24)
- Build: GitHub Actions (see .github/workflows/build.yml in your repo)
- In-app updates: the app checks the latest GitHub Release of the repo that built it.
