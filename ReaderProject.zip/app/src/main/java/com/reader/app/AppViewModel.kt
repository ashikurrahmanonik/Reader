package com.reader.app

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.reader.app.data.BookRow
import com.reader.app.data.HistoryEntry
import com.reader.app.data.PdfItem
import com.reader.app.data.ReaderTarget
import com.reader.app.data.Storage
import com.reader.app.data.Store
import com.reader.app.data.UpdateInfo
import com.reader.app.data.Updater
import com.reader.app.pdf.PdfDoc
import com.reader.app.ui.Str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface UpdateState {
    data object Idle : UpdateState
    data object Checking : UpdateState
    data object UpToDate : UpdateState
    data class Available(val info: UpdateInfo) : UpdateState
    data class Downloading(val info: UpdateInfo, val progress: Float) : UpdateState
    data class Ready(val info: UpdateInfo, val path: String) : UpdateState
    data class Failed(val message: String) : UpdateState
}

class AppViewModel(private val app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var files by mutableStateOf<List<PdfItem>>(emptyList())
        private set
    var scanning by mutableStateOf(false)
        private set
    var hasAccess by mutableStateOf(Storage.hasAccess(app))
        private set
    var history by mutableStateOf(store.loadHistory())
        private set
    var favorites by mutableStateOf(store.loadFavorites())
        private set

    var readerTheme by mutableIntStateOf(store.readerTheme)
        private set
    var autoUpdate by mutableStateOf(store.autoUpdate)
        private set
    var lang by mutableStateOf(store.lang)
        private set
    var curl by mutableStateOf(store.curl)
        private set
    var fontSize by mutableIntStateOf(store.fontSize)
        private set
    var serif by mutableStateOf(store.serif)
        private set
    var brightness by mutableFloatStateOf(store.brightness)
        private set

    var reader by mutableStateOf<ReaderTarget?>(null)
        private set

    var update by mutableStateOf<UpdateState>(UpdateState.Idle)
        private set
    var showUpdateDialog by mutableStateOf(false)

    private fun s() = Str(lang == "bn")

    init {
        PdfDoc.clearTempCopies(app)
        if (hasAccess) scan()
        if (autoUpdate) checkUpdate(manual = false)
    }

    // ---------- storage / scanning ----------

    fun onResume() {
        val now = Storage.hasAccess(app)
        if (now != hasAccess) hasAccess = now
        if (now && files.isEmpty() && !scanning) scan()
    }

    fun scan() {
        if (scanning) return
        scanning = true
        viewModelScope.launch {
            val list = try {
                withContext(Dispatchers.IO) { Storage.scanBooks() }
            } catch (e: Throwable) {
                emptyList()
            }
            files = list
            scanning = false
        }
    }

    // ---------- opening ----------

    fun openPath(path: String) {
        val f = File(path)
        if (!f.exists()) {
            toast(s().toastNotFound)
            return
        }
        val h = history.firstOrNull { it.path == path }
        reader = ReaderTarget(path, f.name, h?.lastPage ?: 0, h?.extra ?: -1L)
    }

    fun openUri(uri: Uri) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { importUri(uri) }
            if (path == null) toast(s().toastCantOpen) else openPath(path)
        }
    }

    private fun importUri(uri: Uri): String? {
        return try {
            if (uri.scheme == "file") {
                val p = uri.path
                return if (p != null && File(p).exists()) p else null
            }
            var display = "document"
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) display = n
                    }
                }
            display = display.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val isEpub = display.endsWith(".epub", ignoreCase = true) ||
                app.contentResolver.getType(uri) == "application/epub+zip"
            if (!display.endsWith(".pdf", ignoreCase = true) && !display.endsWith(".epub", ignoreCase = true)) {
                display += if (isEpub) ".epub" else ".pdf"
            }
            val dir = File(app.filesDir, "imported/${uri.toString().hashCode().toUInt()}")
            dir.mkdirs()
            val dest = File(dir, display)
            app.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { out -> input.copyTo(out) }
            } ?: return null
            dest.absolutePath
        } catch (e: Throwable) {
            null
        }
    }

    fun closeReader() {
        reader = null
    }

    // ---------- history / favorites ----------

    fun recordProgress(path: String, name: String, page: Int, count: Int, extra: Long) {
        val entry = HistoryEntry(path, name, page, count, System.currentTimeMillis(), extra)
        history = (listOf(entry) + history.filter { it.path != path }).take(100)
        store.saveHistory(history)
    }

    fun removeFromHistory(path: String) {
        history = history.filter { it.path != path }
        store.saveHistory(history)
    }

    fun toggleFavorite(path: String) {
        favorites = if (path in favorites) favorites - path else favorites + path
        store.saveFavorites(favorites)
    }

    // ---------- settings ----------

    fun changeReaderTheme(t: Int) {
        readerTheme = t
        store.readerTheme = t
    }

    fun cycleReaderTheme() = changeReaderTheme((readerTheme + 1) % 3)

    fun changeAutoUpdate(v: Boolean) {
        autoUpdate = v
        store.autoUpdate = v
    }

    fun changeLang(v: String) {
        lang = v
        store.lang = v
    }

    fun toggleLang() = changeLang(if (lang == "bn") "en" else "bn")

    fun changeCurl(v: Boolean) {
        curl = v
        store.curl = v
    }

    fun changeFontSize(v: Int) {
        fontSize = v.coerceIn(12, 32)
        store.fontSize = fontSize
    }

    fun changeSerif(v: Boolean) {
        serif = v
        store.serif = v
    }

    fun changeBrightness(v: Float) {
        brightness = v
        store.brightness = v
    }

    /** tab: 0 library, 1 recent, 2 favorites. sort: 0 newest, 1 name, 2 size */
    fun rowsFor(tab: Int, query: String, sort: Int): List<BookRow> {
        val hist = history.associateBy { it.path }
        val favs = favorites
        val base: List<BookRow> = when (tab) {
            1 -> history.mapNotNull { h ->
                val f = File(h.path)
                if (!f.exists()) null
                else BookRow(h.path, f.name, f.length(), f.lastModified(), h.lastPage, h.pageCount, h.path in favs)
            }
            2 -> favs.mapNotNull { p ->
                val f = File(p)
                if (!f.exists()) null
                else {
                    val h = hist[p]
                    BookRow(p, f.name, f.length(), f.lastModified(), h?.lastPage ?: 0, h?.pageCount ?: 0, true)
                }
            }
            else -> files.map { f ->
                val h = hist[f.path]
                BookRow(f.path, f.name, f.size, f.modified, h?.lastPage ?: 0, h?.pageCount ?: 0, f.path in favs)
            }
        }
        val q = query.trim()
        val filtered = if (q.isEmpty()) base else base.filter { it.name.contains(q, ignoreCase = true) }
        return when {
            tab == 1 -> filtered
            sort == 1 -> filtered.sortedBy { it.name.lowercase() }
            sort == 2 -> filtered.sortedByDescending { it.size }
            else -> filtered.sortedByDescending { it.modified }
        }
    }

    // ---------- updates ----------

    fun checkUpdate(manual: Boolean) {
        if (update is UpdateState.Checking || update is UpdateState.Downloading) return
        update = UpdateState.Checking
        viewModelScope.launch {
            try {
                val latest = Updater.fetchLatest()
                if (latest != null && latest.code > BuildConfig.VERSION_CODE) {
                    update = UpdateState.Available(latest)
                    showUpdateDialog = true
                } else {
                    update = UpdateState.UpToDate
                }
            } catch (e: Throwable) {
                update = if (manual) UpdateState.Failed(e.message ?: "Couldn't check for updates")
                else UpdateState.Idle
            }
        }
    }

    fun downloadUpdate(info: UpdateInfo) {
        update = UpdateState.Downloading(info, 0f)
        showUpdateDialog = true
        viewModelScope.launch {
            try {
                val file = Updater.download(app, info) { p ->
                    update = UpdateState.Downloading(info, p)
                }
                update = UpdateState.Ready(info, file.absolutePath)
                installUpdate()
            } catch (e: Throwable) {
                update = UpdateState.Failed(e.message ?: "Download failed")
            }
        }
    }

    fun installUpdate() {
        val u = update
        if (u is UpdateState.Ready) {
            val ok = try {
                Updater.install(app, File(u.path))
            } catch (e: Throwable) {
                toast(s().toastInstallFail)
                true
            }
            if (!ok) toast(s().toastAllowInstall)
        }
    }

    fun dismissUpdateDialog() {
        showUpdateDialog = false
    }

    private fun toast(msg: String) {
        Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
    }
}
