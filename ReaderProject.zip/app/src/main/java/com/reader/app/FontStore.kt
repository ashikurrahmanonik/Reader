package com.reader.app

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import java.io.File

class FontInfo(val family: String, val file: File)

/**
 * Fonts imported by the user (SutonnyMJ, Nikosh, Kalpurush ...) live in the app's private storage,
 * so Word documents that name those fonts can be shown the way they look on a computer.
 */
object FontStore {
    private val faces = LinkedHashMap<String, Typeface>()
    private var infos: List<FontInfo> = emptyList()
    private val legacyBangla = Regex("(?i)(.*mj$|.*sutonny.*|.*bijoy.*|.*adorsho.*)")

    private fun dir(ctx: Context) = File(ctx.filesDir, "fonts").apply { mkdirs() }

    fun norm(s: String): String {
        var n = s.lowercase().filter { it.isLetterOrDigit() }
        for (suf in listOf("regular", "normal", "bold", "italic")) {
            if (n.endsWith(suf) && n.length > suf.length + 2) n = n.removeSuffix(suf)
        }
        return n
    }

    @Synchronized
    fun load(ctx: Context) {
        val map = LinkedHashMap<String, Typeface>()
        val list = ArrayList<FontInfo>()
        val files = dir(ctx).listFiles() ?: emptyArray()
        for (f in files.sortedBy { it.name.lowercase() }) {
            val ext = f.extension.lowercase()
            if (ext != "ttf" && ext != "otf") continue
            val tf = try {
                Typeface.createFromFile(f)
            } catch (e: Throwable) {
                null
            } ?: continue
            val family = readFamilyName(f) ?: f.nameWithoutExtension
            map[norm(f.nameWithoutExtension)] = tf
            map[norm(family)] = tf
            list.add(FontInfo(family, f))
        }
        faces.clear()
        faces.putAll(map)
        infos = list
    }

    @Synchronized
    fun list(): List<FontInfo> = infos

    /** null = use the reader's default font. */
    @Synchronized
    fun find(name: String?): Typeface? {
        if (name.isNullOrBlank()) return null
        val n = norm(name)
        faces[n]?.let { return it }
        if (n.length >= 4) {
            for ((k, v) in faces) if (k.startsWith(n) || n.startsWith(k)) return v
        }
        val l = name.lowercase()
        return when {
            l.contains("times") || l.contains("georgia") || l.contains("cambria") ||
                l.contains("garamond") || l.contains("palatino") || l.contains("serif") && !l.contains("sans") -> Typeface.SERIF
            l.contains("courier") || l.contains("consolas") || l.contains("mono") -> Typeface.MONOSPACE
            else -> null
        }
    }

    /** True for old "ASCII-hack" Bangla fonts, whose text is unreadable without the font itself. */
    @Synchronized
    fun isMissingLegacy(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        if (!legacyBangla.matches(name.trim())) return false
        val n = norm(name)
        if (faces.containsKey(n)) return false
        for (k in faces.keys) if (k.startsWith(n) || n.startsWith(k)) return false
        return true
    }

    /** Copies picked font files into private storage. Returns how many were added. */
    fun import(ctx: Context, uris: List<Uri>): Int {
        var added = 0
        for (u in uris) {
            try {
                var name = "font.ttf"
                ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) name = n
                    }
                }
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext != "ttf" && ext != "otf") continue
                val dest = File(dir(ctx), name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                ctx.contentResolver.openInputStream(u)?.use { input ->
                    dest.outputStream().use { out -> input.copyTo(out) }
                    added++
                }
            } catch (_: Throwable) {
            }
        }
        if (added > 0) load(ctx)
        return added
    }

    /** Fonts dropped into  <storage>/Reader/Fonts  are picked up automatically. */
    fun syncFromFolder(ctx: Context): Int {
        var added = 0
        try {
            val src = File(Environment.getExternalStorageDirectory(), "Reader/Fonts")
            val files = src.listFiles() ?: return 0
            for (f in files) {
                val ext = f.extension.lowercase()
                if (ext != "ttf" && ext != "otf") continue
                val dest = File(dir(ctx), f.name)
                if (!dest.exists() || dest.length() != f.length()) {
                    f.copyTo(dest, overwrite = true)
                    added++
                }
            }
        } catch (_: Throwable) {
        }
        if (added > 0) load(ctx)
        return added
    }

    fun delete(ctx: Context, info: FontInfo) {
        try {
            info.file.delete()
        } catch (_: Throwable) {
        }
        load(ctx)
    }

    /** Reads the family name (name id 1 / 16) from the font's 'name' table. */
    private fun readFamilyName(f: File): String? {
        return try {
            val b = f.readBytes()
            fun u16(o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
            fun u32(o: Int) = (u16(o).toLong() shl 16) or u16(o + 2).toLong()
            val numTables = u16(4)
            var nameOff = -1
            for (i in 0 until numTables) {
                val rec = 12 + i * 16
                val tag = String(b, rec, 4, Charsets.ISO_8859_1)
                if (tag == "name") {
                    nameOff = u32(rec + 8).toInt()
                    break
                }
            }
            if (nameOff < 0) return null
            val count = u16(nameOff + 2)
            val strOff = nameOff + u16(nameOff + 4)
            var best: String? = null
            for (i in 0 until count) {
                val r = nameOff + 6 + i * 12
                val platform = u16(r)
                val nameId = u16(r + 6)
                val len = u16(r + 8)
                val off = u16(r + 10)
                if (nameId != 1 && nameId != 16) continue
                val s = if (platform == 3 || platform == 0) {
                    String(b, strOff + off, len, Charsets.UTF_16BE)
                } else {
                    String(b, strOff + off, len, Charsets.ISO_8859_1)
                }
                if (s.isNotBlank()) {
                    if (nameId == 16 || best == null) best = s.trim()
                }
            }
            best
        } catch (e: Throwable) {
            null
        }
    }
}
