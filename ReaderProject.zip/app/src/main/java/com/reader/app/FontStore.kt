package com.reader.app

import android.content.Context
import android.content.res.AssetManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import java.io.File

class FontInfo(val family: String, val file: File)

/**
 * Fonts imported by the user (SutonnyMJ, Nikosh, Kalpurush ...) live in the app's private storage,
 * so Word documents that name those fonts can be shown the way they look on a computer.
 */
object FontStore {
    private val faces = LinkedHashMap<String, Typeface>()
    private var infos: List<FontInfo> = emptyList()
    private val legacyBangla = Regex("(?i)(.*mj$|.*sutonny.*|.*bijoy.*|.*adorsho.*)")

    // ---- bundled, metric-compatible fonts (Calibri -> Carlito, Arial -> Liberation Sans, ...) ----
    private var assets: AssetManager? = null
    private val bundled = HashMap<String, Array<Typeface?>>()
    private val alias: Map<String, String> = HashMap<String, String>().apply {
        for (n in listOf("calibri", "calibrilight", "carlito")) put(n, "Carlito")
        for (n in listOf(
            "arial", "arialnarrow", "arialunicodems", "arialblack", "helvetica", "verdana", "tahoma", "trebuchetms",
            "segoeui", "liberationsans", "lucidasans", "microsoftsansserif", "candara", "corbel", "gillsans",
            "centurygothic", "franklingothic", "franklingothicbook", "sansserif"
        )) put(n, "LiberationSans")
        for (n in listOf(
            "timesnewroman", "times", "georgia", "bookantiqua", "palatinolinotype", "garamond", "centuryschoolbook",
            "liberationserif", "bookmanoldstyle", "constantia", "mstimes", "serif"
        )) put(n, "LiberationSerif")
        for (n in listOf("cambria", "caladea", "cambriamath")) put(n, "Caladea")
        for (n in listOf("couriernew", "courier", "consolas", "lucidaconsole", "liberationmono", "monaco", "andalemono", "monospace")) put(n, "LiberationMono")
    }
    private val unicodeBangla = Regex("(?i).*(nikosh|kalpurush|solaiman|siyam|rupali|vrinda|mukti|shonar|lohit|akaash|noto.*bengali).*")

    private fun dir(ctx: Context) = File(ctx.filesDir, "fonts").apply { mkdirs() }

    fun norm(s: String): String {
        var n = s.lowercase().filter { it.isLetterOrDigit() }
        for (suf in listOf("regular", "normal", "bold", "italic")) {
            if (n.endsWith(suf) && n.length > suf.length + 2) n = n.removeSuffix(suf)
        }
        return n
    }

    @Synchronized
    fun load(ctx: Context) {
        assets = ctx.applicationContext.assets
        val map = LinkedHashMap<String, Typeface>()
        val list = ArrayList<FontInfo>()
        val files = dir(ctx).listFiles() ?: emptyArray()
        for (f in files.sortedBy { it.name.lowercase() }) {
            val ext = f.extension.lowercase()
            if (ext != "ttf" && ext != "otf") continue
            val tf = try {
                Typeface.createFromFile(f)
            } catch (e: Throwable) {
                null
            } ?: continue
            val family = readFamilyName(f) ?: f.nameWithoutExtension
            map[norm(f.nameWithoutExtension)] = tf
            map[norm(family)] = tf
            list.add(FontInfo(family, f))
        }
        faces.clear()
        faces.putAll(map)
        infos = list
    }

    @Synchronized
    fun list(): List<FontInfo> = infos

    private fun bundledFace(family: String, bold: Boolean, italic: Boolean): Typeface? {
        val am = assets ?: return null
        val arr = bundled.getOrPut(family) { arrayOfNulls(4) }
        val idx = (if (bold) 1 else 0) + (if (italic) 2 else 0)
        if (arr[idx] == null) {
            val suffix = when (idx) {
                0 -> "Regular"
                1 -> "Bold"
                2 -> "Italic"
                else -> "BoldItalic"
            }
            arr[idx] = try {
                Typeface.createFromAsset(am, "fonts/$family-$suffix.ttf")
            } catch (e: Throwable) {
                null
            }
        }
        return arr[idx] ?: arr[0]
    }

    /**
     * The best typeface for a font name used in a document: imported font > bundled look-alike
     * (Calibri -> Carlito ...) > system font. Never null.
     */
    @Synchronized
    fun face(name: String?, bold: Boolean, italic: Boolean, defaultFamily: String = "Carlito"): Typeface {
        val style = (if (bold) Typeface.BOLD else 0) or (if (italic) Typeface.ITALIC else 0)
        if (!name.isNullOrBlank()) {
            val n = norm(name)
            val user = lookup(n)
            if (user != null) return Typeface.create(user, style)
            val fam = alias[n]
            if (fam != null) bundledFace(fam, bold, italic)?.let { return it }
            if (unicodeBangla.matches(name)) return Typeface.create(Typeface.SANS_SERIF, style)
            if (legacyBangla.matches(name.trim())) return Typeface.create(Typeface.DEFAULT, style)
        }
        return bundledFace(defaultFamily, bold, italic) ?: Typeface.create(Typeface.DEFAULT, style)
    }

    /** exact match first, then the closest name (shortest difference) instead of "whatever comes first". */
    private fun lookup(n: String): Typeface? {
        faces[n]?.let { return it }
        if (n.length < 4) return null
        var best: Typeface? = null
        var bestDiff = Int.MAX_VALUE
        for ((k, v) in faces) {
            if (k.startsWith(n) || n.startsWith(k)) {
                val d = kotlin.math.abs(k.length - n.length)
                if (d < bestDiff) {
                    bestDiff = d
                    best = v
                }
            }
        }
        return best
    }

    /** null = use the reader's default font. */
    @Synchronized
    fun find(name: String?): Typeface? {
        if (name.isNullOrBlank()) return null
        val n = norm(name)
        lookup(n)?.let { return it }
        val l = name.lowercase()
        return when {
            l.contains("times") || l.contains("georgia") || l.contains("cambria") ||
                l.contains("garamond") || l.contains("palatino") || l.contains("serif") && !l.contains("sans") -> Typeface.SERIF
            l.contains("courier") || l.contains("consolas") || l.contains("mono") -> Typeface.MONOSPACE
            else -> null
        }
    }

    /** True for old "ASCII-hack" Bangla fonts, whose text is unreadable without the font itself. */
    @Synchronized
    fun isMissingLegacy(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        if (!legacyBangla.matches(name.trim())) return false
        return lookup(norm(name)) == null
    }

    /** Copies picked font files into private storage. Returns how many were added. */
    fun import(ctx: Context, uris: List<Uri>): Int {
        var added = 0
        for (u in uris) {
            try {
                var name = "font.ttf"
                ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) name = n
                    }
                }
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext != "ttf" && ext != "otf") continue
                val dest = File(dir(ctx), name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                run {
                    val p = prefs(ctx)
                    val set = HashSet(p.getStringSet("ignored", emptySet()) ?: emptySet())
                    if (set.removeAll { it.startsWith(dest.name + "|") }) p.edit().putStringSet("ignored", set).apply()
                }
                ctx.contentResolver.openInputStream(u)?.use { input ->
                    dest.outputStream().use { out -> input.copyTo(out) }
                    added++
                }
            } catch (_: Throwable) {
            }
        }
        if (added > 0) load(ctx)
        return added
    }

    fun fontsFolder(): File = File(Environment.getExternalStorageDirectory(), "Reader/Fonts")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("reader_fonts", Context.MODE_PRIVATE)
    private fun ignoreKey(name: String, len: Long) = "$name|$len"

    /**
     * Makes sure  <storage>/Reader/Fonts  really exists (and is visible in file managers),
     * so the user has somewhere to copy font files into.
     */
    fun ensureFolder(ctx: Context) {
        try {
            val d = fontsFolder()
            var fresh = false
            if (!d.exists()) fresh = d.mkdirs()
            if (!d.isDirectory) return
            val note = File(d, "PUT FONTS HERE.txt")
            if (!note.exists()) {
                note.writeText("Copy .ttf / .otf font files (SutonnyMJ, Nikosh, Kalpurush ...) into this folder.\nOpen Reader and they are added automatically.\n")
                fresh = true
            }
            // tell the media index once, so the folder shows up in other file managers / over USB
            if (fresh) {
                android.media.MediaScannerConnection.scanFile(
                    ctx.applicationContext, arrayOf(d.absolutePath, note.absolutePath), null, null
                )
            }
        } catch (_: Throwable) {
        }
    }

    /** Fonts dropped into  <storage>/Reader/Fonts  are picked up automatically. */
    fun syncFromFolder(ctx: Context): Int {
        var added = 0
        try {
            val src = fontsFolder()
            val files = src.listFiles() ?: return 0
            val ignored = prefs(ctx).getStringSet("ignored", emptySet()) ?: emptySet()
            for (f in files) {
                val ext = f.extension.lowercase()
                if (ext != "ttf" && ext != "otf") continue
                // a font the user removed inside the app must not come back by itself
                if (ignoreKey(f.name, f.length()) in ignored) continue
                val dest = File(dir(ctx), f.name)
                if (!dest.exists() || dest.length() != f.length()) {
                    f.copyTo(dest, overwrite = true)
                    added++
                }
            }
        } catch (_: Throwable) {
        }
        if (added > 0) load(ctx)
        return added
    }

    fun delete(ctx: Context, info: FontInfo) {
        try {
            // remember it, so the copy in Reader/Fonts is not imported again at the next start
            val inFolder = File(fontsFolder(), info.file.name)
            if (inFolder.exists()) {
                val p = prefs(ctx)
                val set = HashSet(p.getStringSet("ignored", emptySet()) ?: emptySet())
                set.add(ignoreKey(inFolder.name, inFolder.length()))
                p.edit().putStringSet("ignored", set).apply()
            }
            info.file.delete()
        } catch (_: Throwable) {
        }
        load(ctx)
    }

    /** Reads the family name (name id 1 / 16) from the font's 'name' table. */
    private fun readFamilyName(f: File): String? {
        return try {
            val b = f.readBytes()
            fun u16(o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
            fun u32(o: Int) = (u16(o).toLong() shl 16) or u16(o + 2).toLong()
            val numTables = u16(4)
            var nameOff = -1
            for (i in 0 until numTables) {
                val rec = 12 + i * 16
                val tag = String(b, rec, 4, Charsets.ISO_8859_1)
                if (tag == "name") {
                    nameOff = u32(rec + 8).toInt()
                    break
                }
            }
            if (nameOff < 0) return null
            val count = u16(nameOff + 2)
            val strOff = nameOff + u16(nameOff + 4)
            var best: String? = null
            for (i in 0 until count) {
                val r = nameOff + 6 + i * 12
                val platform = u16(r)
                val nameId = u16(r + 6)
                val len = u16(r + 8)
                val off = u16(r + 10)
                if (nameId != 1 && nameId != 16) continue
                val s = if (platform == 3 || platform == 0) {
                    String(b, strOff + off, len, Charsets.UTF_16BE)
                } else {
                    String(b, strOff + off, len, Charsets.ISO_8859_1)
                }
                if (s.isNotBlank()) {
                    if (nameId == 16 || best == null) best = s.trim()
                }
            }
            best
        } catch (e: Throwable) {
            null
        }
    }
}
