package com.reader.app.data

enum class Kind { PDF, EPUB, DOCX, XLSX, PPTX, TXT, CSV }

fun kindOf(path: String): Kind {
    val p = path.lowercase()
    return when {
        p.endsWith(".epub") -> Kind.EPUB
        p.endsWith(".docx") -> Kind.DOCX
        p.endsWith(".xlsx") || p.endsWith(".xlsm") -> Kind.XLSX
        p.endsWith(".pptx") -> Kind.PPTX
        p.endsWith(".txt") -> Kind.TXT
        p.endsWith(".csv") -> Kind.CSV
        else -> Kind.PDF
    }
}

val BOOK_EXT_REGEX = Regex("\\.(pdf|epub|docx|xlsx|xlsm|pptx|txt|csv)$", RegexOption.IGNORE_CASE)

fun isEpubPath(path: String): Boolean = kindOf(path) == Kind.EPUB

data class PdfItem(
    val path: String,
    val name: String,
    val size: Long,
    val modified: Long,
    /** content fingerprint (only computed for files that share their size with another file); 0 = unknown */
    val hash: Long = 0L
)

data class HistoryEntry(
    val path: String,
    val name: String,
    val lastPage: Int,
    val pageCount: Int,
    val lastOpened: Long,
    val extra: Long = -1L
)

data class ReaderTarget(
    val path: String,
    val name: String,
    val startPage: Int,
    val extra: Long = -1L
)

data class BookRow(
    val path: String,
    val name: String,
    val size: Long,
    val modified: Long,
    val page: Int,
    val pages: Int,
    val fav: Boolean,
    val copies: Int = 0
) {
    val kind: Kind get() = kindOf(path)
    val isPdf: Boolean get() = kind == Kind.PDF
}

// bottom navigation tabs
const val TAB_LIBRARY = 0
const val TAB_FILES = 1
const val TAB_RECENT = 2
const val TAB_FAV = 3
const val TAB_SETTINGS = 4

/** One row of the file manager. */
data class FmEntry(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val children: Int
)

/** Copy / move clipboard of the file manager. */
data class FmClip(val paths: List<String>, val move: Boolean)
