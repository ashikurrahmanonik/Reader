package com.reader.app.data

data class PdfItem(val path: String, val name: String, val size: Long, val modified: Long)

data class HistoryEntry(
    val path: String,
    val name: String,
    val lastPage: Int,
    val pageCount: Int,
    val lastOpened: Long,
    val extra: Long = -1L
)

data class ReaderTarget(
    val path: String,
    val name: String,
    val startPage: Int,
    val extra: Long = -1L
)

data class BookRow(
    val path: String,
    val name: String,
    val size: Long,
    val modified: Long,
    val page: Int,
    val pages: Int,
    val fav: Boolean
) {
    val isEpub: Boolean get() = isEpubPath(path)
}

fun isEpubPath(path: String): Boolean = path.endsWith(".epub", ignoreCase = true)
