package com.reader.app.data

data class PdfItem(val path: String, val name: String, val size: Long, val modified: Long)

data class HistoryEntry(
    val path: String,
    val name: String,
    val lastPage: Int,
    val pageCount: Int,
    val lastOpened: Long
)

data class ReaderTarget(val path: String, val name: String, val startPage: Int)

data class BookRow(
    val path: String,
    val name: String,
    val size: Long,
    val modified: Long,
    val page: Int,
    val pages: Int,
    val fav: Boolean
)
