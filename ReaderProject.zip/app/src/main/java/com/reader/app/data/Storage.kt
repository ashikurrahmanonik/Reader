package com.reader.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File

object Storage {
    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

    /** Walks the whole shared storage and collects every .pdf file. */
    fun scanPdfs(): List<PdfItem> {
        val root = Environment.getExternalStorageDirectory()
        val out = ArrayList<PdfItem>()
        val stack = ArrayList<File>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val dir = stack.removeAt(stack.size - 1)
            val children = dir.listFiles() ?: continue
            for (f in children) {
                if (f.isDirectory) {
                    val n = f.name
                    if (n.startsWith(".")) continue
                    val p = f.absolutePath
                    if (p.endsWith("/Android/data") || p.endsWith("/Android/obb")) continue
                    stack.add(f)
                } else if (f.name.endsWith(".pdf", ignoreCase = true)) {
                    out.add(PdfItem(f.absolutePath, f.name, f.length(), f.lastModified()))
                }
            }
        }
        return out
    }
}
