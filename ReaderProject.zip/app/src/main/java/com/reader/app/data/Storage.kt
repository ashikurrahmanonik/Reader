package com.reader.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.CRC32

object Storage {
    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

    private val SCAN_EXT = listOf(".pdf", ".epub", ".docx", ".xlsx", ".xlsm", ".pptx", ".csv", ".txt", ".doc")

    /** Walks the whole shared storage and collects every book / document. */
    fun scanBooks(): List<PdfItem> {
        val root = Environment.getExternalStorageDirectory()
        val out = ArrayList<PdfItem>()
        val stack = ArrayList<File>()
        val seenDirs = HashSet<String>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val dir = stack.removeAt(stack.size - 1)
            val canon = try {
                dir.canonicalPath
            } catch (e: Throwable) {
                dir.absolutePath
            }
            if (!seenDirs.add(canon)) continue
            val children = dir.listFiles() ?: continue
            for (f in children) {
                if (f.isDirectory) {
                    val n = f.name
                    if (n.startsWith(".")) continue
                    val p = f.absolutePath
                    if (p.endsWith("/Android/data") || p.endsWith("/Android/obb")) continue
                    stack.add(f)
                } else {
                    val lower = f.name.lowercase()
                    if (SCAN_EXT.any { lower.endsWith(it) } && !lower.startsWith("~$") && f.length() > 0L && f.name != "PUT FONTS HERE.txt") {
                        out.add(PdfItem(f.absolutePath, f.name, f.length(), f.lastModified()))
                    }
                }
            }
        }
        // fingerprint only files that share a size with another file
        val bySize = out.groupBy { it.size }
        val result = ArrayList<PdfItem>(out.size)
        for (item in out) {
            val group = bySize[item.size]
            if (group != null && group.size > 1 && item.size > 0) {
                result.add(item.copy(hash = fingerprint(File(item.path))))
            } else {
                result.add(item)
            }
        }
        return result
    }

    /** CRC of the first and last 64 KB plus the length. Cheap, and plenty to spot identical copies. */
    private fun fingerprint(f: File): Long {
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val len = raf.length()
                val crc = CRC32()
                val buf = ByteArray(64 * 1024)
                val n1 = raf.read(buf)
                if (n1 > 0) crc.update(buf, 0, n1)
                if (len > buf.size * 2L) {
                    raf.seek(len - buf.size)
                    val n2 = raf.read(buf)
                    if (n2 > 0) crc.update(buf, 0, n2)
                }
                crc.value xor (len shl 20) or 1L
            }
        } catch (e: Throwable) {
            0L
        }
    }
}
