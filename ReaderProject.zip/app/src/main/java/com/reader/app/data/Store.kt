package com.reader.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)

    fun loadHistory(): List<HistoryEntry> {
        val raw = sp.getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<HistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryEntry(
                        path = o.getString("path"),
                        name = o.optString("name"),
                        lastPage = o.optInt("page"),
                        pageCount = o.optInt("count"),
                        lastOpened = o.optLong("t"),
                        extra = o.optLong("x", -1L)
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveHistory(list: List<HistoryEntry>) {
        val arr = JSONArray()
        for (h in list) {
            val o = JSONObject()
            o.put("path", h.path)
            o.put("name", h.name)
            o.put("page", h.lastPage)
            o.put("count", h.pageCount)
            o.put("t", h.lastOpened)
            o.put("x", h.extra)
            arr.put(o)
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun loadFavorites(): Set<String> =
        sp.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(set: Set<String>) {
        sp.edit().putStringSet("favorites", HashSet(set)).apply()
    }

    var readerTheme: Int
        get() = sp.getInt("reader_theme", 0)
        set(v) {
            sp.edit().putInt("reader_theme", v).apply()
        }

    var autoUpdate: Boolean
        get() = sp.getBoolean("auto_update", true)
        set(v) {
            sp.edit().putBoolean("auto_update", v).apply()
        }

    var lang: String
        get() = sp.getString("lang", null)
            ?: if (Locale.getDefault().language == "bn") "bn" else "en"
        set(v) {
            sp.edit().putString("lang", v).apply()
        }

    var curl: Boolean
        get() = sp.getBoolean("curl", true)
        set(v) {
            sp.edit().putBoolean("curl", v).apply()
        }

    var fontSize: Int
        get() = sp.getInt("font_size", 18)
        set(v) {
            sp.edit().putInt("font_size", v).apply()
        }

    var serif: Boolean
        get() = sp.getBoolean("serif", true)
        set(v) {
            sp.edit().putBoolean("serif", v).apply()
        }

    /** -1 = follow the system brightness */
    var brightness: Float
        get() = sp.getFloat("brightness", -1f)
        set(v) {
            sp.edit().putFloat("brightness", v).apply()
        }
}
