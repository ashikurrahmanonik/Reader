package com.reader.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)

    fun loadHistory(): List<HistoryEntry> {
        val raw = sp.getString("history", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<HistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryEntry(
                        path = o.getString("path"),
                        name = o.optString("name"),
                        lastPage = o.optInt("page"),
                        pageCount = o.optInt("count"),
                        lastOpened = o.optLong("t")
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveHistory(list: List<HistoryEntry>) {
        val arr = JSONArray()
        for (h in list) {
            val o = JSONObject()
            o.put("path", h.path)
            o.put("name", h.name)
            o.put("page", h.lastPage)
            o.put("count", h.pageCount)
            o.put("t", h.lastOpened)
            arr.put(o)
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun loadFavorites(): Set<String> =
        sp.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(set: Set<String>) {
        sp.edit().putStringSet("favorites", HashSet(set)).apply()
    }

    var readerTheme: Int
        get() = sp.getInt("reader_theme", 0)
        set(v) {
            sp.edit().putInt("reader_theme", v).apply()
        }

    var autoUpdate: Boolean
        get() = sp.getBoolean("auto_update", true)
        set(v) {
            sp.edit().putBoolean("auto_update", v).apply()
        }
}
