package com.reader.app.epub

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.IOException
import java.util.zip.ZipFile

data class TocItem(val title: String, val spineIndex: Int)

class EpubBook(
    val path: String,
    private val zip: ZipFile,
    val title: String,
    val spine: List<String>,
    val coverEntry: String?
) {
    var toc: List<TocItem> = emptyList()
    var missingFonts: Set<String> = emptySet()

    private val lowerIndex: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        val en = zip.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            m[e.name.lowercase()] = e.name
        }
        m
    }

    fun entryName(name: String): String? {
        if (zip.getEntry(name) != null) return name
        val d = Uri.decode(name)
        if (zip.getEntry(d) != null) return d
        return lowerIndex[name.lowercase()] ?: lowerIndex[d.lowercase()]
    }

    fun bytes(name: String): ByteArray? {
        val n = entryName(name) ?: return null
        val e = zip.getEntry(n) ?: return null
        return try {
            zip.getInputStream(e).use { it.readBytes() }
        } catch (t: Throwable) {
            null
        }
    }

    fun imageSize(entry: String): Pair<Int, Int>? {
        val b = bytes(entry) ?: return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        return if (o.outWidth > 0 && o.outHeight > 0) Pair(o.outWidth, o.outHeight) else null
    }

    fun close() {
        try {
            zip.close()
        } catch (_: Throwable) {
        }
    }
}

/** Decoded-image cache shared by all books (images are decoded lazily while drawing a page). */
object EpubImages {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    @Synchronized
    fun get(book: EpubBook, entry: String, targetW: Int): Bitmap? {
        val key = "${book.path}|$entry|$targetW"
        cache.get(key)?.let { return it }
        val b = decodeSampled(book.bytes(entry), targetW, Int.MAX_VALUE) ?: return null
        cache.put(key, b)
        return b
    }

    fun decodeSampled(bytes: ByteArray?, targetW: Int, targetH: Int): Bitmap? {
        if (bytes == null) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        var w = o.outWidth
        var h = o.outHeight
        while (w / 2 >= targetW && h / 2 >= targetH) {
            w /= 2
            h /= 2
            sample *= 2
        }
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}

fun resolvePath(baseDir: String, rel: String): String {
    var r = rel.substringBefore('#').substringBefore('?')
    r = Uri.decode(r)
    val parts = ArrayList<String>()
    if (!r.startsWith("/")) {
        for (seg in baseDir.split('/')) if (seg.isNotEmpty()) parts.add(seg)
    }
    for (seg in r.split('/')) {
        if (seg.isEmpty() || seg == ".") continue
        if (seg == "..") {
            if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
        } else {
            parts.add(seg)
        }
    }
    return parts.joinToString("/")
}

private class ManifestItem(val id: String, val href: String, val type: String, val props: String)

object EpubParser {
    fun open(path: String): EpubBook {
        val zip = ZipFile(path)
        try {
            val container = zip.getEntry("META-INF/container.xml") ?: throw IOException("no container")
            val rootPath = zip.getInputStream(container).use { findRootfile(it.readBytes()) }
                ?: throw IOException("no rootfile")
            val opfEntry = zip.getEntry(rootPath) ?: throw IOException("no opf")
            val opfBytes = zip.getInputStream(opfEntry).use { it.readBytes() }
            val opfDir = rootPath.substringBeforeLast('/', "")

            val manifest = LinkedHashMap<String, ManifestItem>()
            val spineIds = ArrayList<String>()
            var tocId: String? = null
            var title = ""
            var coverMetaId: String? = null

            val p = Xml.newPullParser()
            p.setInput(ByteArrayInputStream(opfBytes), null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name ?: ""
                    if (n == "item") {
                        val id = p.getAttributeValue(null, "id") ?: ""
                        val href = p.getAttributeValue(null, "href") ?: ""
                        val type = p.getAttributeValue(null, "media-type") ?: ""
                        val props = p.getAttributeValue(null, "properties") ?: ""
                        if (id.isNotEmpty()) manifest[id] = ManifestItem(id, href, type, props)
                    } else if (n == "itemref") {
                        val idref = p.getAttributeValue(null, "idref")
                        val linear = p.getAttributeValue(null, "linear")
                        if (idref != null && linear != "no") spineIds.add(idref)
                    } else if (n == "spine") {
                        tocId = p.getAttributeValue(null, "toc")
                    } else if (n == "meta") {
                        if (p.getAttributeValue(null, "name") == "cover") {
                            coverMetaId = p.getAttributeValue(null, "content")
                        }
                    } else if (n == "title" || n.endsWith(":title")) {
                        if (title.isEmpty()) {
                            title = try {
                                p.nextText().trim()
                            } catch (e: Throwable) {
                                ""
                            }
                        }
                    }
                }
                ev = p.next()
            }

            val spine = ArrayList<String>()
            for (id in spineIds) {
                val it = manifest[id] ?: continue
                val isHtml = it.type.contains("html") || it.href.endsWith(".html", true) ||
                    it.href.endsWith(".xhtml", true) || it.href.endsWith(".htm", true)
                if (isHtml) spine.add(resolvePath(opfDir, it.href))
            }
            if (spine.isEmpty()) throw IOException("empty spine")

            val coverItem = manifest.values.firstOrNull { "cover-image" in it.props.split(' ') }
                ?: coverMetaId?.let { manifest[it] }
            val cover = coverItem?.let { resolvePath(opfDir, it.href) }

            val book = EpubBook(path, zip, title, spine, cover)

            // table of contents: EPUB3 nav first, then EPUB2 ncx
            val navItem = manifest.values.firstOrNull { "nav" in it.props.split(' ') }
            val ncxItem = (tocId?.let { manifest[it] })
                ?: manifest.values.firstOrNull { it.type == "application/x-dtbncx+xml" }
            var raw: List<Pair<String, String>> = emptyList()
            var tocDir = opfDir
            if (navItem != null) {
                val b = book.bytes(resolvePath(opfDir, navItem.href))
                if (b != null) {
                    raw = try {
                        parseNav(b)
                    } catch (e: Throwable) {
                        emptyList()
                    }
                    tocDir = resolvePath(opfDir, navItem.href).substringBeforeLast('/', "")
                }
            }
            if (raw.isEmpty() && ncxItem != null) {
                val b = book.bytes(resolvePath(opfDir, ncxItem.href))
                if (b != null) {
                    raw = try {
                        parseNcx(b)
                    } catch (e: Throwable) {
                        emptyList()
                    }
                    tocDir = resolvePath(opfDir, ncxItem.href).substringBeforeLast('/', "")
                }
            }
            val items = ArrayList<TocItem>()
            for ((t, href) in raw) {
                val idx = spine.indexOf(resolvePath(tocDir, href))
                if (idx >= 0 && t.isNotBlank()) items.add(TocItem(t.trim(), idx))
            }
            book.toc = items
            return book
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }

    /** Cover image for the library thumbnails. */
    fun cover(path: String, targetW: Int): Bitmap? {
        val book = open(path)
        try {
            val entry = book.coverEntry ?: return null
            return EpubImages.decodeSampled(book.bytes(entry), targetW, targetW)
        } finally {
            book.close()
        }
    }

    private fun findRootfile(bytes: ByteArray): String? {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), null)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name == "rootfile") {
                return p.getAttributeValue(null, "full-path")
            }
            ev = p.next()
        }
        return null
    }

    private fun relaxed(p: XmlPullParser) {
        try {
            p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
        } catch (_: Throwable) {
        }
    }

    private fun readText(p: XmlPullParser): String {
        val sb = StringBuilder()
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.START_TAG -> depth++
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.TEXT -> sb.append(p.text)
                XmlPullParser.END_DOCUMENT -> return sb.toString()
                else -> {}
            }
        }
        return sb.toString()
    }

    private fun parseNav(bytes: ByteArray): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val p = Xml.newPullParser()
        relaxed(p)
        p.setInput(ByteArrayInputStream(bytes), null)
        var inToc = false
        var done = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && !done) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name ?: ""
                if (n == "nav") {
                    val t = p.getAttributeValue(null, "epub:type") ?: p.getAttributeValue(null, "type") ?: ""
                    if (t.contains("toc")) inToc = true
                } else if (n == "a" && inToc) {
                    val href = p.getAttributeValue(null, "href")
                    val txt = readText(p).replace(Regex("\\s+"), " ").trim()
                    if (href != null && txt.isNotEmpty()) out.add(Pair(txt, href))
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "nav" && inToc) {
                inToc = false
                done = true
            }
            ev = p.next()
        }
        return out
    }

    private fun parseNcx(bytes: ByteArray): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val p = Xml.newPullParser()
        relaxed(p)
        p.setInput(ByteArrayInputStream(bytes), null)
        var inLabel = false
        var pending: String? = null
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name ?: ""
                if (n == "navLabel") {
                    inLabel = true
                } else if (n == "text" && inLabel) {
                    pending = try {
                        p.nextText().trim()
                    } catch (e: Throwable) {
                        null
                    }
                } else if (n == "content") {
                    val src = p.getAttributeValue(null, "src")
                    val t = pending
                    if (src != null && t != null) out.add(Pair(t, src))
                    pending = null
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "navLabel") {
                inLabel = false
            }
            ev = p.next()
        }
        return out
    }
}
