package com.reader.app.epub

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.Html
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.text.style.AlignmentSpan
import android.text.style.ImageSpan
import android.text.style.RelativeSizeSpan
import android.text.style.URLSpan
import com.reader.app.pdf.BookDoc
import com.reader.app.pdf.TocEntry
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlin.math.max
import kotlin.math.min

private class LazyImage(
    private val book: EpubBook,
    private val entry: String,
    private val targetW: Int
) : Drawable() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val b = EpubImages.get(book, entry, targetW) ?: return
        canvas.drawBitmap(b, null, bounds, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

class PageRef(val chapter: Int, val startLine: Int, val endLine: Int, val startChar: Int)

/** A paginated EPUB: every page is a slice of lines of a StaticLayout, drawn on demand. */
class EpubDoc private constructor(
    val book: EpubBook,
    private val layouts: List<StaticLayout?>,
    private val pages: List<PageRef>,
    private val chapterFirstPage: IntArray,
    private val w: Int,
    private val h: Int,
    private val marginH: Int,
    private val marginTop: Int,
    private val density: Float
) : BookDoc {
    private val lock = Any()
    private val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(140, 146, 160)
        textSize = 11f * density
        textAlign = Paint.Align.CENTER
    }

    override val pageCount: Int get() = pages.size

    override fun renderPage(index: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(this.w, this.h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        if (index < 0 || index >= pages.size) return bmp
        val p = pages[index]
        val layout = layouts[p.chapter] ?: return bmp
        synchronized(lock) {
            val c = Canvas(bmp)
            val top = layout.getLineTop(p.startLine)
            val bottom = layout.getLineBottom(p.endLine - 1)
            c.save()
            c.clipRect(
                marginH.toFloat(), marginTop.toFloat(),
                (this.w - marginH).toFloat(), (marginTop + (bottom - top)).toFloat()
            )
            c.translate(marginH.toFloat(), (marginTop - top).toFloat())
            layout.draw(c)
            c.restore()
            if (book.title.isNotBlank()) {
                val t = TextUtils.ellipsize(book.title, footerPaint, (this.w - 2 * marginH).toFloat(), TextUtils.TruncateAt.END)
                c.drawText(t.toString(), this.w / 2f, this.h - 18f * density, footerPaint)
            }
        }
        return bmp
    }

    override fun locatorOf(page: Int): Long {
        if (page < 0 || page >= pages.size) return -1L
        val p = pages[page]
        return p.chapter.toLong() * LOC + p.startChar
    }

    fun pageForLocator(loc: Long): Int {
        if (loc < 0 || pages.isEmpty()) return 0
        val ch = (loc / LOC).toInt()
        val off = (loc % LOC).toInt()
        var best = 0
        for (i in pages.indices) {
            val p = pages[i]
            if (p.chapter < ch || (p.chapter == ch && p.startChar <= off)) best = i else break
        }
        return best
    }

    override fun toc(): List<TocEntry> {
        val out = ArrayList<TocEntry>()
        if (book.toc.isNotEmpty()) {
            for (t in book.toc) {
                var pg = -1
                var i = t.spineIndex
                while (i < chapterFirstPage.size && pg < 0) {
                    pg = chapterFirstPage[i]
                    i++
                }
                if (pg >= 0) out.add(TocEntry(t.title, pg))
            }
        } else {
            for (i in chapterFirstPage.indices) {
                if (chapterFirstPage[i] >= 0) out.add(TocEntry("", chapterFirstPage[i]))
            }
        }
        return out
    }

    override fun close() {
        // the underlying book is closed by whoever opened it
    }

    companion object {
        private const val LOC = 10_000_000L

        suspend fun build(
            book: EpubBook,
            w: Int,
            h: Int,
            density: Float,
            fontSp: Int,
            serif: Boolean,
            onProgress: (Float) -> Unit
        ): EpubDoc {
            val marginH = (26 * density).toInt()
            val marginTop = (44 * density).toInt()
            val marginBottom = (48 * density).toInt()
            val cw = max(100, w - 2 * marginH)
            val ch = max(100, h - marginTop - marginBottom)

            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
            paint.color = Color.rgb(28, 30, 36)
            paint.textSize = fontSp * density
            paint.typeface = if (serif) Typeface.SERIF else Typeface.SANS_SERIF

            val layouts = ArrayList<StaticLayout?>()
            val pages = ArrayList<PageRef>()
            val first = IntArray(book.spine.size) { -1 }

            for (i in book.spine.indices) {
                currentCoroutineContext().ensureActive()
                onProgress(i.toFloat() / max(1, book.spine.size))
                val html = book.bytes(book.spine[i])?.toString(Charsets.UTF_8)
                if (html == null) {
                    layouts.add(null)
                    continue
                }
                val sp = buildSpanned(book, book.spine[i], html, cw, ch, density)
                if (sp.isEmpty()) {
                    layouts.add(null)
                    continue
                }
                val lb = StaticLayout.Builder.obtain(sp, 0, sp.length, paint, cw)
                    .setLineSpacing(0f, 1.3f)
                    .setIncludePad(false)
                    .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                    .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
                if (Build.VERSION.SDK_INT >= 26) {
                    lb.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
                }
                val layout = lb.build()
                layouts.add(layout)

                val n = layout.lineCount
                var line = 0
                while (line < n) {
                    // skip blank spacer lines at the top of a page
                    while (line < n - 1 && isBlankLine(layout, sp, line)) line++
                    val top = layout.getLineTop(line)
                    var end = line
                    while (end < n && layout.getLineBottom(end) - top <= ch) end++
                    if (end == line) end = line + 1
                    if (first[i] < 0) first[i] = pages.size
                    pages.add(PageRef(i, line, end, layout.getLineStart(line)))
                    line = end
                }
            }
            onProgress(1f)
            if (pages.isEmpty()) throw IllegalStateException("empty book")
            return EpubDoc(book, layouts, pages, first, w, h, marginH, marginTop, density)
        }

        private fun isBlankLine(layout: StaticLayout, sp: CharSequence, line: Int): Boolean {
            val s = layout.getLineStart(line)
            val e = layout.getLineEnd(line)
            for (k in s until e) if (!sp[k].isWhitespace()) return false
            return true
        }

        private fun prep(html: String): String {
            var s = html
            val bi = s.indexOf("<body", ignoreCase = true)
            if (bi >= 0) {
                val gt = s.indexOf('>', bi)
                val be = s.lastIndexOf("</body>", ignoreCase = true)
                if (gt >= 0) s = if (be > gt) s.substring(gt + 1, be) else s.substring(gt + 1)
            }
            s = s.replace(Regex("<(style|script)[^>]*>.*?</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), "")
            // SVG cover pages: turn <image xlink:href=".."> into <img src="..">, drop the svg wrappers
            s = s.replace(
                Regex("<image[^>]*?(?:xlink:)?href=[\"']([^\"']+)[\"'][^>]*>", RegexOption.IGNORE_CASE),
                "<img src=\"$1\"/>"
            )
            s = s.replace(Regex("</?svg[^>]*>", RegexOption.IGNORE_CASE), "")
            return s
        }

        private fun buildSpanned(
            book: EpubBook,
            entry: String,
            html: String,
            cw: Int,
            ch: Int,
            density: Float
        ): SpannableStringBuilder {
            val dir = entry.substringBeforeLast('/', "")
            val getter = Html.ImageGetter { src ->
                val ent = resolvePath(dir, src ?: "")
                val size = book.imageSize(ent)
                if (size == null) {
                    val d = ColorDrawable(Color.TRANSPARENT)
                    d.setBounds(0, 0, 1, 1)
                    d
                } else {
                    val iw = size.first
                    val ih = size.second
                    val maxW = cw.toFloat()
                    val maxH = ch * 0.92f
                    val scale = if (iw >= 120) min(maxW / iw, maxH / ih) else density
                    val tw = max(1, (iw * scale).toInt())
                    val th = max(1, (ih * scale).toInt())
                    val d = LazyImage(book, ent, tw)
                    d.setBounds(0, 0, tw, th)
                    d
                }
            }
            val spanned = Html.fromHtml(prep(html), Html.FROM_HTML_MODE_LEGACY, getter, null)
            val sb = SpannableStringBuilder(spanned)

            for (u in sb.getSpans(0, sb.length, URLSpan::class.java)) sb.removeSpan(u)

            // trim leading / trailing whitespace
            while (sb.isNotEmpty() && sb[0].isWhitespace()) sb.delete(0, 1)
            while (sb.isNotEmpty() && sb[sb.length - 1].isWhitespace()) sb.delete(sb.length - 1, sb.length)

            // make blank lines between paragraphs smaller
            for (i in 1 until sb.length) {
                if (sb[i] == '\n' && sb[i - 1] == '\n') {
                    sb.setSpan(RelativeSizeSpan(0.45f), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }

            // centre images that sit alone in their paragraph
            for (img in sb.getSpans(0, sb.length, ImageSpan::class.java)) {
                val s = sb.getSpanStart(img)
                val e = sb.getSpanEnd(img)
                var ps = s
                while (ps > 0 && sb[ps - 1] != '\n') ps--
                var pe = e
                while (pe < sb.length && sb[pe] != '\n') pe++
                var alone = true
                for (k in ps until pe) {
                    if (k in s until e) continue
                    if (!sb[k].isWhitespace()) {
                        alone = false
                        break
                    }
                }
                if (alone) {
                    val end = min(sb.length, pe + 1)
                    sb.setSpan(
                        AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER),
                        ps, end, Spannable.SPAN_PARAGRAPH
                    )
                }
            }
            return sb
        }
    }
}
