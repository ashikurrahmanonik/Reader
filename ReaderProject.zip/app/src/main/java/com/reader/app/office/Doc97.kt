package com.reader.app.office

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Minimal reader for old binary Word files (.doc, Word 97-2003): pulls the plain text out.
 * Layout (fonts, tables, pictures) of such files is not reproduced - convert to .docx for that.
 */
object Doc97 {
    private const val ENDOFCHAIN = -2
    private const val FREESECT = -1

    private class Cfb(val d: ByteArray) {
        val bb: ByteBuffer = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val ss = 1 shl bb.getShort(0x1E).toInt()
        val mss = 1 shl bb.getShort(0x20).toInt()
        val cutoff = bb.getInt(0x38)
        val fat = ArrayList<Int>()
        val miniFat = ArrayList<Int>()
        var miniStream = ByteArray(0)
        class Ent(val name: String, val type: Int, val start: Int, val size: Long)
        val entries = ArrayList<Ent>()

        private fun secOff(id: Int) = (id + 1).toLong() * ss

        private fun readSector(id: Int): ByteArray {
            val o = secOff(id)
            if (o < 0 || o + ss > d.size) return ByteArray(0)
            return d.copyOfRange(o.toInt(), o.toInt() + ss)
        }

        private fun chain(start: Int, table: List<Int>): ByteArray {
            val out = java.io.ByteArrayOutputStream()
            var s = start
            var guard = 0
            while (s >= 0 && guard++ < 1_000_000) {
                out.write(readSector(s))
                s = if (s < table.size) table[s] else break
            }
            return out.toByteArray()
        }

        init {
            // FAT sector list: 109 entries in the header, the rest through DIFAT sectors
            val difat = ArrayList<Int>()
            for (i in 0 until 109) difat.add(bb.getInt(0x4C + i * 4))
            var ds = bb.getInt(0x44)
            var n = bb.getInt(0x48)
            while (n-- > 0 && ds >= 0) {
                val o = secOff(ds).toInt()
                for (i in 0 until ss / 4 - 1) difat.add(bb.getInt(o + i * 4))
                ds = bb.getInt(o + ss - 4)
            }
            for (f in difat) {
                if (f < 0) continue
                val o = secOff(f).toInt()
                if (o + ss > d.size) continue
                for (i in 0 until ss / 4) fat.add(bb.getInt(o + i * 4))
            }
            val dir = chain(bb.getInt(0x30), fat)
            val db = ByteBuffer.wrap(dir).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until dir.size / 128) {
                val o = i * 128
                val len = db.getShort(o + 0x40).toInt()
                val nm = if (len >= 2) String(dir, o, len - 2, Charsets.UTF_16LE) else ""
                entries.add(Ent(nm, dir[o + 0x42].toInt(), db.getInt(o + 0x74), db.getInt(o + 0x78).toLong() and 0xFFFFFFFFL))
            }
            val root = entries.firstOrNull { it.type == 5 }
            if (root != null) {
                miniStream = chain(root.start, fat)
                val mf = chain(bb.getInt(0x3C), fat)
                val mb = ByteBuffer.wrap(mf).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until mf.size / 4) miniFat.add(mb.getInt(i * 4))
            }
        }

        fun stream(name: String): ByteArray? {
            val e = entries.firstOrNull { it.type == 2 && it.name == name } ?: return null
            if (e.size < cutoff) {
                val out = java.io.ByteArrayOutputStream()
                var s = e.start
                var guard = 0
                while (s >= 0 && guard++ < 1_000_000) {
                    val o = s * mss
                    if (o + mss > miniStream.size) break
                    out.write(miniStream, o, mss)
                    s = if (s < miniFat.size) miniFat[s] else break
                }
                return out.toByteArray().copyOf(e.size.toInt())
            }
            val b = chain(e.start, fat)
            return if (b.size >= e.size) b.copyOf(e.size.toInt()) else b
        }
    }

    fun extractText(path: String): String {
        val data = File(path).readBytes()
        if (data.size < 512 || data[0] != 0xD0.toByte() || data[1] != 0xCF.toByte()) {
            return String(data, Charsets.UTF_8) // not an OLE file: show it as plain text
        }
        val cfb = Cfb(data)
        val wd = cfb.stream("WordDocument") ?: return ""
        val w = ByteBuffer.wrap(wd).order(ByteOrder.LITTLE_ENDIAN)
        val flags = w.getShort(0x0A).toInt()
        val tableName = if ((flags and 0x0200) != 0) "1Table" else "0Table"
        val table = cfb.stream(tableName) ?: return ""
        val csw = w.getShort(32).toInt() and 0xFFFF
        val lwStart = 32 + 2 + csw * 2 + 2           // FibRgLw97
        val ccpText = w.getInt(lwStart + 3 * 4)
        val cslw = w.getShort(32 + 2 + csw * 2).toInt() and 0xFFFF
        val blob = lwStart + cslw * 4 + 2            // FibRgFcLcb97
        val fcClx = w.getInt(blob + 33 * 8)
        val lcbClx = w.getInt(blob + 33 * 8 + 4)
        val t = ByteBuffer.wrap(table).order(ByteOrder.LITTLE_ENDIAN)
        var p = fcClx
        val end = fcClx + lcbClx
        while (p < end && table[p].toInt() == 1) {            // skip Prc records
            p += 3 + (t.getShort(p + 1).toInt() and 0xFFFF)
        }
        if (p >= end || table[p].toInt() != 2) return ""
        val lcb = t.getInt(p + 1)
        val plc = p + 5
        val n = (lcb - 4) / 12
        val sb = StringBuilder()
        for (i in 0 until n) {
            val cpStart = t.getInt(plc + i * 4)
            val cpEnd = t.getInt(plc + (i + 1) * 4)
            val pcd = plc + (n + 1) * 4 + i * 8
            var fc = t.getInt(pcd + 2)
            val compressed = (fc and 0x40000000) != 0
            fc = fc and 0x3FFFFFFF
            val cnt = minOf(cpEnd, ccpText) - cpStart
            if (cnt <= 0) continue
            if (compressed) {
                val off = fc / 2
                if (off + cnt <= wd.size) sb.append(String(wd, off, cnt, charset("windows-1252")))
            } else {
                if (fc + cnt * 2 <= wd.size) sb.append(String(wd, fc, cnt * 2, Charsets.UTF_16LE))
            }
        }
        return clean(sb.toString())
    }

    /** paragraph / cell / break marks -> text; field codes (between 0x13 and 0x14) are dropped. */
    private fun clean(raw: String): String {
        val out = StringBuilder()
        var depth = 0
        var inCode = 0
        for (c in raw) {
            when (c) {
                '\u0013' -> { depth++; inCode++ }
                '\u0014' -> if (inCode > 0) inCode--
                '\u0015' -> { if (depth > 0) depth--; if (inCode > depth) inCode = depth }
                else -> if (inCode == 0) when (c) {
                    '\r' -> out.append('\n')
                    '\u0007' -> out.append('\t')
                    '\u000B' -> out.append('\n')
                    '\u000C' -> out.append("\n\n")
                    '\u0001', '\u0008' -> {}
                    else -> if (c >= ' ' || c == '\t') out.append(c)
                }
            }
        }
        return out.toString().replace("\t\n", "\n")
    }
}
