package com.reader.app.office

import android.graphics.Color
import android.graphics.Typeface
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ImageSpan
import android.text.style.MetricAffectingSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.UnderlineSpan
import android.util.Xml
import com.reader.app.FontStore
import com.reader.app.epub.EpubBook
import com.reader.app.epub.LazyImage
import com.reader.app.epub.resolvePath
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min

/** Applies one custom Typeface to a text run (and fakes bold / italic if the face lacks them). */
class FontSpan(private val tf: Typeface) : MetricAffectingSpan() {
    override fun updateDrawState(ds: TextPaint) = apply(ds)
    override fun updateMeasureState(ds: TextPaint) = apply(ds)
    private fun apply(ds: TextPaint) {
        val old = ds.typeface
        val oldStyle = old?.style ?: 0
        val fake = oldStyle and tf.style.inv()
        if (fake and Typeface.BOLD != 0) ds.isFakeBoldText = true
        if (fake and Typeface.ITALIC != 0) ds.textSkewX = -0.25f
        ds.typeface = tf
    }
}

class RProps {
    var font: String? = null
    /** font for complex scripts (Bangla): Word uses w:cs, not w:ascii, for those characters */
    var fontCs: String? = null
    var sizeCs: Float? = null
    var boldCs: Boolean? = null
    var italicCs: Boolean? = null
    var sizePt: Float? = null
    var bold: Boolean? = null
    var italic: Boolean? = null
    var underline: Boolean? = null
    var strike: Boolean? = null
    var color: Int? = null
    var highlight: Int? = null
    var vert: Int? = null
    var caps: Boolean? = null

    fun copyFrom(o: RProps) {
        o.font?.let { font = it }
        o.fontCs?.let { fontCs = it }
        o.sizeCs?.let { sizeCs = it }
        o.boldCs?.let { boldCs = it }
        o.italicCs?.let { italicCs = it }
        o.sizePt?.let { sizePt = it }
        o.bold?.let { bold = it }
        o.italic?.let { italic = it }
        o.underline?.let { underline = it }
        o.strike?.let { strike = it }
        o.color?.let { color = it }
        o.highlight?.let { highlight = it }
        o.vert?.let { vert = it }
        o.caps?.let { caps = it }
    }
}

class DRun(val text: String, val props: RProps, val image: String?)

class DPara(
    val runs: List<DRun>,
    val align: String?,
    val heading: Int,
    val bullet: Boolean,
    val level: Int
)

private class StyleDef(
    val id: String,
    val type: String,
    val name: String,
    val basedOn: String?,
    val rp: RProps,
    val isDefault: Boolean,
    val list: Boolean
)

/** A text document turned into chapters of paragraphs (DOCX, PPTX, TXT). */
class DocModel(val chapters: List<List<DPara>>, val compact: Boolean, val titles: List<String>) {

    /** Builds the styled text of one chapter. [missing] collects legacy fonts we don't have. */
    fun buildSpans(
        index: Int,
        basePaint: TextPaint,
        density: Float,
        cw: Int,
        ch: Int,
        book: EpubBook,
        missing: MutableSet<String>
    ): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        val basePx = basePaint.textSize
        val faceCache = HashMap<String, Typeface>()

        for (para in chapters[index]) {
            val start = sb.length
            if (para.bullet) {
                for (i in 0 until para.level) sb.append("     ")
                sb.append("•  ")
            }
            for (run in para.runs) {
                if (run.image != null) {
                    val size = book.imageSize(run.image)
                    if (size != null) {
                        val iw = size.first
                        val ih = size.second
                        val scale = min(cw.toFloat() / iw, (ch * 0.92f) / ih)
                        val tw = max(1, (iw * min(scale, 1.6f)).toInt())
                        val th = max(1, (ih * min(scale, 1.6f)).toInt())
                        val d = LazyImage(book, run.image, tw)
                        d.setBounds(0, 0, tw, th)
                        val s = sb.length
                        sb.append('\uFFFC')
                        sb.setSpan(ImageSpan(d), s, s + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    continue
                }
                if (run.text.isEmpty()) continue
                val rp = run.props
                val s = sb.length
                sb.append(run.text)
                val e = sb.length

                var sizePt = rp.sizePt ?: 11f
                var bold = rp.bold == true
                if (para.heading > 0 && rp.sizePt == null) {
                    sizePt = when (para.heading) {
                        1 -> 11f * 1.7f
                        2 -> 11f * 1.45f
                        3 -> 11f * 1.25f
                        else -> 11f * 1.1f
                    }
                    bold = true
                }
                val italic = rp.italic == true
                val style = (if (bold) Typeface.BOLD else 0) or (if (italic) Typeface.ITALIC else 0)

                val fontName = rp.font
                var custom = FontStore.find(fontName)
                if (custom == null && FontStore.isMissingLegacy(fontName)) missing.add(fontName!!)
                val key = "${fontName ?: ""}|$style"
                val face = faceCache.getOrPut(key) {
                    Typeface.create(custom ?: basePaint.typeface ?: Typeface.DEFAULT, style)
                }
                sb.setSpan(FontSpan(face), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                val px = (basePx * sizePt / 11f).toInt().coerceIn(6, 400)
                sb.setSpan(AbsoluteSizeSpan(px, false), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                rp.color?.let { sb.setSpan(ForegroundColorSpan(it), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                if (rp.underline == true) sb.setSpan(UnderlineSpan(), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (rp.strike == true) sb.setSpan(StrikethroughSpan(), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            sb.append('\n')
            val align = when (para.align) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> null
            }
            if (align != null) {
                sb.setSpan(AlignmentSpan.Standard(align), start, sb.length, Spannable.SPAN_PARAGRAPH)
            }
            if (!compact) {
                val g = sb.length
                sb.append('\n')
                sb.setSpan(RelativeSizeSpan(0.4f), g, g + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        while (sb.isNotEmpty() && sb[sb.length - 1].isWhitespace()) sb.delete(sb.length - 1, sb.length)
        return sb
    }
}

private class XNode(val name: String, val attrs: Map<String, String>) {
    val kids = ArrayList<XNode>(4)
    var text: StringBuilder? = null
    val ln: String = name.substringAfter(':')

    fun attr(local: String): String? {
        attrs["w:$local"]?.let { return it }
        for ((k, v) in attrs) if (k.substringAfter(':') == local) return v
        return null
    }

    fun kid(local: String): XNode? {
        for (k in kids) if (k.ln == local) return k
        return null
    }
}

object DocxParser {
    private fun newParser(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        try {
            p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
        } catch (_: Throwable) {
        }
        p.setInput(ByteArrayInputStream(bytes), null)
        return p
    }

    /** Whole part as a small tree; only <w:t> text is kept. Robust against any nesting. */
    private fun parseTree(bytes: ByteArray): XNode {
        val p = newParser(bytes)
        val root = XNode("#root", emptyMap())
        val stack = ArrayList<XNode>()
        stack.add(root)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val attrs = HashMap<String, String>()
                for (i in 0 until p.attributeCount) attrs[p.getAttributeName(i)] = p.getAttributeValue(i)
                val n = XNode(p.name ?: "", attrs)
                stack[stack.size - 1].kids.add(n)
                stack.add(n)
            } else if (ev == XmlPullParser.TEXT || ev == XmlPullParser.IGNORABLE_WHITESPACE) {
                val top = stack[stack.size - 1]
                if (top.ln == "t") {
                    val sb = top.text ?: StringBuilder().also { top.text = it }
                    sb.append(p.text)
                }
            } else if (ev == XmlPullParser.END_TAG) {
                if (stack.size > 1) stack.removeAt(stack.size - 1)
            }
            ev = p.next()
        }
        return root
    }

    private fun readRProps(rpr: XNode?, into: RProps) {
        if (rpr == null) return
        for (k in rpr.kids) {
            when (k.ln) {
                "rFonts" -> {
                    val f = k.attr("ascii") ?: k.attr("hAnsi") ?: k.attr("cs") ?: k.attr("eastAsia")
                    if (f != null) into.font = f
                }
                "b" -> into.bold = onOff(k)
                "i" -> into.italic = onOff(k)
                "u" -> into.underline = onOff(k)
                "strike" -> into.strike = onOff(k)
                "sz" -> k.attr("val")?.toFloatOrNull()?.let { into.sizePt = it / 2f }
                "color" -> {
                    val c = k.attr("val")
                    if (c != null && c.length == 6 && c != "auto") {
                        try {
                            into.color = Color.parseColor("#$c")
                        } catch (_: Throwable) {
                        }
                    }
                }
            }
        }
    }

    private fun onOff(k: XNode): Boolean {
        val v = k.attr("val") ?: return true
        return !(v == "0" || v == "false" || v == "off" || v == "none")
    }

    private fun parseStyles(bytes: ByteArray?): Pair<RProps, Map<String, StyleDef>> {
        val defaults = RProps()
        val styles = LinkedHashMap<String, StyleDef>()
        if (bytes == null) return Pair(defaults, styles)
        try {
            val root = parseTree(bytes)
            val st = root.kids.firstOrNull { it.ln == "styles" } ?: return Pair(defaults, styles)
            for (k in st.kids) {
                when (k.ln) {
                    "docDefaults" -> readRProps(k.kid("rPrDefault")?.kid("rPr"), defaults)
                    "style" -> {
                        val id = k.attr("styleId") ?: continue
                        val rp = RProps()
                        readRProps(k.kid("rPr"), rp)
                        styles[id] = StyleDef(
                            id,
                            k.attr("type") ?: "",
                            k.kid("name")?.attr("val") ?: "",
                            k.kid("basedOn")?.attr("val"),
                            rp,
                            k.attr("default") == "1",
                            k.kid("pPr")?.kid("numPr") != null
                        )
                    }
                }
            }
        } catch (_: Throwable) {
        }
        return Pair(defaults, styles)
    }

    private fun chain(styles: Map<String, StyleDef>, id: String?): List<StyleDef> {
        val out = ArrayList<StyleDef>()
        var cur = id
        var guard = 0
        while (cur != null && guard < 8) {
            val s = styles[cur] ?: break
            out.add(0, s)
            cur = s.basedOn
            guard++
        }
        return out
    }

    private fun parseRels(bytes: ByteArray?): Map<String, String> {
        val map = HashMap<String, String>()
        if (bytes == null) return map
        try {
            val p = newParser(bytes)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && (p.name ?: "").endsWith("Relationship")) {
                    val id = p.getAttributeValue(null, "Id")
                    val target = p.getAttributeValue(null, "Target")
                    if (id != null && target != null) map[id] = target
                }
                ev = p.next()
            }
        } catch (_: Throwable) {
        }
        return map
    }

    private class PState {
        var breakAfter = false
    }

    private class Builder(
        val defaults: RProps,
        val styles: Map<String, StyleDef>,
        val defaultPara: StyleDef?,
        val rels: Map<String, String>
    ) {
        val chapters = ArrayList<MutableList<DPara>>()
        var cur: MutableList<DPara> = ArrayList()

        init {
            chapters.add(cur)
        }

        fun newChapter() {
            cur = ArrayList()
            chapters.add(cur)
        }

        fun resolve(pStyle: String?, rStyle: String?, direct: RProps): RProps {
            val out = RProps()
            out.copyFrom(defaults)
            defaultPara?.let { out.copyFrom(it.rp) }
            for (s in chain(styles, pStyle)) out.copyFrom(s.rp)
            for (s in chain(styles, rStyle)) out.copyFrom(s.rp)
            out.copyFrom(direct)
            return out
        }

        fun findBlip(n: XNode): String? {
            if (n.ln == "blip") return n.attr("embed")
            for (c in n.kids) {
                val r = findBlip(c)
                if (r != null) return r
            }
            return null
        }

        fun runNode(r: XNode, pStyle: String?, out: ArrayList<DRun>, st: PState) {
            val direct = RProps()
            var rStyle: String? = null
            val rpr = r.kid("rPr")
            if (rpr != null) {
                readRProps(rpr, direct)
                rStyle = rpr.kid("rStyle")?.attr("val")
            }
            val rs = rStyle
            val sb = StringBuilder()
            fun flush() {
                if (sb.isNotEmpty()) {
                    out.add(DRun(sb.toString(), resolve(pStyle, rs, direct), null))
                    sb.setLength(0)
                }
            }
            fun child(k: XNode) {
                when (k.ln) {
                    "t" -> sb.append(k.text ?: "")
                    "tab" -> sb.append("    ")
                    "br" -> if (k.attr("type") == "page") st.breakAfter = true else sb.append('\n')
                    "cr" -> sb.append('\n')
                    "noBreakHyphen" -> sb.append('-')
                    "drawing" -> {
                        val rid = findBlip(k)
                        val target = if (rid != null) rels[rid] else null
                        if (target != null) {
                            flush()
                            out.add(DRun("", resolve(pStyle, rs, direct), resolvePath("word", target)))
                        }
                    }
                    "AlternateContent" -> {
                        for (c in k.kids) if (c.ln == "Choice") for (g in c.kids) child(g)
                    }
                }
            }
            for (k in r.kids) child(k)
            flush()
        }

        fun collectRuns(node: XNode, pStyle: String?, out: ArrayList<DRun>, st: PState) {
            for (k in node.kids) {
                when (k.ln) {
                    "r" -> runNode(k, pStyle, out, st)
                    "hyperlink", "ins", "smartTag", "sdt", "sdtContent", "fldSimple", "customXml", "moveTo", "bdo", "dir" ->
                        collectRuns(k, pStyle, out, st)
                    "AlternateContent" -> {
                        for (c in k.kids) if (c.ln == "Choice") collectRuns(c, pStyle, out, st)
                    }
                }
            }
        }

        fun paragraph(p: XNode) {
            val pPr = p.kid("pPr")
            val pStyle = pPr?.kid("pStyle")?.attr("val")
            val align = pPr?.kid("jc")?.attr("val")
            val numPr = pPr?.kid("numPr")
            val level = numPr?.kid("ilvl")?.attr("val")?.toIntOrNull() ?: 0
            val breakBefore = pPr?.kid("pageBreakBefore") != null
            val st = PState()
            val runs = ArrayList<DRun>()
            collectRuns(p, pStyle, runs, st)
            val styleName = (styles[pStyle ?: ""]?.name ?: pStyle ?: "").lowercase()
            var heading = 0
            if (styleName.startsWith("heading")) {
                heading = styleName.filter { it.isDigit() }.toIntOrNull() ?: 1
            } else if (styleName == "title") {
                heading = 1
            }
            val viaStyle = styleName.startsWith("list bullet") || styleName.startsWith("list number") ||
                chain(styles, pStyle).any { it.list }
            if (breakBefore && cur.isNotEmpty()) newChapter()
            cur.add(DPara(runs, align, heading, numPr != null || viaStyle, level))
            if (st.breakAfter) newChapter()
        }

        fun cellRuns(tc: XNode, out: ArrayList<DRun>) {
            for (k in tc.kids) {
                when (k.ln) {
                    "p" -> {
                        val st = PState()
                        val pStyle = k.kid("pPr")?.kid("pStyle")?.attr("val")
                        collectRuns(k, pStyle, out, st)
                        out.add(DRun(" ", RProps(), null))
                    }
                    "tbl" -> {
                        for (row in tableRows(k)) {
                            out.addAll(row)
                            out.add(DRun(" ", RProps(), null))
                        }
                    }
                    "sdt", "sdtContent" -> cellRuns(k, out)
                }
            }
        }

        fun tableRows(tbl: XNode): List<List<DRun>> {
            val rows = ArrayList<List<DRun>>()
            for (tr in tbl.kids) {
                if (tr.ln != "tr") continue
                val runs = ArrayList<DRun>()
                var first = true
                for (tc in tr.kids) {
                    if (tc.ln != "tc") continue
                    if (!first) runs.add(DRun("  │  ", RProps(), null))
                    first = false
                    cellRuns(tc, runs)
                }
                rows.add(runs)
            }
            return rows
        }

        fun walkBlocks(node: XNode) {
            for (k in node.kids) {
                when (k.ln) {
                    "p" -> paragraph(k)
                    "tbl" -> for (row in tableRows(k)) cur.add(DPara(row, null, 0, false, 0))
                    "body", "sdt", "sdtContent", "customXml", "ins", "smartTag", "moveTo" -> walkBlocks(k)
                }
            }
        }

        fun textLength(): Int {
            var n = 0
            for (ch in chapters) for (pa in ch) for (r in pa.runs) n += r.text.length + (if (r.image != null) 1 else 0)
            return n
        }
    }

    private fun unescape(s: String): String {
        var r = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
        r = Regex("&#(\\d+);").replace(r) { m -> m.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: "" }
        return r
    }

    /** Last resort: pull every <..:t> text out of the raw XML, whatever the prefixes / structure. */
    private fun regexFallback(xml: String, b: Builder) {
        val pRx = Regex("<(?:\\w+:)?p[ >/].*?</(?:\\w+:)?p>", RegexOption.DOT_MATCHES_ALL)
        val tRx = Regex("<(?:\\w+:)?t(?:\\s[^>]*)?>(.*?)</(?:\\w+:)?t>", RegexOption.DOT_MATCHES_ALL)
        for (m in pRx.findAll(xml)) {
            val sb = StringBuilder()
            for (t in tRx.findAll(m.value)) sb.append(unescape(t.groupValues[1]))
            b.cur.add(DPara(if (sb.isEmpty()) emptyList() else listOf(DRun(sb.toString(), RProps(), null)), null, 0, false, 0))
        }
    }

    fun parse(path: String): Pair<DocModel, EpubBook> {
        val zip = ZipFile(path)
        try {
            fun read(name: String): ByteArray? {
                val e = zip.getEntry(name) ?: return null
                return zip.getInputStream(e).use { it.readBytes() }
            }

            // the main part is normally word/document.xml, but follow the package relationship if not
            var mainName = "word/document.xml"
            if (zip.getEntry(mainName) == null) {
                val en = zip.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.name.startsWith("word/document") && e.name.endsWith(".xml")) {
                        mainName = e.name
                        break
                    }
                }
            }
            val doc = read(mainName) ?: throw IllegalArgumentException("not a docx (no word/document.xml)")
            val (defaults, styles) = parseStyles(read("word/styles.xml"))
            val relName = mainName.substringBeforeLast('/') + "/_rels/" + mainName.substringAfterLast('/') + ".rels"
            val rels = parseRels(read(relName))
            val defaultPara = styles.values.firstOrNull { it.type == "paragraph" && it.isDefault }
            val b = Builder(defaults, styles, defaultPara, rels)

            try {
                val root = parseTree(doc)
                val document = root.kids.firstOrNull { it.ln == "document" }
                val body = document?.kid("body")
                if (body != null) b.walkBlocks(body)
            } catch (_: Throwable) {
            }
            if (b.textLength() == 0) {
                b.chapters.clear()
                b.newChapter()
                regexFallback(String(doc, Charsets.UTF_8), b)
            }

            val nonEmpty = b.chapters.filter { it.isNotEmpty() }
            val finalChapters: List<List<DPara>> =
                if (nonEmpty.isEmpty()) listOf(listOf(DPara(emptyList(), null, 0, false, 0))) else nonEmpty
            val titles = finalChapters.indices.map { "" }
            val model = DocModel(finalChapters, compact = false, titles = titles)
            val book = EpubBook(path, zip, "", List(finalChapters.size) { "chapter$it" }, null)
            return Pair(model, book)
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }
}

object PptxParser {
    fun parse(path: String): Pair<DocModel, EpubBook> {
        val zip = ZipFile(path)
        try {
            val names = ArrayList<Pair<Int, String>>()
            val en = zip.entries()
            val rx = Regex("^ppt/slides/slide(\\d+)\\.xml$")
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                val m = rx.find(e.name)
                if (m != null) names.add(Pair(m.groupValues[1].toInt(), e.name))
            }
            names.sortBy { it.first }
            if (names.isEmpty()) throw IllegalStateException("no slides")

            val chapters = ArrayList<List<DPara>>()
            val titles = ArrayList<String>()
            for ((num, name) in names) {
                val bytes = zip.getInputStream(zip.getEntry(name)).use { it.readBytes() }
                val paras = ArrayList<DPara>()
                paras.add(DPara(listOf(DRun("Slide $num", RProps().also { it.sizePt = 9f; it.color = Color.GRAY }, null)), null, 0, false, 0))
                val p = Xml.newPullParser()
                try {
                    p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
                } catch (_: Throwable) {
                }
                p.setInput(ByteArrayInputStream(bytes), null)
                var isTitle = false
                var inPara = false
                val text = StringBuilder()
                var firstTitle = ""
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "p:sp" -> isTitle = false
                            "p:ph" -> {
                                val t = p.getAttributeValue(null, "type") ?: ""
                                if (t.contains("title", ignoreCase = true)) isTitle = true
                            }
                            "a:p" -> {
                                inPara = true
                                text.setLength(0)
                            }
                            "a:t" -> if (inPara) {
                                try {
                                    text.append(p.nextText())
                                } catch (_: Throwable) {
                                }
                            }
                            "a:br" -> if (inPara) text.append('\n')
                        }
                    } else if (ev == XmlPullParser.END_TAG && p.name == "a:p") {
                        inPara = false
                        val s = text.toString()
                        if (s.isNotBlank()) {
                            if (isTitle && firstTitle.isEmpty()) firstTitle = s.trim()
                            val rp = RProps()
                            if (isTitle) {
                                rp.sizePt = 20f
                                rp.bold = true
                            }
                            paras.add(DPara(listOf(DRun(s, rp, null)), null, 0, !isTitle, 0))
                        }
                    }
                    ev = p.next()
                }
                chapters.add(paras)
                titles.add(if (firstTitle.isNotEmpty()) firstTitle else "Slide $num")
            }
            val model = DocModel(chapters, compact = false, titles = titles)
            val book = EpubBook(path, zip, "", List(chapters.size) { "slide$it" }, null)
            return Pair(model, book)
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }
}

private fun looksBijoy(t: String): Boolean {
    val s = if (t.length > 20000) t.substring(0, 20000) else t
    var letters = 0
    var odd = 0
    for (c in s) {
        if (c.isLetter()) letters++
        // Bijoy uses these Latin-1 / punctuation symbols as Bangla signs
        if (c in "†‡¡¢£¤¥¦§¨©ª«¬®¯°±²³´µ¶·¸¹º»¼½¾¿×÷ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ" || c.code in 0x80..0xFF) odd++
    }
    return letters > 20 && odd * 100 >= letters * 2
}

object TxtParser {
    fun parse(path: String): Pair<DocModel, EpubBook> {
        val bytes = java.io.File(path).readBytes()
        var text = if (path.lowercase().endsWith(".doc")) Doc97.extractText(path) else String(bytes, Charsets.UTF_8)
        if (text.startsWith("\uFEFF")) text = text.substring(1)
        val paras = ArrayList<DPara>()
        val rp = RProps()
        // Old .doc files written with Bijoy / SutonnyMJ are plain ASCII-looking text ("Avg evMvb wjR ...").
        // They only read correctly in that font, so use it when the text looks like Bijoy.
        if (path.lowercase().endsWith(".doc") && looksBijoy(text)) rp.font = "SutonnyMJ"
        for (line in text.split('\n')) {
            val l = line.trimEnd('\r')
            paras.add(DPara(if (l.isEmpty()) emptyList() else listOf(DRun(l, rp, null)), null, 0, false, 0))
        }
        val model = DocModel(listOf(paras), compact = true, titles = listOf(""))
        // a throw-away zip is not needed for plain text; give the book an empty-zip stand-in
        val tmp = java.io.File.createTempFile("txt", ".zip")
        java.util.zip.ZipOutputStream(tmp.outputStream()).use { it.putNextEntry(java.util.zip.ZipEntry("x")); it.closeEntry() }
        val book = EpubBook(path, ZipFile(tmp), "", listOf("text"), null)
        tmp.deleteOnExit()
        return Pair(model, book)
    }
}
