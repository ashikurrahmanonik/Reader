package com.reader.app.office

import android.graphics.Color
import android.graphics.Typeface
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ImageSpan
import android.text.style.MetricAffectingSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.UnderlineSpan
import android.util.Xml
import com.reader.app.FontStore
import com.reader.app.epub.EpubBook
import com.reader.app.epub.LazyImage
import com.reader.app.epub.resolvePath
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min

/** Applies one custom Typeface to a text run (and fakes bold / italic if the face lacks them). */
class FontSpan(private val tf: Typeface) : MetricAffectingSpan() {
    override fun updateDrawState(ds: TextPaint) = apply(ds)
    override fun updateMeasureState(ds: TextPaint) = apply(ds)
    private fun apply(ds: TextPaint) {
        val old = ds.typeface
        val oldStyle = old?.style ?: 0
        val fake = oldStyle and tf.style.inv()
        if (fake and Typeface.BOLD != 0) ds.isFakeBoldText = true
        if (fake and Typeface.ITALIC != 0) ds.textSkewX = -0.25f
        ds.typeface = tf
    }
}

class RProps {
    var font: String? = null
    var sizePt: Float? = null
    var bold: Boolean? = null
    var italic: Boolean? = null
    var underline: Boolean? = null
    var strike: Boolean? = null
    var color: Int? = null

    fun copyFrom(o: RProps) {
        o.font?.let { font = it }
        o.sizePt?.let { sizePt = it }
        o.bold?.let { bold = it }
        o.italic?.let { italic = it }
        o.underline?.let { underline = it }
        o.strike?.let { strike = it }
        o.color?.let { color = it }
    }
}

class DRun(val text: String, val props: RProps, val image: String?)

class DPara(
    val runs: List<DRun>,
    val align: String?,
    val heading: Int,
    val bullet: Boolean,
    val level: Int
)

private class StyleDef(
    val id: String,
    val type: String,
    val name: String,
    val basedOn: String?,
    val rp: RProps,
    val isDefault: Boolean
)

/** A text document turned into chapters of paragraphs (DOCX, PPTX, TXT). */
class DocModel(val chapters: List<List<DPara>>, val compact: Boolean, val titles: List<String>) {

    /** Builds the styled text of one chapter. [missing] collects legacy fonts we don't have. */
    fun buildSpans(
        index: Int,
        basePaint: TextPaint,
        density: Float,
        cw: Int,
        ch: Int,
        book: EpubBook,
        missing: MutableSet<String>
    ): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        val basePx = basePaint.textSize
        val faceCache = HashMap<String, Typeface>()

        for (para in chapters[index]) {
            val start = sb.length
            if (para.bullet) {
                for (i in 0 until para.level) sb.append("     ")
                sb.append("•  ")
            }
            for (run in para.runs) {
                if (run.image != null) {
                    val size = book.imageSize(run.image)
                    if (size != null) {
                        val iw = size.first
                        val ih = size.second
                        val scale = min(cw.toFloat() / iw, (ch * 0.92f) / ih)
                        val tw = max(1, (iw * min(scale, 1.6f)).toInt())
                        val th = max(1, (ih * min(scale, 1.6f)).toInt())
                        val d = LazyImage(book, run.image, tw)
                        d.setBounds(0, 0, tw, th)
                        val s = sb.length
                        sb.append('\uFFFC')
                        sb.setSpan(ImageSpan(d), s, s + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    continue
                }
                if (run.text.isEmpty()) continue
                val rp = run.props
                val s = sb.length
                sb.append(run.text)
                val e = sb.length

                var sizePt = rp.sizePt ?: 11f
                var bold = rp.bold == true
                if (para.heading > 0 && rp.sizePt == null) {
                    sizePt = when (para.heading) {
                        1 -> 11f * 1.7f
                        2 -> 11f * 1.45f
                        3 -> 11f * 1.25f
                        else -> 11f * 1.1f
                    }
                    bold = true
                }
                val italic = rp.italic == true
                val style = (if (bold) Typeface.BOLD else 0) or (if (italic) Typeface.ITALIC else 0)

                val fontName = rp.font
                var custom = FontStore.find(fontName)
                if (custom == null && FontStore.isMissingLegacy(fontName)) missing.add(fontName!!)
                val key = "${fontName ?: ""}|$style"
                val face = faceCache.getOrPut(key) {
                    Typeface.create(custom ?: basePaint.typeface ?: Typeface.DEFAULT, style)
                }
                sb.setSpan(FontSpan(face), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                val px = (basePx * sizePt / 11f).toInt().coerceIn(6, 400)
                sb.setSpan(AbsoluteSizeSpan(px, false), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                rp.color?.let { sb.setSpan(ForegroundColorSpan(it), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                if (rp.underline == true) sb.setSpan(UnderlineSpan(), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (rp.strike == true) sb.setSpan(StrikethroughSpan(), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            sb.append('\n')
            val align = when (para.align) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> null
            }
            if (align != null) {
                sb.setSpan(AlignmentSpan.Standard(align), start, sb.length, Spannable.SPAN_PARAGRAPH)
            }
            if (!compact) {
                val g = sb.length
                sb.append('\n')
                sb.setSpan(RelativeSizeSpan(0.4f), g, g + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        while (sb.isNotEmpty() && sb[sb.length - 1].isWhitespace()) sb.delete(sb.length - 1, sb.length)
        return sb
    }
}

object DocxParser {
    private fun newParser(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        try {
            p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
        } catch (_: Throwable) {
        }
        p.setInput(ByteArrayInputStream(bytes), null)
        return p
    }

    private fun attr(p: XmlPullParser, name: String): String? = p.getAttributeValue(null, name)

    private fun onOff(p: XmlPullParser): Boolean {
        val v = attr(p, "w:val") ?: return true
        return !(v == "0" || v == "false" || v == "off" || v == "none")
    }

    private fun applyRPrTag(p: XmlPullParser, rp: RProps) {
        when (p.name) {
            "w:rFonts" -> {
                val f = attr(p, "w:ascii") ?: attr(p, "w:hAnsi") ?: attr(p, "w:cs") ?: attr(p, "w:eastAsia")
                if (f != null) rp.font = f
            }
            "w:b" -> rp.bold = onOff(p)
            "w:i" -> rp.italic = onOff(p)
            "w:u" -> rp.underline = onOff(p)
            "w:strike" -> rp.strike = onOff(p)
            "w:sz" -> attr(p, "w:val")?.toFloatOrNull()?.let { rp.sizePt = it / 2f }
            "w:color" -> {
                val c = attr(p, "w:val")
                if (c != null && c.length == 6 && c != "auto") {
                    try {
                        rp.color = Color.parseColor("#$c")
                    } catch (_: Throwable) {
                    }
                }
            }
        }
    }

    private fun parseStyles(bytes: ByteArray?): Pair<RProps, Map<String, StyleDef>> {
        val defaults = RProps()
        val styles = LinkedHashMap<String, StyleDef>()
        if (bytes == null) return Pair(defaults, styles)
        try {
            val p = newParser(bytes)
            var inDocDefaults = false
            var sId: String? = null
            var sType = ""
            var sDefault = false
            var sName = ""
            var sBased: String? = null
            var sRp = RProps()
            var inRPr = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "w:docDefaults" -> inDocDefaults = true
                        "w:style" -> {
                            sId = attr(p, "w:styleId")
                            sType = attr(p, "w:type") ?: ""
                            sDefault = attr(p, "w:default") == "1"
                            sName = ""
                            sBased = null
                            sRp = RProps()
                        }
                        "w:name" -> if (sId != null) sName = attr(p, "w:val") ?: ""
                        "w:basedOn" -> if (sId != null) sBased = attr(p, "w:val")
                        "w:rPr" -> inRPr = true
                        else -> if (inRPr) applyRPrTag(p, if (inDocDefaults) defaults else sRp)
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "w:docDefaults" -> inDocDefaults = false
                        "w:rPr" -> inRPr = false
                        "w:style" -> {
                            val id = sId
                            if (id != null) styles[id] = StyleDef(id, sType, sName, sBased, sRp, sDefault)
                            sId = null
                        }
                    }
                }
                ev = p.next()
            }
        } catch (_: Throwable) {
        }
        return Pair(defaults, styles)
    }

    private fun chain(styles: Map<String, StyleDef>, id: String?): List<StyleDef> {
        val out = ArrayList<StyleDef>()
        var cur = id
        var guard = 0
        while (cur != null && guard < 8) {
            val s = styles[cur] ?: break
            out.add(0, s)
            cur = s.basedOn
            guard++
        }
        return out
    }

    private fun parseRels(bytes: ByteArray?): Map<String, String> {
        val map = HashMap<String, String>()
        if (bytes == null) return map
        try {
            val p = newParser(bytes)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                    val id = attr(p, "Id")
                    val target = attr(p, "Target")
                    if (id != null && target != null) map[id] = target
                }
                ev = p.next()
            }
        } catch (_: Throwable) {
        }
        return map
    }

    fun parse(path: String): Pair<DocModel, EpubBook> {
        val zip = ZipFile(path)
        try {
            fun read(name: String): ByteArray? {
                val e = zip.getEntry(name) ?: return null
                return zip.getInputStream(e).use { it.readBytes() }
            }

            val doc = read("word/document.xml") ?: throw IllegalStateException("not a docx")
            val (defaults, styles) = parseStyles(read("word/styles.xml"))
            val rels = parseRels(read("word/_rels/document.xml.rels"))
            val defaultPara = styles.values.firstOrNull { it.type == "paragraph" && it.isDefault }

            fun resolve(pStyle: String?, rStyle: String?, direct: RProps): RProps {
                val out = RProps()
                out.copyFrom(defaults)
                defaultPara?.let { out.copyFrom(it.rp) }
                for (s in chain(styles, pStyle)) out.copyFrom(s.rp)
                for (s in chain(styles, rStyle)) out.copyFrom(s.rp)
                out.copyFrom(direct)
                return out
            }

            val chapters = ArrayList<MutableList<DPara>>()
            var cur = ArrayList<DPara>()
            chapters.add(cur)

            val p = newParser(doc)
            var tblDepth = 0
            var cellRuns: ArrayList<DRun>? = null
            var rowCells: ArrayList<List<DRun>>? = null

            var inP = false
            var inPPr = false
            var pRuns = ArrayList<DRun>()
            var pAlign: String? = null
            var pStyle: String? = null
            var pList = false
            var pLevel = 0
            var breakBefore = false
            var breakAfter = false

            var inR = false
            var inRPr = false
            var rDirect = RProps()
            var rStyle: String? = null
            val rText = StringBuilder()
            var rImage: String? = null

            fun flushRun() {
                if (rText.isNotEmpty() || rImage != null) {
                    pRuns.add(DRun(rText.toString(), resolve(pStyle, rStyle, rDirect), rImage))
                }
                rText.setLength(0)
                rImage = null
            }

            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "w:tbl" -> tblDepth++
                        "w:tr" -> if (tblDepth == 1) rowCells = ArrayList()
                        "w:tc" -> cellRuns = ArrayList()
                        "w:p" -> {
                            inP = true
                            pRuns = ArrayList()
                            pAlign = null
                            pStyle = null
                            pList = false
                            pLevel = 0
                            breakBefore = false
                            breakAfter = false
                        }
                        "w:pPr" -> inPPr = true
                        "w:pStyle" -> if (inPPr) pStyle = attr(p, "w:val")
                        "w:jc" -> if (inPPr) pAlign = attr(p, "w:val")
                        "w:numPr" -> if (inPPr) pList = true
                        "w:ilvl" -> if (inPPr) pLevel = attr(p, "w:val")?.toIntOrNull() ?: 0
                        "w:pageBreakBefore" -> if (inPPr) breakBefore = true
                        "w:r" -> {
                            inR = true
                            rDirect = RProps()
                            rStyle = null
                            rText.setLength(0)
                            rImage = null
                        }
                        "w:rPr" -> if (inR && !inPPr) inRPr = true
                        "w:rStyle" -> if (inRPr) rStyle = attr(p, "w:val")
                        "w:t" -> if (inR) {
                            try {
                                rText.append(p.nextText())
                            } catch (_: Throwable) {
                            }
                        }
                        "w:tab" -> if (inR && !inPPr) rText.append("    ")
                        "w:br" -> if (inR) {
                            if (attr(p, "w:type") == "page") breakAfter = true else rText.append('\n')
                        }
                        "w:cr" -> if (inR) rText.append('\n')
                        "w:noBreakHyphen" -> if (inR) rText.append('-')
                        "a:blip" -> if (inR) {
                            val rid = attr(p, "r:embed")
                            val target = if (rid != null) rels[rid] else null
                            if (target != null) {
                                flushRun()
                                rImage = resolvePath("word", target)
                            }
                        }
                        else -> if (inRPr) applyRPrTag(p, rDirect)
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "w:pPr" -> inPPr = false
                        "w:rPr" -> inRPr = false
                        "w:r" -> {
                            flushRun()
                            inR = false
                            inRPr = false
                        }
                        "w:p" -> {
                            inP = false
                            val styleName = (styles[pStyle ?: ""]?.name ?: pStyle ?: "").lowercase()
                            var heading = 0
                            if (styleName.startsWith("heading")) {
                                heading = styleName.filter { it.isDigit() }.toIntOrNull() ?: 1
                            } else if (styleName == "title") {
                                heading = 1
                            }
                            if (tblDepth > 0) {
                                val cr = cellRuns
                                if (cr != null) {
                                    cr.addAll(pRuns)
                                    cr.add(DRun(" ", RProps(), null))
                                }
                            } else {
                                if (breakBefore && cur.isNotEmpty()) {
                                    cur = ArrayList()
                                    chapters.add(cur)
                                }
                                cur.add(DPara(pRuns, pAlign, heading, pList, pLevel))
                                if (breakAfter) {
                                    cur = ArrayList()
                                    chapters.add(cur)
                                }
                            }
                        }
                        "w:tc" -> {
                            val cr = cellRuns
                            val rc = rowCells
                            if (cr != null && rc != null) rc.add(cr)
                            cellRuns = null
                        }
                        "w:tr" -> {
                            val rc = rowCells
                            if (tblDepth == 1 && rc != null) {
                                val runs = ArrayList<DRun>()
                                for ((i, cell) in rc.withIndex()) {
                                    if (i > 0) runs.add(DRun("  │  ", RProps(), null))
                                    runs.addAll(cell)
                                }
                                cur.add(DPara(runs, null, 0, false, 0))
                            }
                            rowCells = null
                        }
                        "w:tbl" -> if (tblDepth > 0) tblDepth--
                    }
                }
                ev = p.next()
            }

            val nonEmpty = chapters.filter { it.isNotEmpty() }
            val finalChapters = if (nonEmpty.isEmpty()) listOf(listOf(DPara(emptyList(), null, 0, false, 0))) else nonEmpty
            val titles = finalChapters.indices.map { "" }
            val model = DocModel(finalChapters, compact = false, titles = titles)
            val book = EpubBook(path, zip, "", List(finalChapters.size) { "chapter$it" }, null)
            return Pair(model, book)
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }
}

object PptxParser {
    fun parse(path: String): Pair<DocModel, EpubBook> {
        val zip = ZipFile(path)
        try {
            val names = ArrayList<Pair<Int, String>>()
            val en = zip.entries()
            val rx = Regex("^ppt/slides/slide(\\d+)\\.xml$")
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                val m = rx.find(e.name)
                if (m != null) names.add(Pair(m.groupValues[1].toInt(), e.name))
            }
            names.sortBy { it.first }
            if (names.isEmpty()) throw IllegalStateException("no slides")

            val chapters = ArrayList<List<DPara>>()
            val titles = ArrayList<String>()
            for ((num, name) in names) {
                val bytes = zip.getInputStream(zip.getEntry(name)).use { it.readBytes() }
                val paras = ArrayList<DPara>()
                paras.add(DPara(listOf(DRun("Slide $num", RProps().also { it.sizePt = 9f; it.color = Color.GRAY }, null)), null, 0, false, 0))
                val p = Xml.newPullParser()
                try {
                    p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
                } catch (_: Throwable) {
                }
                p.setInput(ByteArrayInputStream(bytes), null)
                var isTitle = false
                var inPara = false
                val text = StringBuilder()
                var firstTitle = ""
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "p:sp" -> isTitle = false
                            "p:ph" -> {
                                val t = p.getAttributeValue(null, "type") ?: ""
                                if (t.contains("title", ignoreCase = true)) isTitle = true
                            }
                            "a:p" -> {
                                inPara = true
                                text.setLength(0)
                            }
                            "a:t" -> if (inPara) {
                                try {
                                    text.append(p.nextText())
                                } catch (_: Throwable) {
                                }
                            }
                            "a:br" -> if (inPara) text.append('\n')
                        }
                    } else if (ev == XmlPullParser.END_TAG && p.name == "a:p") {
                        inPara = false
                        val s = text.toString()
                        if (s.isNotBlank()) {
                            if (isTitle && firstTitle.isEmpty()) firstTitle = s.trim()
                            val rp = RProps()
                            if (isTitle) {
                                rp.sizePt = 20f
                                rp.bold = true
                            }
                            paras.add(DPara(listOf(DRun(s, rp, null)), null, 0, !isTitle, 0))
                        }
                    }
                    ev = p.next()
                }
                chapters.add(paras)
                titles.add(if (firstTitle.isNotEmpty()) firstTitle else "Slide $num")
            }
            val model = DocModel(chapters, compact = false, titles = titles)
            val book = EpubBook(path, zip, "", List(chapters.size) { "slide$it" }, null)
            return Pair(model, book)
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }
}

object TxtParser {
    fun parse(path: String): Pair<DocModel, EpubBook> {
        val bytes = java.io.File(path).readBytes()
        var text = String(bytes, Charsets.UTF_8)
        if (text.startsWith("\uFEFF")) text = text.substring(1)
        val paras = ArrayList<DPara>()
        val rp = RProps()
        for (line in text.split('\n')) {
            val l = line.trimEnd('\r')
            paras.add(DPara(if (l.isEmpty()) emptyList() else listOf(DRun(l, rp, null)), null, 0, false, 0))
        }
        val model = DocModel(listOf(paras), compact = true, titles = listOf(""))
        // a throw-away zip is not needed for plain text; give the book an empty-zip stand-in
        val tmp = java.io.File.createTempFile("txt", ".zip")
        java.util.zip.ZipOutputStream(tmp.outputStream()).use { it.putNextEntry(java.util.zip.ZipEntry("x")); it.closeEntry() }
        val book = EpubBook(path, ZipFile(tmp), "", listOf("text"), null)
        tmp.deleteOnExit()
        return Pair(model, book)
    }
}
