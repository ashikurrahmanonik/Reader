package com.reader.app.office

import android.graphics.Canvas
import android.graphics.Paint
import android.text.StaticLayout
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream

/** Small XML tree used by the Word / PowerPoint parsers. Only <t> text is kept. */
internal class XN(val name: String, val attrs: Map<String, String>) {
    val kids = ArrayList<XN>(4)
    var text: StringBuilder? = null
    val ln: String = name.substringAfter(':')

    fun a(local: String): String? {
        for ((k, v) in attrs) if (k == local || k.substringAfter(':') == local) return v
        return null
    }

    fun kid(local: String): XN? {
        for (k in kids) if (k.ln == local) return k
        return null
    }

    fun kidsNamed(local: String): List<XN> {
        val out = ArrayList<XN>()
        for (k in kids) if (k.ln == local) out.add(k)
        return out
    }

    fun find(local: String): XN? {
        if (ln == local) return this
        for (k in kids) {
            val r = k.find(local)
            if (r != null) return r
        }
        return null
    }
}

internal fun parseXml(bytes: ByteArray): XN {
    val p = Xml.newPullParser()
    try {
        p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
    } catch (_: Throwable) {
    }
    p.setInput(ByteArrayInputStream(bytes), null)
    val root = XN("#root", emptyMap())
    val stack = ArrayList<XN>()
    stack.add(root)
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        if (ev == XmlPullParser.START_TAG) {
            val attrs = HashMap<String, String>()
            for (i in 0 until p.attributeCount) attrs[p.getAttributeName(i)] = p.getAttributeValue(i)
            val n = XN(p.name ?: "", attrs)
            stack[stack.size - 1].kids.add(n)
            stack.add(n)
        } else if (ev == XmlPullParser.TEXT || ev == XmlPullParser.IGNORABLE_WHITESPACE) {
            val top = stack[stack.size - 1]
            if (top.ln == "t" || top.ln == "instrText" || top.ln == "v") {
                val sb = top.text ?: StringBuilder().also { top.text = it }
                sb.append(p.text)
            }
        } else if (ev == XmlPullParser.END_TAG) {
            if (stack.size > 1) stack.removeAt(stack.size - 1)
        }
        ev = p.next()
    }
    return root
}

/** A document made of fixed-size pages (Word pages, PowerPoint slides) that draws itself with vector ops. */
interface FixedDoc {
    val pageCount: Int
    /** page size in pixels at zoom 1 */
    val pageW: Float
    val pageH: Float
    val missingFonts: Set<String>
    /** (title, page index) pairs for the contents list; may be empty */
    val outline: List<Pair<String, Int>>
    fun drawPage(c: Canvas, index: Int)
}

abstract class Draw {
    abstract fun draw(c: Canvas)
}

class RectDraw(val l: Float, val t: Float, val r: Float, val b: Float, val color: Int) : Draw() {
    private val paint = Paint().apply { this.color = this@RectDraw.color }
    override fun draw(c: Canvas) {
        c.drawRect(l, t, r, b, paint)
    }
}

class LineDraw(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val w: Float, val color: Int) : Draw() {
    private val paint = Paint().apply {
        this.color = this@LineDraw.color
        strokeWidth = this@LineDraw.w
    }
    override fun draw(c: Canvas) {
        c.drawLine(x1, y1, x2, y2, paint)
    }
}

class TextDraw(val text: String, val x: Float, val y: Float, val paint: android.text.TextPaint) : Draw() {
    override fun draw(c: Canvas) {
        c.drawText(text, x, y, paint)
    }
}

/** Lines [from, to) of a laid-out paragraph, drawn with its top-left at (x, y). */
class ParaDraw(
    val layout: StaticLayout,
    val from: Int,
    val to: Int,
    val x: Float,
    val y: Float
) : Draw() {
    override fun draw(c: Canvas) {
        val top = layout.getLineTop(from)
        val bottom = layout.getLineBottom(to - 1)
        c.save()
        c.clipRect(x - 8f, y - 4f, x + layout.width + 8f, y + (bottom - top) + 6f)
        c.translate(x, y - top)
        layout.draw(c)
        c.restore()
    }
}

class ImageDraw(
    val provider: () -> android.graphics.Bitmap?,
    val l: Float, val t: Float, val r: Float, val b: Float
) : Draw() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dst = android.graphics.RectF()
    override fun draw(c: Canvas) {
        val bmp = provider() ?: return
        dst.set(l, t, r, b)
        c.drawBitmap(bmp, null, dst, paint)
    }
}
