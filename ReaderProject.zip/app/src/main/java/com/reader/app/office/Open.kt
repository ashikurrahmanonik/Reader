package com.reader.app.office

import com.reader.app.data.Kind
import com.reader.app.data.kindOf
import com.reader.app.epub.EpubBook
import com.reader.app.epub.EpubParser
import com.reader.app.epub.TocItem

sealed interface OpenedDoc

/** Text-like documents that are re-flowed to the screen (EPUB, DOCX, PPTX, TXT). */
class OpenedReflow(val book: EpubBook, val model: DocModel?) : OpenedDoc

/** Spreadsheets (XLSX, CSV). */
class OpenedSheets(val sheets: List<SheetData>) : OpenedDoc

object OfficeOpen {
    fun open(path: String): OpenedDoc {
        return when (kindOf(path)) {
            Kind.EPUB -> OpenedReflow(EpubParser.open(path), null)
            Kind.DOCX -> {
                val (m, b) = DocxParser.parse(path)
                OpenedReflow(b, m)
            }
            Kind.PPTX -> {
                val (m, b) = PptxParser.parse(path)
                if (m.titles.any { it.isNotBlank() }) {
                    b.toc = m.titles.mapIndexed { i, t -> TocItem(t, i) }
                }
                OpenedReflow(b, m)
            }
            Kind.TXT -> {
                val (m, b) = TxtParser.parse(path)
                OpenedReflow(b, m)
            }
            Kind.XLSX -> OpenedSheets(SheetParser.parseXlsx(path))
            Kind.CSV -> OpenedSheets(SheetParser.parseCsv(path))
            Kind.PDF -> throw IllegalArgumentException("pdf")
        }
    }
}
