package com.reader.app.office

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.TextPaint
import android.text.TextUtils
import android.util.Xml
import com.reader.app.epub.resolvePath
import com.reader.app.pdf.BookDoc
import com.reader.app.pdf.TocEntry
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.math.BigDecimal
import java.math.MathContext
import java.util.zip.ZipFile
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

class SheetData(val name: String, val rows: List<Array<String>>, val cols: Int)

object SheetParser {
    private fun parser(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        try {
            p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
        } catch (_: Throwable) {
        }
        p.setInput(ByteArrayInputStream(bytes), null)
        return p
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (c in ref) {
            if (c in 'A'..'Z') n = n * 26 + (c - 'A' + 1)
            else if (c in 'a'..'z') n = n * 26 + (c - 'a' + 1)
            else break
        }
        return n - 1
    }

    private fun fmtNumber(v: String): String {
        return try {
            val bd = BigDecimal(v).round(MathContext(12)).stripTrailingZeros()
            val s = bd.toPlainString()
            s
        } catch (e: Throwable) {
            v
        }
    }

    private fun fmtDate(serial: Double): String {
        val days = serial.toLong()
        // Excel epoch 1899-12-30
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        cal.clear()
        cal.set(1899, 11, 30)
        cal.add(java.util.Calendar.DAY_OF_YEAR, days.toInt())
        val y = cal.get(java.util.Calendar.YEAR)
        val m = cal.get(java.util.Calendar.MONTH) + 1
        val d = cal.get(java.util.Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(y, m, d)
    }

    fun parseXlsx(path: String): List<SheetData> {
        val zip = ZipFile(path)
        try {
            fun read(name: String): ByteArray? {
                val e = zip.getEntry(name) ?: return null
                return zip.getInputStream(e).use { it.readBytes() }
            }

            // shared strings
            val shared = ArrayList<String>()
            read("xl/sharedStrings.xml")?.let { b ->
                val p = parser(b)
                var inSi = false
                val sb = StringBuilder()
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        if (p.name == "si") {
                            inSi = true
                            sb.setLength(0)
                        } else if (p.name == "t" && inSi) {
                            try {
                                sb.append(p.nextText())
                            } catch (_: Throwable) {
                            }
                        }
                    } else if (ev == XmlPullParser.END_TAG && p.name == "si") {
                        inSi = false
                        shared.add(sb.toString())
                    }
                    ev = p.next()
                }
            }

            // which cell styles are dates
            val dateStyles = HashSet<Int>()
            read("xl/styles.xml")?.let { b ->
                val p = parser(b)
                val customDate = HashSet<Int>()
                var inXfs = false
                var xfIndex = 0
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "numFmt" -> {
                                val id = p.getAttributeValue(null, "numFmtId")?.toIntOrNull()
                                val code = (p.getAttributeValue(null, "formatCode") ?: "").lowercase()
                                if (id != null && (code.contains("yy") || code.contains("dd") || code.contains("mmm")) &&
                                    !code.contains("0.0")
                                ) customDate.add(id)
                            }
                            "cellXfs" -> {
                                inXfs = true
                                xfIndex = 0
                            }
                            "xf" -> if (inXfs) {
                                val id = p.getAttributeValue(null, "numFmtId")?.toIntOrNull() ?: 0
                                if ((id in 14..22) || (id in 45..47) || id in customDate) dateStyles.add(xfIndex)
                                xfIndex++
                            }
                        }
                    } else if (ev == XmlPullParser.END_TAG && p.name == "cellXfs") {
                        inXfs = false
                    }
                    ev = p.next()
                }
            }

            // sheet list + targets
            val rels = HashMap<String, String>()
            read("xl/_rels/workbook.xml.rels")?.let { b ->
                val p = parser(b)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                        val id = p.getAttributeValue(null, "Id")
                        val t = p.getAttributeValue(null, "Target")
                        if (id != null && t != null) rels[id] = t
                    }
                    ev = p.next()
                }
            }
            val sheetRefs = ArrayList<Pair<String, String>>()
            val wb = read("xl/workbook.xml") ?: throw IllegalStateException("not an xlsx")
            run {
                val p = parser(wb)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                        val name = p.getAttributeValue(null, "name") ?: "Sheet"
                        val rid = p.getAttributeValue(null, "r:id")
                        val target = if (rid != null) rels[rid] else null
                        if (target != null) {
                            val entry = if (target.startsWith("/")) target.substring(1) else resolvePath("xl", target)
                            sheetRefs.add(Pair(name, entry))
                        }
                    }
                    ev = p.next()
                }
            }

            val out = ArrayList<SheetData>()
            for ((name, entry) in sheetRefs) {
                val bytes = read(entry) ?: continue
                val rows = ArrayList<Array<String>>()
                var maxCols = 0
                val p = parser(bytes)
                var curRow = ArrayList<String>()
                var rowNum = 0
                var cellCol = 0
                var cellType = ""
                var cellStyle = 0
                var inV = false
                var value = StringBuilder()
                var inIs = false
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "row" -> {
                                curRow = ArrayList()
                                val r = p.getAttributeValue(null, "r")?.toIntOrNull()
                                if (r != null) {
                                    // keep blank rows between data rows
                                    while (rows.size < r - 1 && rows.size < 20000) rows.add(emptyArray())
                                }
                                rowNum++
                            }
                            "c" -> {
                                val ref = p.getAttributeValue(null, "r") ?: ""
                                cellCol = if (ref.isNotEmpty()) colIndex(ref) else curRow.size
                                cellType = p.getAttributeValue(null, "t") ?: ""
                                cellStyle = p.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                                value = StringBuilder()
                                inV = false
                                inIs = false
                            }
                            "v" -> {
                                inV = true
                                try {
                                    value.append(p.nextText())
                                } catch (_: Throwable) {
                                }
                                inV = false
                            }
                            "is" -> inIs = true
                            "t" -> if (inIs) {
                                try {
                                    value.append(p.nextText())
                                } catch (_: Throwable) {
                                }
                            }
                        }
                    } else if (ev == XmlPullParser.END_TAG) {
                        when (p.name) {
                            "is" -> inIs = false
                            "c" -> {
                                val raw = value.toString()
                                val text = when (cellType) {
                                    "s" -> raw.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                                    "b" -> if (raw == "1") "TRUE" else "FALSE"
                                    "str", "inlineStr", "e" -> raw
                                    else -> {
                                        if (raw.isEmpty()) ""
                                        else if (cellStyle in dateStyles && raw.toDoubleOrNull() != null) fmtDate(raw.toDouble())
                                        else fmtNumber(raw)
                                    }
                                }
                                if (cellCol in 0..300) {
                                    while (curRow.size < cellCol) curRow.add("")
                                    if (curRow.size == cellCol) curRow.add(text) else curRow[cellCol] = text
                                }
                            }
                            "row" -> {
                                maxCols = max(maxCols, curRow.size)
                                if (rows.size < 20000) rows.add(curRow.toTypedArray())
                            }
                        }
                    }
                    ev = p.next()
                }
                out.add(SheetData(name, rows, max(1, maxCols)))
            }
            if (out.isEmpty()) throw IllegalStateException("no sheets")
            return out
        } finally {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
        }
    }

    fun parseCsv(path: String): List<SheetData> {
        val bytes = java.io.File(path).readBytes()
        var text = String(bytes, Charsets.UTF_8)
        if (text.startsWith("\uFEFF")) text = text.substring(1)
        val firstLine = text.lineSequence().firstOrNull() ?: ""
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } } ?: ','
        val rows = ArrayList<Array<String>>()
        var maxCols = 0
        for (line in text.lineSequence()) {
            if (rows.size >= 20000) break
            val cells = ArrayList<String>()
            val sb = StringBuilder()
            var q = false
            var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (q) {
                    if (ch == '"') {
                        if (i + 1 < line.length && line[i + 1] == '"') {
                            sb.append('"')
                            i++
                        } else q = false
                    } else sb.append(ch)
                } else if (ch == '"') q = true
                else if (ch == delim) {
                    cells.add(sb.toString())
                    sb.setLength(0)
                } else sb.append(ch)
                i++
            }
            cells.add(sb.toString())
            maxCols = max(maxCols, cells.size)
            rows.add(cells.toTypedArray())
        }
        return listOf(SheetData("CSV", rows, max(1, min(maxCols, 300))))
    }
}

/** Spreadsheet pages: a grid with row numbers and column letters; wide sheets continue on further pages. */
class SheetDoc(
    private val sheets: List<SheetData>,
    private val w: Int,
    private val h: Int,
    density: Float,
    fontSp: Int,
    private val title: String
) : BookDoc {
    private class Layout(
        val sheet: SheetData,
        val colW: FloatArray,
        val bands: List<IntRange>,
        val rowsPerPage: Int,
        val chunks: Int
    )

    private class PageDef(val sheet: Int, val band: Int, val chunk: Int)

    private val lock = Any()
    private val marginH = 8f * density
    private val marginTop = 40f * density
    private val marginBottom = 36f * density
    private val textPx = max(9f * density, fontSp * 0.78f * density)
    private val pad = 6f * density
    private val rowH = textPx * 2.0f
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 30, 36)
        textSize = textPx
    }
    private val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(70, 78, 96)
        textSize = textPx
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val foot = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(140, 146, 160)
        textSize = 11f * density
        textAlign = Paint.Align.CENTER
    }
    private val grid = Paint().apply {
        color = Color.rgb(214, 219, 228)
        strokeWidth = max(1f, density * 0.8f)
    }
    private val fill = Paint()
    private val rowNumW = text.measureText("99999") + pad
    private val layouts = ArrayList<Layout>()
    private val pages = ArrayList<PageDef>()
    private val firstPage = IntArray(sheets.size)

    init {
        val availW = w - 2 * marginH - rowNumW
        val availH = h - marginTop - marginBottom - rowH
        for ((si, sh) in sheets.withIndex()) {
            val colW = FloatArray(sh.cols)
            for (c in 0 until sh.cols) {
                var mx = head.measureText(colLetter(c))
                val limit = min(sh.rows.size, 300)
                for (r in 0 until limit) {
                    val row = sh.rows[r]
                    if (c < row.size) mx = max(mx, text.measureText(row[c].take(60)))
                }
                colW[c] = (mx + 2 * pad).coerceIn(48f * density, min(240f * density, availW))
            }
            val bands = ArrayList<IntRange>()
            var start = 0
            var acc = 0f
            for (c in 0 until sh.cols) {
                if (acc + colW[c] > availW && c > start) {
                    bands.add(start until c)
                    start = c
                    acc = 0f
                }
                acc += colW[c]
            }
            bands.add(start until sh.cols)
            val rpp = max(1, (availH / rowH).toInt())
            val chunks = max(1, ceil(sh.rows.size.toFloat() / rpp).toInt())
            layouts.add(Layout(sh, colW, bands, rpp, chunks))
            firstPage[si] = pages.size
            for (ch in 0 until chunks) for (b in bands.indices) pages.add(PageDef(si, b, ch))
        }
    }

    override val pageCount: Int get() = pages.size
    override val supportsZoom: Boolean get() = true

    private fun colLetter(i: Int): String {
        var n = i
        val sb = StringBuilder()
        do {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    private fun drawInto(c: Canvas, index: Int) {
        val pd = pages[index]
        val lay = layouts[pd.sheet]
        val sh = lay.sheet
        val band = lay.bands[pd.band]
        val rowStart = pd.chunk * lay.rowsPerPage
        val rowEnd = min(sh.rows.size, rowStart + lay.rowsPerPage)
        val x0 = marginH
        val y0 = marginTop

        var bandW = 0f
        for (col in band) bandW += lay.colW[col]
        val totalW = rowNumW + bandW

        // header row
        fill.color = Color.rgb(238, 241, 247)
        c.drawRect(x0, y0, x0 + totalW, y0 + rowH, fill)
        var x = x0 + rowNumW
        for (col in band) {
            c.drawText(colLetter(col), x + lay.colW[col] / 2f, y0 + rowH / 2f + textPx * 0.35f, head)
            x += lay.colW[col]
        }
        // rows
        for (r in rowStart until rowEnd) {
            val top = y0 + rowH * (r - rowStart + 1)
            if ((r - rowStart) % 2 == 1) {
                fill.color = Color.rgb(248, 249, 252)
                c.drawRect(x0 + rowNumW, top, x0 + totalW, top + rowH, fill)
            }
            fill.color = Color.rgb(238, 241, 247)
            c.drawRect(x0, top, x0 + rowNumW, top + rowH, fill)
            val numStr = (r + 1).toString()
            c.drawText(numStr, x0 + rowNumW / 2f - text.measureText(numStr) / 2f, top + rowH / 2f + textPx * 0.35f, text)
            val row = sh.rows[r]
            var cx = x0 + rowNumW
            for (col in band) {
                val cell = if (col < row.size) row[col] else ""
                if (cell.isNotEmpty()) {
                    val avail = lay.colW[col] - 2 * pad
                    val shown = TextUtils.ellipsize(cell.replace('\n', ' '), text, avail, TextUtils.TruncateAt.END).toString()
                    val numeric = cell.toDoubleOrNull() != null
                    val tx = if (numeric) cx + lay.colW[col] - pad - text.measureText(shown) else cx + pad
                    c.drawText(shown, tx, top + rowH / 2f + textPx * 0.35f, text)
                }
                cx += lay.colW[col]
            }
        }
        // grid
        val bottom = y0 + rowH * (rowEnd - rowStart + 1)
        var gx = x0
        c.drawLine(gx, y0, gx, bottom, grid)
        gx += rowNumW
        c.drawLine(gx, y0, gx, bottom, grid)
        for (col in band) {
            gx += lay.colW[col]
            c.drawLine(gx, y0, gx, bottom, grid)
        }
        for (i in 0..(rowEnd - rowStart + 1)) {
            val gy = y0 + rowH * i
            c.drawLine(x0, gy, x0 + totalW, gy, grid)
        }
        val label = "${sh.name}  ·  ${colLetter(band.first)}–${colLetter(band.last)}  ·  ${rowStart + 1}–$rowEnd"
        c.drawText(label, w / 2f, h - 14f * 2f, foot)
    }

    override fun renderPage(index: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(this.w, this.h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        if (index in pages.indices) synchronized(lock) { drawInto(Canvas(bmp), index) }
        return bmp
    }

    override fun renderRegion(index: Int, w: Int, h: Int, zoom: Float, tx: Float, ty: Float): Bitmap? {
        val bmp = Bitmap.createBitmap(this.w, this.h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        if (index in pages.indices) synchronized(lock) {
            val c = Canvas(bmp)
            c.translate(tx, ty)
            c.scale(zoom, zoom)
            drawInto(c, index)
        }
        return bmp
    }

    override fun toc(): List<TocEntry> =
        if (sheets.size > 1) sheets.indices.map { TocEntry(sheets[it].name, firstPage[it]) } else emptyList()

    override fun close() {}
}
