package com.reader.app.office

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StrikethroughSpan
import android.text.style.UnderlineSpan
import com.reader.app.FontStore
import com.reader.app.epub.EpubBook
import com.reader.app.epub.EpubImages
import com.reader.app.epub.resolvePath
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val EMU_PT = 12700f

internal class SlideTheme(val colors: Map<String, Int>, val major: String?, val minor: String?)

/** Wraps shape drawing with a rotation / flip about the shape's centre. */
private class XformDraw(
    val kids: List<Draw>, val rot: Float, val cx: Float, val cy: Float, val flipH: Boolean, val flipV: Boolean
) : Draw() {
    override fun draw(c: Canvas) {
        c.save()
        if (rot != 0f) c.rotate(rot, cx, cy)
        if (flipH || flipV) c.scale(if (flipH) -1f else 1f, if (flipV) -1f else 1f, cx, cy)
        for (k in kids) k.draw(c)
        c.restore()
    }
}

private class ShapeDraw(
    val shape: Int, // 0 rect, 1 ellipse, 2 round rect
    val l: Float, val t: Float, val r: Float, val b: Float,
    val fill: Int?, val line: Int?, val lineW: Float, val radius: Float
) : Draw() {
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    override fun draw(c: Canvas) {
        rect.set(l, t, r, b)
        if (fill != null) {
            fp.color = fill
            when (shape) {
                1 -> c.drawOval(rect, fp)
                2 -> c.drawRoundRect(rect, radius, radius, fp)
                else -> c.drawRect(rect, fp)
            }
        }
        if (line != null) {
            lp.color = line
            lp.strokeWidth = max(1f, lineW)
            when (shape) {
                1 -> c.drawOval(rect, lp)
                2 -> c.drawRoundRect(rect, radius, radius, lp)
                else -> c.drawRect(rect, lp)
            }
        }
    }
}

class SlideDoc internal constructor(
    private val pages: List<List<Draw>>,
    override val pageW: Float,
    override val pageH: Float,
    override val missingFonts: Set<String>,
    override val outline: List<Pair<String, Int>>,
    private val zip: ZipFile
) : FixedDoc {
    override val pageCount: Int get() = pages.size

    override fun drawPage(c: Canvas, index: Int) {
        if (index !in pages.indices) return
        for (d in pages[index]) d.draw(c)
    }

    fun close() {
        try {
            zip.close()
        } catch (_: Throwable) {
        }
    }
}

private class Xf(val sx: Float, val sy: Float, val tx: Float, val ty: Float) // child -> slide px

private class SB(
    val zip: ZipFile,
    val theme: SlideTheme,
    val clrMap: Map<String, String>,
    val s: Float, // px per EMU
    val missing: MutableSet<String>,
    val cache: HashMap<String, XN?> = HashMap(),
    val relCache: HashMap<String, Map<String, String>> = HashMap()
) {

    fun read(name: String): ByteArray? {
        val e = zip.getEntry(name) ?: return null
        return try {
            zip.getInputStream(e).use { it.readBytes() }
        } catch (_: Throwable) {
            null
        }
    }

    fun tree(name: String): XN? = cache.getOrPut(name) {
        val b = read(name)
        if (b == null) null else try {
            parseXml(b)
        } catch (_: Throwable) {
            null
        }
    }

    fun rels(entry: String): Map<String, String> = relCache.getOrPut(entry) {
        val relName = entry.substringBeforeLast('/') + "/_rels/" + entry.substringAfterLast('/') + ".rels"
        val m = HashMap<String, String>()
        tree(relName)?.kids?.firstOrNull()?.let { root ->
            for (r in root.kids) {
                val id = r.a("Id")
                val t = r.a("Target")
                if (id != null && t != null) m[id] = resolvePath(entry.substringBeforeLast('/', ""), t)
            }
        }
        m
    }

    // ---- colours

    private fun hsl(c: Int): FloatArray {
        val hsv = FloatArray(3)
        val r = Color.red(c) / 255f
        val g = Color.green(c) / 255f
        val b = Color.blue(c) / 255f
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val l = (mx + mn) / 2f
        val d = mx - mn
        var h = 0f
        var sat = 0f
        if (d > 0f) {
            sat = d / (1f - abs(2f * l - 1f))
            h = when (mx) {
                r -> ((g - b) / d) % 6f
                g -> (b - r) / d + 2f
                else -> (r - g) / d + 4f
            } * 60f
            if (h < 0) h += 360f
        }
        hsv[0] = h
        hsv[1] = sat
        hsv[2] = l
        return hsv
    }

    private fun fromHsl(h: Float, sat: Float, l: Float, a: Int): Int {
        val c = (1f - abs(2f * l - 1f)) * sat
        val x = c * (1f - abs((h / 60f) % 2f - 1f))
        val m = l - c / 2f
        val (r, g, b) = when {
            h < 60f -> Triple(c, x, 0f)
            h < 120f -> Triple(x, c, 0f)
            h < 180f -> Triple(0f, c, x)
            h < 240f -> Triple(0f, x, c)
            h < 300f -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        return Color.argb(a, ((r + m) * 255f).toInt().coerceIn(0, 255), ((g + m) * 255f).toInt().coerceIn(0, 255), ((b + m) * 255f).toInt().coerceIn(0, 255))
    }

    fun color(n: XN?): Int? {
        if (n == null) return null
        var base: Int? = null
        when (n.ln) {
            "srgbClr" -> base = hexColor(n.a("val"))
            "sysClr" -> base = hexColor(n.a("lastClr")) ?: if (n.a("val") == "window") Color.WHITE else Color.BLACK
            "schemeClr" -> {
                val v = n.a("val") ?: "tx1"
                val mapped = clrMap[v] ?: v
                base = theme.colors[mapped] ?: theme.colors[v]
            }
            "prstClr" -> base = when (n.a("val")) {
                "black" -> Color.BLACK
                "white" -> Color.WHITE
                "red" -> Color.RED
                "green" -> Color.GREEN
                "blue" -> Color.BLUE
                "yellow" -> Color.YELLOW
                "gray", "grey" -> Color.GRAY
                else -> Color.BLACK
            }
        }
        var c = base ?: return null
        var alpha = 255
        for (m in n.kids) {
            val v = m.a("val")?.toFloatOrNull() ?: continue
            when (m.ln) {
                "lumMod" -> {
                    val h = hsl(c)
                    c = fromHsl(h[0], h[1], (h[2] * v / 100000f).coerceIn(0f, 1f), 255)
                }
                "lumOff" -> {
                    val h = hsl(c)
                    c = fromHsl(h[0], h[1], (h[2] + v / 100000f).coerceIn(0f, 1f), 255)
                }
                "tint" -> c = mix(c, Color.WHITE, 1f - v / 100000f)
                "shade" -> c = mix(c, Color.BLACK, 1f - v / 100000f)
                "alpha" -> alpha = (255 * v / 100000f).toInt().coerceIn(0, 255)
            }
        }
        return Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** First colour of a fill element (solid / gradient). null = no fill specified. */
    fun fillOf(spPr: XN?): Int? {
        if (spPr == null) return null
        for (k in spPr.kids) {
            when (k.ln) {
                "solidFill" -> return color(k.kids.firstOrNull())
                "gradFill" -> return color(k.find("gs")?.kids?.firstOrNull())
                "noFill" -> return 0
            }
        }
        return null
    }
}

internal object SlidesBuilder {
    private fun parseTheme(sb: ByteArray?): SlideTheme {
        val colors = HashMap<String, Int>()
        var major: String? = null
        var minor: String? = null
        if (sb != null) {
            try {
                val root = parseXml(sb)
                val cs = root.find("clrScheme")
                if (cs != null) {
                    for (k in cs.kids) {
                        val c = k.kids.firstOrNull() ?: continue
                        val v = if (c.ln == "sysClr") (hexColor(c.a("lastClr")) ?: Color.BLACK) else hexColor(c.a("val"))
                        if (v != null) colors[k.ln] = v
                    }
                }
                major = root.find("majorFont")?.kid("latin")?.a("typeface")
                minor = root.find("minorFont")?.kid("latin")?.a("typeface")
            } catch (_: Throwable) {
            }
        }
        return SlideTheme(colors, major, minor)
    }

    private fun placeholder(tree: XN?, type: String?, idx: String?): XN? {
        val sp = tree?.find("spTree") ?: return null
        for (shape in sp.kids) {
            if (shape.ln != "sp") continue
            val ph = shape.kid("nvSpPr")?.kid("nvPr")?.kid("ph") ?: continue
            if (idx != null && ph.a("idx") == idx) return shape
        }
        for (shape in sp.kids) {
            if (shape.ln != "sp") continue
            val ph = shape.kid("nvSpPr")?.kid("nvPr")?.kid("ph") ?: continue
            val t = ph.a("type") ?: "body"
            val want = type ?: "body"
            if (t == want || (want == "ctrTitle" && t == "title") || (want == "subTitle" && t == "body")) return shape
        }
        return null
    }

    suspend fun build(path: String, viewW: Float, onProgress: (Float) -> Unit): SlideDoc {
        val zip = ZipFile(path)
        try {
            fun readRaw(name: String): ByteArray? {
                val e = zip.getEntry(name) ?: return null
                return zip.getInputStream(e).use { it.readBytes() }
            }
            val pres = parseXml(readRaw("ppt/presentation.xml") ?: throw IllegalArgumentException("not a pptx"))
            val sz = pres.find("sldSz")
            val cx = sz?.a("cx")?.toFloatOrNull() ?: 9144000f
            val cy = sz?.a("cy")?.toFloatOrNull() ?: 5143500f
            val s = viewW / cx
            val theme = parseTheme(readRaw("ppt/theme/theme1.xml"))
            val missing = HashSet<String>()

            // slide order
            val presRels = HashMap<String, String>()
            parseXml(readRaw("ppt/_rels/presentation.xml.rels") ?: ByteArray(0).let { "<r/>".toByteArray() }).kids.firstOrNull()?.kids?.forEach {
                val id = it.a("Id")
                val t = it.a("Target")
                if (id != null && t != null) presRels[id] = resolvePath("ppt", t)
            }
            val slideEntries = ArrayList<String>()
            pres.find("sldIdLst")?.kids?.forEach { sid ->
                // the relationship id is the namespaced attribute (r:id); plain "id" is the numeric slide id
                var relId: String? = null
                for ((k, v) in sid.attrs) if (k.endsWith(":id")) relId = v
                val target = if (relId != null) presRels[relId] else null
                if (target != null) slideEntries.add(target)
            }
            if (slideEntries.isEmpty()) {
                val en = zip.entries()
                val tmp = ArrayList<Pair<Int, String>>()
                val rx = Regex("^ppt/slides/slide(\\d+)\\.xml$")
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val m = rx.find(e.name)
                    if (m != null) tmp.add(Pair(m.groupValues[1].toInt(), e.name))
                }
                tmp.sortBy { it.first }
                for (x in tmp) slideEntries.add(x.second)
            }
            if (slideEntries.isEmpty()) throw IllegalStateException("no slides")

            val pages = ArrayList<List<Draw>>()
            val outline = ArrayList<Pair<String, Int>>()
            val book = EpubBook(path, zip, "", emptyList(), null)
            val ph = cy * s
            val shared = SB(zip, theme, emptyMap(), s, missing)

            for ((i, entry) in slideEntries.withIndex()) {
                currentCoroutineContext().ensureActive()
                onProgress(i.toFloat() / slideEntries.size)
                val draws = ArrayList<Draw>()
                var title = ""
                try {
                    title = buildSlide(entry, shared, book, cx * s, ph, draws)
                } catch (_: Throwable) {
                }
                pages.add(draws)
                outline.add(Pair(if (title.isNotBlank()) title else "Slide ${i + 1}", i))
            }
            onProgress(1f)
            return SlideDoc(pages, cx * s, ph, missing, outline, zip)
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }

    private fun buildSlide(entry: String, base: SB, book: EpubBook, pw: Float, ph: Float, out: ArrayList<Draw>): String {
        val slide = base.tree(entry)?.find("sld") ?: return ""
        val rels = base.rels(entry)
        val layoutEntry = rels.values.firstOrNull { it.contains("slideLayouts/") }
        val layout = if (layoutEntry != null) base.tree(layoutEntry)?.find("sldLayout") else null
        val masterEntry = if (layoutEntry != null) base.rels(layoutEntry).values.firstOrNull { it.contains("slideMasters/") } else null
        val master = if (masterEntry != null) base.tree(masterEntry)?.find("sldMaster") else null
        val clrMapNode = master?.kid("clrMap")
        val clrMap = HashMap<String, String>()
        clrMapNode?.attrs?.forEach { (k, v) -> clrMap[k.substringAfter(':')] = v }
        if (clrMap.isEmpty()) {
            clrMap["bg1"] = "lt1"; clrMap["tx1"] = "dk1"; clrMap["bg2"] = "lt2"; clrMap["tx2"] = "dk2"
        }
        val sb = SB(base.zip, base.theme, clrMap, base.s, base.missing, base.cache, base.relCache)

        // background
        fun bgOf(root: XN?): Int? {
            val bgPr = root?.find("bg")?.kid("bgPr")
            val f = sb.fillOf(bgPr)
            if (f != null && f != 0) return f
            val ref = root?.find("bg")?.kid("bgRef")
            return sb.color(ref?.kids?.firstOrNull())
        }
        val bg = bgOf(slide) ?: bgOf(layout) ?: bgOf(master) ?: Color.WHITE
        out.add(RectDraw(0f, 0f, pw, ph, bg))

        val ctx = SlideCtx(sb, book, master, layout, entry)
        val showMaster = layout?.a("showMasterSp") != "0" && slide.a("showMasterSp") != "0"
        if (showMaster) master?.find("spTree")?.let { shapes(it, Xf(sb.s, sb.s, 0f, 0f), ctx, ctx.masterRels, false, out, null) }
        layout?.find("spTree")?.let { shapes(it, Xf(sb.s, sb.s, 0f, 0f), ctx, ctx.layoutRels, false, out, null) }
        val titleBox = arrayOfNulls<String>(1)
        slide.find("spTree")?.let { shapes(it, Xf(sb.s, sb.s, 0f, 0f), ctx, rels, true, out, titleBox) }
        return titleBox[0] ?: ""
    }

    private class SlideCtx(val sb: SB, val book: EpubBook, val master: XN?, val layout: XN?, val entry: String) {
        val layoutEntry: String? = sb.rels(entry).values.firstOrNull { it.contains("slideLayouts/") }
        val masterEntry: String? = if (layoutEntry != null) sb.rels(layoutEntry).values.firstOrNull { it.contains("slideMasters/") } else null
        val layoutRels: Map<String, String> = if (layoutEntry != null) sb.rels(layoutEntry) else emptyMap()
        val masterRels: Map<String, String> = if (masterEntry != null) sb.rels(masterEntry) else emptyMap()
    }

    // ------------------------------------------------------------ shapes

    private fun xfrmOf(spPr: XN?): XN? = spPr?.kid("xfrm")

    private fun shapes(
        tree: XN, xf: Xf, ctx: SlideCtx, rels: Map<String, String>, isSlide: Boolean,
        out: ArrayList<Draw>, titleOut: Array<String?>?
    ) {
        for (shape in tree.kids) {
            when (shape.ln) {
                "sp", "cxnSp" -> drawSp(shape, xf, ctx, rels, isSlide, out, titleOut)
                "pic" -> drawPic(shape, xf, ctx, rels, out)
                "graphicFrame" -> drawFrame(shape, xf, ctx, out)
                "grpSp" -> {
                    val x = shape.kid("grpSpPr")?.kid("xfrm")
                    if (x != null) {
                        val off = x.kid("off")
                        val ext = x.kid("ext")
                        val chOff = x.kid("chOff")
                        val chExt = x.kid("chExt")
                        val ox = off?.a("x")?.toFloatOrNull() ?: 0f
                        val oy = off?.a("y")?.toFloatOrNull() ?: 0f
                        val ex = ext?.a("cx")?.toFloatOrNull() ?: 1f
                        val ey = ext?.a("cy")?.toFloatOrNull() ?: 1f
                        val cox = chOff?.a("x")?.toFloatOrNull() ?: 0f
                        val coy = chOff?.a("y")?.toFloatOrNull() ?: 0f
                        val cex = chExt?.a("cx")?.toFloatOrNull() ?: ex
                        val cey = chExt?.a("cy")?.toFloatOrNull() ?: ey
                        val kx = if (cex != 0f) ex / cex else 1f
                        val ky = if (cey != 0f) ey / cey else 1f
                        // child emu -> parent emu: p = off + (c - chOff) * k ; then parent -> px via xf
                        val nx = Xf(xf.sx * kx, xf.sy * ky, xf.tx + xf.sx * (ox - cox * kx), xf.ty + xf.sy * (oy - coy * ky))
                        shapes(shape, nx, ctx, rels, isSlide, out, titleOut)
                    } else shapes(shape, xf, ctx, rels, isSlide, out, titleOut)
                }
            }
        }
    }

    private class Box(val x: Float, val y: Float, val w: Float, val h: Float, val rot: Float, val flipH: Boolean, val flipV: Boolean)

    private fun boxOf(x: XN?, xf: Xf): Box? {
        if (x == null) return null
        val off = x.kid("off") ?: return null
        val ext = x.kid("ext") ?: return null
        val ox = off.a("x")?.toFloatOrNull() ?: return null
        val oy = off.a("y")?.toFloatOrNull() ?: return null
        val cx = ext.a("cx")?.toFloatOrNull() ?: return null
        val cy = ext.a("cy")?.toFloatOrNull() ?: return null
        return Box(
            xf.tx + ox * xf.sx, xf.ty + oy * xf.sy, cx * xf.sx, cy * xf.sy,
            (x.a("rot")?.toFloatOrNull() ?: 0f) / 60000f, x.a("flipH") == "1", x.a("flipV") == "1"
        )
    }

    private fun drawSp(
        sp: XN, xf: Xf, ctx: SlideCtx, rels: Map<String, String>, isSlide: Boolean,
        out: ArrayList<Draw>, titleOut: Array<String?>?
    ) {
        val sb = ctx.sb
        val nvPr = sp.kid("nvSpPr")?.kid("nvPr") ?: sp.kid("nvCxnSpPr")?.kid("nvPr")
        val ph = nvPr?.kid("ph")
        val phType = ph?.a("type")
        val phIdx = ph?.a("idx")
        if (ph != null && !isSlide) return // placeholders on layouts/masters are only templates
        val layoutPh = if (ph != null) placeholder(ctx.layout, phType, phIdx) else null
        val masterPh = if (ph != null) placeholder(ctx.master, phType, null) else null
        val spPr = sp.kid("spPr")
        val box = boxOf(xfrmOf(spPr), xf) ?: boxOf(xfrmOf(layoutPh?.kid("spPr")), Xf(ctx.sb.s, ctx.sb.s, 0f, 0f))
            ?: boxOf(xfrmOf(masterPh?.kid("spPr")), Xf(ctx.sb.s, ctx.sb.s, 0f, 0f)) ?: return

        val kids = ArrayList<Draw>()
        // fill + outline
        val geom = spPr?.kid("prstGeom")?.a("prst") ?: "rect"
        val fill = sb.fillOf(spPr)
        val lnNode = spPr?.kid("ln")
        val lineColor = if (lnNode?.kid("noFill") != null) null else sb.color(lnNode?.kid("solidFill")?.kids?.firstOrNull())
        val lineW = (lnNode?.a("w")?.toFloatOrNull() ?: 12700f) * sb.s
        val shapeKind = when {
            geom == "ellipse" -> 1
            geom.startsWith("roundRect") -> 2
            else -> 0
        }
        if (sp.ln == "cxnSp" || geom == "line" || geom == "straightConnector1") {
            val c = lineColor ?: Color.BLACK
            kids.add(LineDraw(box.x, box.y, box.x + box.w, box.y + box.h, max(1f, lineW), c))
        } else if ((fill != null && fill != 0) || lineColor != null) {
            kids.add(
                ShapeDraw(
                    shapeKind, box.x, box.y, box.x + box.w, box.y + box.h,
                    if (fill != null && fill != 0) fill else null, lineColor, lineW, min(box.w, box.h) * 0.16f
                )
            )
        }

        // text
        val body = sp.kid("txBody")
        if (body != null) {
            val kind = when (phType) {
                "title", "ctrTitle" -> "title"
                "sldNum", "dt", "ftr" -> "other"
                null -> if (ph != null) "body" else "other"
                else -> "body"
            }
            val text = layoutText(body, box, ctx, kind, layoutPh, masterPh, kids)
            if (isSlide && titleOut != null && titleOut[0] == null && kind == "title" && text.isNotBlank()) {
                titleOut[0] = text.trim().take(100)
            }
        }
        if (kids.isNotEmpty()) {
            if (box.rot != 0f || box.flipH || box.flipV) {
                out.add(XformDraw(kids, box.rot, box.x + box.w / 2f, box.y + box.h / 2f, box.flipH, box.flipV))
            } else out.addAll(kids)
        }
    }

    private fun drawPic(pic: XN, xf: Xf, ctx: SlideCtx, rels: Map<String, String>, out: ArrayList<Draw>) {
        val rid = pic.find("blip")?.a("embed") ?: return
        val entry = rels[rid] ?: return
        val box = boxOf(xfrmOf(pic.kid("spPr")), xf) ?: return
        val book = ctx.book
        val targetW = max(1, box.w.toInt())
        val d = ImageDraw({ EpubImages.get(book, entry, targetW) }, box.x, box.y, box.x + box.w, box.y + box.h)
        // decode now (background thread) so drawing never stalls
        EpubImages.get(book, entry, targetW)
        if (box.rot != 0f || box.flipH || box.flipV) {
            out.add(XformDraw(listOf(d), box.rot, box.x + box.w / 2f, box.y + box.h / 2f, box.flipH, box.flipV))
        } else out.add(d)
    }

    private fun drawFrame(fr: XN, xf: Xf, ctx: SlideCtx, out: ArrayList<Draw>) {
        val tbl = fr.find("tbl") ?: return
        val box = boxOf(fr.kid("xfrm"), xf) ?: return
        val sb = ctx.sb
        val cols = tbl.kid("tblGrid")?.kidsNamed("gridCol")?.map { (it.a("w")?.toFloatOrNull() ?: 914400f) * xf.sx } ?: return
        var y = box.y
        for (tr in tbl.kidsNamed("tr")) {
            val rh = (tr.a("h")?.toFloatOrNull() ?: 370840f) * xf.sy
            var x = box.x
            var ci = 0
            for (tc in tr.kidsNamed("tc")) {
                val span = tc.a("gridSpan")?.toIntOrNull() ?: 1
                var w = 0f
                for (k in 0 until span) w += cols.getOrElse(ci + k) { 0f }
                val pr = tc.kid("tcPr")
                val fill = sb.fillOf(pr)
                if (fill != null && fill != 0) out.add(RectDraw(x, y, x + w, y + rh, fill))
                val cellBox = Box(x + 91440f * xf.sx * 0.5f, y, w, rh, 0f, false, false)
                val body = tc.kid("txBody")
                if (body != null) layoutText(body, cellBox, ctx, "other", null, null, out)
                // thin borders
                out.add(LineDraw(x, y, x + w, y, 1f, 0x66000000))
                out.add(LineDraw(x, y + rh, x + w, y + rh, 1f, 0x66000000))
                out.add(LineDraw(x, y, x, y + rh, 1f, 0x66000000))
                out.add(LineDraw(x + w, y, x + w, y + rh, 1f, 0x66000000))
                x += w
                ci += span
            }
            y += rh
        }
    }

    // ------------------------------------------------------------ text

    private fun chainNodes(body: XN, kind: String, layoutPh: XN?, masterPh: XN?, ctx: SlideCtx, lvl: Int): List<XN?> {
        val name = "lvl${lvl + 1}pPr"
        val styleName = when (kind) {
            "title" -> "titleStyle"
            "body" -> "bodyStyle"
            else -> "otherStyle"
        }
        return listOf(
            body.kid("lstStyle")?.kid(name),
            layoutPh?.kid("txBody")?.kid("lstStyle")?.kid(name),
            masterPh?.kid("txBody")?.kid("lstStyle")?.kid(name),
            ctx.master?.find("txStyles")?.kid(styleName)?.kid(name)
        )
    }

    private fun firstAttr(nodes: List<XN?>, name: String): String? {
        for (n in nodes) {
            val v = n?.a(name)
            if (v != null) return v
        }
        return null
    }

    private fun firstKid(nodes: List<XN?>, name: String): XN? {
        for (n in nodes) {
            val v = n?.kid(name)
            if (v != null) return v
        }
        return null
    }

    /** Lays out a text body into [out]; returns the plain text. */
    private fun layoutText(
        body: XN, box: Box, ctx: SlideCtx, kind: String, layoutPh: XN?, masterPh: XN?, out: MutableList<Draw>
    ): String {
        val sb = ctx.sb
        val s = sb.s
        val bodyPr = body.kid("bodyPr") ?: layoutPh?.kid("txBody")?.kid("bodyPr") ?: masterPh?.kid("txBody")?.kid("bodyPr")
        val lIns = (bodyPr?.a("lIns")?.toFloatOrNull() ?: 91440f) * s
        val rIns = (bodyPr?.a("rIns")?.toFloatOrNull() ?: 91440f) * s
        val tIns = (bodyPr?.a("tIns")?.toFloatOrNull() ?: 45720f) * s
        val bIns = (bodyPr?.a("bIns")?.toFloatOrNull() ?: 45720f) * s
        val anchor = bodyPr?.a("anchor") ?: layoutPh?.kid("txBody")?.kid("bodyPr")?.a("anchor") ?: masterPh?.kid("txBody")?.kid("bodyPr")?.a("anchor") ?: "t"
        val fontScale = (bodyPr?.kid("normAutofit")?.a("fontScale")?.toFloatOrNull() ?: 100000f) / 100000f
        val availW = max(10f, box.w - lIns - rIns)

        val plain = StringBuilder()
        class PL(val layout: StaticLayout, val before: Float, val after: Float, val label: String?, val labelPaint: TextPaint?, val labelX: Float)
        val laid = ArrayList<PL>()
        var autoNum = 0

        for (p in body.kidsNamed("p")) {
            val pPr = p.kid("pPr")
            val lvl = pPr?.a("lvl")?.toIntOrNull()?.coerceIn(0, 8) ?: 0
            val chain = chainNodes(body, kind, layoutPh, masterPh, ctx, lvl)
            val nodes = listOf(pPr) + chain
            val algn = firstAttr(nodes, "algn") ?: "l"
            val marL = (firstAttr(nodes, "marL")?.toFloatOrNull() ?: 0f) * s
            val indent = (firstAttr(nodes, "indent")?.toFloatOrNull() ?: 0f) * s
            val lnSpc = firstKid(nodes, "lnSpc")?.kid("spcPct")?.a("val")?.toFloatOrNull()?.div(100000f) ?: 1f
            val spcBef = (firstKid(nodes, "spcBef")?.kid("spcPts")?.a("val")?.toFloatOrNull() ?: 0f) / 100f * EMU_PT * s
            val spcAft = (firstKid(nodes, "spcAft")?.kid("spcPts")?.a("val")?.toFloatOrNull() ?: 0f) / 100f * EMU_PT * s

            val sbd = SpannableStringBuilder()
            var firstRp: XN? = null
            var firstRpDef: XN? = null
            var defSizePx = 18f * EMU_PT * s
            val defNodes = chain.map { it?.kid("defRPr") }
            for (child in p.kids) {
                val isBr = child.ln == "br"
                if (child.ln != "r" && child.ln != "fld" && !isBr) continue
                val txt = if (isBr) "\n" else (child.kid("t")?.text?.toString() ?: "")
                if (txt.isEmpty()) continue
                val rPr = child.kid("rPr")
                if (firstRp == null) {
                    firstRp = rPr
                    firstRpDef = defNodes.firstOrNull { it != null }
                }
                val rNodes = listOf(rPr) + defNodes
                val szV = firstAttr(rNodes, "sz")?.toFloatOrNull()
                val sizePx = ((szV ?: when (kind) { "title" -> 4400f; "body" -> 2800f; else -> 1800f }) / 100f) * EMU_PT * s * fontScale
                if (sbd.isEmpty()) defSizePx = sizePx
                val bold = firstAttr(rNodes, "b") == "1"
                val italic = firstAttr(rNodes, "i") == "1"
                val und = (firstAttr(rNodes, "u") ?: "none") != "none"
                val strike = (firstAttr(rNodes, "strike") ?: "noStrike") != "noStrike"
                var font = (rPr?.kid("latin") ?: firstKid(rNodes, "latin"))?.a("typeface")
                if (font == "+mj-lt") font = sb.theme.major
                if (font == "+mn-lt" || font == null) font = font?.let { sb.theme.minor } ?: sb.theme.minor
                val fillNode = firstKid(rNodes, "solidFill")
                var col = sb.color(fillNode?.kids?.firstOrNull())
                if (col == null) col = sb.color(XN("schemeClr", mapOf("val" to "tx1")))
                val st = sbd.length
                sbd.append(txt)
                val en = sbd.length
                if (FontStore.isMissingLegacy(font)) sb.missing.add(font!!)
                sbd.setSpan(com.reader.app.office.FontSpan(FontStore.face(font, bold, italic)), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sbd.setSpan(AbsoluteSizeSpan(max(1, sizePx.toInt()), false), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                col?.let { sbd.setSpan(ForegroundColorSpan(it), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                if (und) sbd.setSpan(UnderlineSpan(), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (strike) sbd.setSpan(StrikethroughSpan(), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            plain.append(sbd).append('\n')

            // bullets
            var label: String? = null
            val buChar = firstKid(nodes, "buChar")?.a("char")
            val buAuto = firstKid(nodes, "buAutoNum")?.a("type")
            val noBu = firstKid(nodes, "buNone") != null && buChar == null && buAuto == null
            if (sbd.isNotBlank() && !noBu) {
                if (buAuto != null) {
                    autoNum++
                    label = when {
                        buAuto.startsWith("alphaLc") -> fmtNumber(autoNum, "lowerLetter")
                        buAuto.startsWith("alphaUc") -> fmtNumber(autoNum, "upperLetter")
                        buAuto.startsWith("romanLc") -> fmtNumber(autoNum, "lowerRoman")
                        buAuto.startsWith("romanUc") -> fmtNumber(autoNum, "upperRoman")
                        else -> autoNum.toString()
                    } + if (buAuto.endsWith("ParenR")) ")" else "."
                } else {
                    autoNum = 0
                    if (buChar != null) label = bulletChar(buChar)
                }
            } else autoNum = 0

            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
            paint.typeface = FontStore.face(sb.theme.minor, false, false)
            paint.textSize = max(1f, defSizePx)
            val hang = if (label != null) max(-indent, defSizePx * 0.9f) else 0f
            val leftMargin = (marL).toInt().coerceAtLeast(0)
            val firstMargin = (marL + indent).toInt().coerceAtLeast(0)
            if (sbd.isNotEmpty()) {
                sbd.setSpan(LeadingMarginSpan.Standard(if (label != null) leftMargin else firstMargin, leftMargin), 0, sbd.length, Spannable.SPAN_PARAGRAPH)
            }
            val align = when (algn) {
                "ctr" -> Layout.Alignment.ALIGN_CENTER
                "r" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
            val layout = StaticLayout.Builder.obtain(sbd, 0, sbd.length, paint, max(10, availW.toInt()))
                .setAlignment(align)
                .setLineSpacing(0f, lnSpc.coerceIn(0.5f, 3f))
                .setIncludePad(false)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                .build()
            var lp: TextPaint? = null
            if (label != null) {
                lp = TextPaint(Paint.ANTI_ALIAS_FLAG)
                lp.typeface = FontStore.face(sb.theme.minor, false, false)
                lp.textSize = max(1f, defSizePx)
                lp.color = sb.color(firstKid(listOf(firstRp) + defNodes, "solidFill")?.kids?.firstOrNull()) ?: Color.BLACK
            }
            laid.add(PL(layout, spcBef, spcAft, label, lp, max(0f, leftMargin - max(hang, defSizePx * 0.9f))))
        }
        if (laid.isEmpty()) return ""

        var total = 0f
        var prevAfter = 0f
        for (l in laid) {
            total += max(prevAfter, l.before) + l.layout.height
            prevAfter = l.after
        }
        val availH = box.h - tIns - bIns
        var y = when (anchor) {
            "ctr" -> box.y + tIns + max(0f, (availH - total) / 2f)
            "b" -> box.y + tIns + max(0f, availH - total)
            else -> box.y + tIns
        }
        prevAfter = 0f
        for (l in laid) {
            y += max(prevAfter, l.before)
            if (l.layout.lineCount > 0) {
                if (l.label != null && l.labelPaint != null) {
                    out.add(TextDraw(l.label, box.x + lIns + l.labelX, y + l.layout.getLineBaseline(0), l.labelPaint))
                }
                out.add(ParaDraw(l.layout, 0, l.layout.lineCount, box.x + lIns, y))
            }
            y += l.layout.height
            prevAfter = l.after
        }
        return plain.toString()
    }
}
