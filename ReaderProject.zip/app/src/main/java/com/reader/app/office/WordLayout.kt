package com.reader.app.office

import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ImageSpan
import android.text.style.LeadingMarginSpan
import android.text.style.LineHeightSpan
import android.text.style.StrikethroughSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TabStopSpan
import android.text.style.UnderlineSpan
import com.reader.app.FontStore
import com.reader.app.epub.EpubBook
import com.reader.app.epub.EpubImages
import com.reader.app.epub.LazyImage
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlin.math.max
import kotlin.math.min

private class ExactLine(val h: Int) : LineHeightSpan {
    override fun chooseHeight(
        text: CharSequence?, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: Paint.FontMetricsInt?
    ) {
        if (fm == null) return
        val diff = h - (fm.descent - fm.ascent)
        fm.descent += diff
        fm.bottom = fm.descent
    }
}

internal class LayoutCtx(
    val s: Float,
    val book: EpubBook,
    val defFont: String?,
    val defSize: Float,
    val missing: MutableSet<String>,
    val defFontCs: String? = null
) {
    val images = ArrayList<Pair<String, Int>>()
}

internal abstract class LaidBlock {
    abstract val before: Float
    abstract val after: Float
    abstract val inner: Float
    abstract fun placeInner(ox: Float, oy: Float, out: MutableList<Draw>)
}

internal fun stackHeight(list: List<LaidBlock>): Float {
    var y = 0f
    var prevAfter = 0f
    for (b in list) {
        y += max(prevAfter, b.before)
        y += b.inner
        prevAfter = b.after
    }
    return y + prevAfter
}

internal fun placeStack(list: List<LaidBlock>, ox: Float, oy: Float, out: MutableList<Draw>) {
    var y = oy
    var prevAfter = 0f
    for (b in list) {
        y += max(prevAfter, b.before)
        b.placeInner(ox, y, out)
        y += b.inner
        prevAfter = b.after
    }
}

internal class LaidPara(
    val layout: StaticLayout,
    val leftPx: Float,
    override val before: Float,
    override val after: Float,
    val shade: Int?,
    val borders: Array<WBorder?>?,
    val s: Float,
    val label: String?,
    val labelPaint: TextPaint?,
    val labelX: Float,
    val heading: Int,
    val plain: String
) : LaidBlock() {
    override val inner: Float get() = layout.height.toFloat()

    fun chunk(from: Int, to: Int, ox: Float, y: Float, out: MutableList<Draw>, isFirst: Boolean, isLast: Boolean) {
        val top = layout.getLineTop(from)
        val h = (layout.getLineBottom(to - 1) - top).toFloat()
        val x0 = ox + leftPx
        val x1 = ox + layout.width
        if (shade != null) out.add(RectDraw(x0, y, x1, y + h, shade))
        val b = borders
        if (b != null) {
            b[0]?.let { if (isFirst) out.add(LineDraw(x0, y, x1, y, max(1f, it.w * s), it.color)) }
            b[2]?.let { if (isLast) out.add(LineDraw(x0, y + h, x1, y + h, max(1f, it.w * s), it.color)) }
            b[1]?.let { out.add(LineDraw(x0, y, x0, y + h, max(1f, it.w * s), it.color)) }
            b[3]?.let { out.add(LineDraw(x1, y, x1, y + h, max(1f, it.w * s), it.color)) }
        }
        if (isFirst && label != null && labelPaint != null) {
            out.add(TextDraw(label, ox + labelX, y + layout.getLineBaseline(from) - top, labelPaint))
        }
        out.add(ParaDraw(layout, from, to, ox, y))
    }

    override fun placeInner(ox: Float, oy: Float, out: MutableList<Draw>) {
        if (layout.lineCount > 0) chunk(0, layout.lineCount, ox, oy, out, true, true)
    }
}

internal class LaidCell(
    val r: Int, val c0: Int, val span: Int, val m: WCellM,
    var blocks: List<LaidBlock>, var contentH: Float, var rowSpan: Int
)

internal class LaidTable(
    val colX: FloatArray,
    val rowH: FloatArray,
    val cells: List<LaidCell>,
    val borders: Array<WBorder?>?,
    val marL: Float, val marR: Float, val marT: Float, val marB: Float,
    val s: Float,
    val groupEnd: IntArray
) : LaidBlock() {
    override val before: Float get() = 0f
    override val after: Float get() = 0f
    override val inner: Float get() = rowH.sum()
    private val nCols = colX.size - 1

    fun unitHeight(from: Int, to: Int): Float {
        var h = 0f
        for (i in from..to) h += rowH[i]
        return h
    }

    fun placeRows(from: Int, to: Int, ox: Float, oy: Float, out: MutableList<Draw>) {
        for (cell in cells) {
            if (cell.r < from || cell.r > to) continue
            val x = ox + colX[cell.c0]
            val w = colX[cell.c0 + cell.span] - colX[cell.c0]
            var y = oy
            for (i in from until cell.r) y += rowH[i]
            var h = 0f
            for (i in cell.r until min(rowH.size, cell.r + cell.rowSpan)) h += rowH[i]
            cell.m.shd?.let { out.add(RectDraw(x, y, x + w, y + h, it)) }
            var vOff = 0f
            val free = h - cell.contentH - marT - marB
            if (free > 0f) {
                when (cell.m.vAlign) {
                    "center" -> vOff = free / 2f
                    "bottom" -> vOff = free
                }
            }
            placeStack(cell.blocks, x + marL, y + marT + vOff, out)
            // borders
            val tb = borders
            val cb = cell.m.borders
            val lastRow = cell.r + cell.rowSpan >= rowH.size
            val top = cb?.get(0) ?: if (cell.r == 0) tb?.get(0) else tb?.get(4)
            val left = cb?.get(1) ?: if (cell.c0 == 0) tb?.get(1) else tb?.get(5)
            val bottom = cb?.get(2) ?: if (lastRow) tb?.get(2) else tb?.get(4)
            val right = cb?.get(3) ?: if (cell.c0 + cell.span >= nCols) tb?.get(3) else tb?.get(5)
            top?.let { out.add(LineDraw(x, y, x + w, y, max(1f, it.w * s), it.color)) }
            bottom?.let { out.add(LineDraw(x, y + h, x + w, y + h, max(1f, it.w * s), it.color)) }
            left?.let { out.add(LineDraw(x, y, x, y + h, max(1f, it.w * s), it.color)) }
            right?.let { out.add(LineDraw(x + w, y, x + w, y + h, max(1f, it.w * s), it.color)) }
        }
    }

    override fun placeInner(ox: Float, oy: Float, out: MutableList<Draw>) {
        if (rowH.isNotEmpty()) placeRows(0, rowH.size - 1, ox, oy, out)
    }
}

internal object WordLayout {
    // ------------------------------------------------------------ paragraphs

    fun layoutPara(par: WPara, availPt: Float, ctx: LayoutCtx, pageNo: Int, pageTotal: Int): LaidPara {
        val s = ctx.s
        val p = par.p
        val leftPt = max(0f, p.left ?: 0f)
        val rightPt = max(0f, p.right ?: 0f)
        val firstRel = if (par.label != null) 0f else if (p.hanging != null) -(p.hanging ?: 0f) else (p.first ?: 0f)
        val widthPx = max(24f, (availPt - rightPt) * s)
        val firstMargin = max(0f, (leftPt + firstRel) * s).toInt()
        val restMargin = (leftPt * s).toInt()

        val markFont = par.markRp.font ?: ctx.defFont
        val basePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        basePaint.typeface = FontStore.face(markFont, false, false)
        basePaint.textSize = max(1f, (par.markRp.sizePt ?: ctx.defSize) * s)
        basePaint.color = par.markRp.color ?: 0xFF000000.toInt()

        val sb = SpannableStringBuilder()
        val carry = Carry()
        for (inl in par.runs) {
            when (inl) {
                is WText -> appendText(sb, inl.text, inl.rp, s, ctx, carry)
                is WPageNo -> appendText(sb, (if (inl.kind == 1) pageNo else pageTotal).toString(), inl.rp, s, ctx, carry)
                is WImg -> {
                    var w = inl.wPt * s
                    var h = inl.hPt * s
                    val maxW = max(20f, widthPx - restMargin)
                    if (w > maxW) {
                        h = h * maxW / w
                        w = maxW
                    }
                    val tw = max(1, w.toInt())
                    val th = max(1, h.toInt())
                    val d = LazyImage(ctx.book, inl.entry, tw)
                    d.setBounds(0, 0, tw, th)
                    ctx.images.add(Pair(inl.entry, tw))
                    val st = sb.length
                    sb.append('\uFFFC')
                    sb.setSpan(ImageSpan(d), st, st + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                else -> {}
            }
        }
        if (sb.isNotEmpty()) {
            val end = sb.length
            if (firstMargin != 0 || restMargin != 0) {
                sb.setSpan(LeadingMarginSpan.Standard(firstMargin, restMargin), 0, end, Spannable.SPAN_PARAGRAPH)
            }
            val custom = p.tabs ?: emptyList()
            var lastTab = 0f
            for (t in custom.sorted()) {
                sb.setSpan(TabStopSpan.Standard((t * s).toInt()), 0, end, Spannable.SPAN_PARAGRAPH)
                lastTab = max(lastTab, t)
            }
            var t = 36f
            var guard = 0
            while (t * s < widthPx && guard < 40) {
                if (t > lastTab) sb.setSpan(TabStopSpan.Standard((t * s).toInt()), 0, end, Spannable.SPAN_PARAGRAPH)
                t += 36f
                guard++
            }
            if (p.lineRule == "exact" && (p.line ?: 0f) > 0f) {
                sb.setSpan(ExactLine(max(1, ((p.line ?: 240f) / 20f * s).toInt())), 0, end, Spannable.SPAN_PARAGRAPH)
            }
        }

        val align = when (p.jc) {
            "center" -> Layout.Alignment.ALIGN_CENTER
            "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val mult = if (p.lineRule == null || p.lineRule == "auto") ((p.line ?: 240f) / 240f).coerceIn(0.5f, 4f) else 1f
        val lb = StaticLayout.Builder.obtain(sb, 0, sb.length, basePaint, widthPx.toInt())
            .setAlignment(align)
            .setLineSpacing(0f, mult)
            .setIncludePad(false)
            .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
        if (Build.VERSION.SDK_INT >= 26 && (p.jc == "both" || p.jc == "distribute")) {
            lb.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
        }
        val layout = lb.build()

        var labelPaint: TextPaint? = null
        var labelX = 0f
        if (par.label != null && par.labelRp != null) {
            val lrp = par.labelRp
            labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
            labelPaint.typeface = FontStore.face(lrp.font ?: ctx.defFont, lrp.bold == true, lrp.italic == true)
            labelPaint.textSize = max(1f, (lrp.sizePt ?: ctx.defSize) * s)
            labelPaint.color = lrp.color ?: 0xFF000000.toInt()
            labelX = max(0f, (leftPt - (p.hanging ?: 18f)) * s)
        }

        return LaidPara(
            layout, leftPt * s, (p.before ?: 0f) * s, (p.after ?: 0f) * s, p.shd, p.borders, s,
            par.label, labelPaint, labelX, par.heading, par.plain
        )
    }

    /** font + size of the last piece of text, so a combining mark that starts a new run can borrow them. */
    private class Carry {
        var face: Typeface? = null
        var size: Int = 0
        var fontSpan: FontSpan? = null
        var sizeSpan: AbsoluteSizeSpan? = null
        var start: Int = 0
    }

    /** Bangla vowel signs, anusvara, visarga, chandrabindu, hasanta (and ZWJ / ZWNJ) must be shaped together with the letter before them. */
    private val ZW_BEFORE_MARK = Regex("[\\u200B\\u200C\\u2060\\uFEFF]+(?=[\\u0981-\\u0983\\u09BC\\u09BE-\\u09CD\\u09D7])")

    private fun isAttach(c: Char): Boolean {
        if (c == '\u200C' || c == '\u200D' || c == '\u09CD') return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() ||
            t == Character.COMBINING_SPACING_MARK.toInt() ||
            t == Character.ENCLOSING_MARK.toInt()
    }

    private fun appendText(sb: SpannableStringBuilder, raw: String, rp: RProps, s: Float, ctx: LayoutCtx, carry: Carry) {
        if (raw.isEmpty()) return
        var text = if (rp.caps == true) raw.uppercase() else raw
        // zero-width characters in front of a vowel sign / ঃ / ং also break the cluster
        if (text.any { it == '\u200B' || it == '\u200C' || it == '\u2060' || it == '\uFEFF' }) {
            text = text.replace(ZW_BEFORE_MARK, "")
        }
        val st = sb.length
        sb.append(text)
        val en = sb.length
        // Bangla characters are drawn with the complex-script font (w:cs), like Word does. Using the
        // ascii font here (e.g. Times New Roman) made Android fall back piece by piece -> broken marks.
        val bangla = text.any { it in '\u0980'..'\u09FF' }
        val font = if (bangla) (rp.fontCs ?: ctx.defFontCs ?: rp.font ?: ctx.defFont) else (rp.font ?: ctx.defFont)
        if (FontStore.isMissing(font)) ctx.missing.add(font!!)
        var size = (if (bangla) rp.sizeCs else null) ?: rp.sizePt ?: ctx.defSize
        if (rp.vert != null && rp.vert != 0) size *= 0.65f
        val face = FontStore.face(
            font,
            (if (bangla) rp.boldCs ?: rp.bold else rp.bold) == true,
            (if (bangla) rp.italicCs ?: rp.italic else rp.italic) == true
        )
        val sizePx = max(1, (size * s).toInt())

        // Word often splits "মোঃ" / "ইং" into several runs. Every style span boundary splits Android's text
        // shaping, so a lone ঃ / ং / vowel sign got a dotted circle - even when both runs use the same font.
        // So: same font+size as the run before -> EXTEND the previous span instead of starting a new one;
        // different font -> at least keep marks (and the letter after a hasanta) inside the previous span.
        var lead = 0
        val pf = carry.fontSpan
        val ps = carry.sizeSpan
        if (pf != null && ps != null && st > 0) {
            if (carry.face == face && carry.size == sizePx) {
                lead = text.length
            } else {
                val prev = sb[st - 1]
                if ((prev == '\u09CD' || prev == '\u200D') && text.isNotEmpty()) lead = 1
                while (lead < text.length && isAttach(text[lead])) lead++
            }
            if (lead > 0) {
                sb.removeSpan(pf)
                sb.removeSpan(ps)
                sb.setSpan(pf, carry.start, st + lead, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(ps, carry.start, st + lead, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        val fs = st + lead
        if (fs < en) {
            val f1 = FontSpan(face)
            val s1 = AbsoluteSizeSpan(sizePx, false)
            sb.setSpan(f1, fs, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(s1, fs, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            carry.fontSpan = f1
            carry.sizeSpan = s1
            carry.start = fs
            carry.face = face
            carry.size = sizePx
        }
        rp.color?.let { sb.setSpan(ForegroundColorSpan(it), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        rp.highlight?.let { sb.setSpan(BackgroundColorSpan(it), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        if (rp.underline == true) sb.setSpan(UnderlineSpan(), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rp.strike == true) sb.setSpan(StrikethroughSpan(), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rp.vert == 1) sb.setSpan(SuperscriptSpan(), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rp.vert == -1) sb.setSpan(SubscriptSpan(), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // ------------------------------------------------------------ tables

    fun layoutBlocks(blocks: List<WBlock>, availPt: Float, ctx: LayoutCtx, pageNo: Int, pageTotal: Int): List<LaidBlock> {
        val out = ArrayList<LaidBlock>()
        for (b in blocks) {
            when (b) {
                is WPara -> out.add(layoutPara(b, availPt, ctx, pageNo, pageTotal))
                is WTable -> out.add(layoutTable(b, availPt, ctx, pageNo, pageTotal))
                else -> {}
            }
        }
        return out
    }

    fun layoutTable(t: WTable, availPt: Float, ctx: LayoutCtx, pageNo: Int, pageTotal: Int): LaidTable {
        val s = ctx.s
        var grid = t.grid
        if (grid.isEmpty()) {
            val n = max(1, t.rows.maxOfOrNull { r -> r.cells.sumOf { it.span } } ?: 1)
            grid = FloatArray(n) { (availPt - t.indent) / n }
        }
        val total = grid.sum()
        val maxW = max(40f, availPt - t.indent)
        val f = if (total > maxW * 1.01f) maxW / total else 1f
        val colX = FloatArray(grid.size + 1)
        for (i in grid.indices) colX[i + 1] = colX[i] + grid[i] * f * s
        val indentPx = t.indent * s
        for (i in colX.indices) colX[i] += indentPx

        val nRows = t.rows.size
        val cells = ArrayList<LaidCell>()
        val open = HashMap<Int, LaidCell>()
        val marL = t.marL * s
        val marR = t.marR * s
        val marT = t.marT * s
        val marB = t.marB * s
        for ((ri, row) in t.rows.withIndex()) {
            var gi = 0
            for (m in row.cells) {
                val span = max(1, min(m.span, grid.size - gi))
                if (gi >= grid.size) break
                if (m.vMerge == 2) {
                    open[gi]?.let { it.rowSpan += 1 }
                } else {
                    val wPt = (colX[gi + span] - colX[gi]) / s
                    val inner = max(10f, wPt - t.marL - t.marR)
                    val laid = layoutBlocks(m.blocks, inner, ctx, pageNo, pageTotal)
                    val cell = LaidCell(ri, gi, span, m, laid, stackHeight(laid), 1)
                    cells.add(cell)
                    if (m.vMerge == 1) open[gi] = cell else open.remove(gi)
                }
                gi += span
            }
        }
        val rowH = FloatArray(nRows)
        for ((ri, row) in t.rows.withIndex()) {
            val h = row.height
            if (h != null) rowH[ri] = h * s
        }
        for (c in cells) {
            if (c.rowSpan == 1) {
                val row = t.rows[c.r]
                val need = c.contentH + marT + marB
                rowH[c.r] = if (row.exact && row.height != null) row.height * s else max(rowH[c.r], need)
            }
        }
        for (c in cells) {
            if (c.rowSpan > 1) {
                val need = c.contentH + marT + marB
                var have = 0f
                val last = min(nRows - 1, c.r + c.rowSpan - 1)
                for (i in c.r..last) have += rowH[i]
                if (need > have) rowH[last] += need - have
            }
        }
        // rows joined by a vertical merge must stay on one page
        val groupEnd = IntArray(nRows) { it }
        for (c in cells) {
            if (c.rowSpan > 1) {
                val last = min(nRows - 1, c.r + c.rowSpan - 1)
                for (i in c.r..last) groupEnd[i] = max(groupEnd[i], last)
            }
        }
        var changed = true
        while (changed) {
            changed = false
            for (i in 0 until nRows) {
                val g = groupEnd[i]
                if (g > i) for (j in i..g) if (groupEnd[j] < g) {
                    groupEnd[j] = g
                    changed = true
                }
            }
        }
        return LaidTable(colX, rowH, cells, t.borders, marL, marR, marT, marB, s, groupEnd)
    }

    // ------------------------------------------------------------ pages

    private class Flow(val sec: WSection, val s: Float) {
        val pages = ArrayList<ArrayList<Draw>>()
        var cur = ArrayList<Draw>()
        val top = sec.mt * s
        val bottom = (sec.ph - sec.mb) * s
        var y = top
        var prevAfter = 0f
        val outline = ArrayList<Pair<String, Int>>()

        init {
            pages.add(cur)
        }

        fun newPage() {
            cur = ArrayList()
            pages.add(cur)
            y = top
            prevAfter = 0f
        }

        fun addPara(lp: LaidPara, cx: Float) {
            val gap = if (y <= top + 0.5f && cur.isEmpty()) lp.before else max(prevAfter, lp.before)
            y += gap
            val n = lp.layout.lineCount
            if (lp.heading in 1..2 && lp.plain.isNotBlank()) {
                // note the page where the heading lands (may move to the next page below)
                outline.add(Pair(lp.plain.trim().take(120), pages.size - 1))
            }
            if (n == 0) {
                prevAfter = lp.after
                return
            }
            var line = 0
            var firstChunk = true
            while (line < n) {
                val avail = bottom - y
                val top0 = lp.layout.getLineTop(line)
                var end = line
                while (end < n && lp.layout.getLineBottom(end) - top0 <= avail) end++
                if (end == line) {
                    if (y > top + 0.5f) {
                        newPage()
                        if (firstChunk && lp.heading in 1..2 && outline.isNotEmpty()) {
                            val last = outline.removeAt(outline.size - 1)
                            outline.add(Pair(last.first, pages.size - 1))
                        }
                        continue
                    } else end = line + 1
                }
                if (end < n) {
                    if (end - line == 1 && y > top + 0.5f && firstChunk) {
                        newPage()
                        continue
                    }
                    if (n - end == 1 && end - line >= 2) end -= 1
                }
                val chunkTop = y
                lp.chunk(line, end, cx, chunkTop, cur, firstChunk, end >= n)
                y += (lp.layout.getLineBottom(end - 1) - top0).toFloat()
                line = end
                firstChunk = false
                if (line < n) newPage()
            }
            prevAfter = lp.after
        }

        fun addTable(lt: LaidTable, cx: Float) {
            var i = 0
            while (i < lt.rowH.size) {
                val g = lt.groupEnd[i]
                val h = lt.unitHeight(i, g)
                if (y + h > bottom && y > top + 0.5f) newPage()
                lt.placeRows(i, g, cx, y, cur)
                y += h
                i = g + 1
            }
            prevAfter = 0f
        }
    }

    suspend fun build(model: WordModel, viewW: Float, onProgress: (Float) -> Unit): WordDoc {
        val sec = model.sec
        val s = viewW / sec.pw
        val ctx = LayoutCtx(s, model.book, model.defaultFont, model.defaultSizePt, HashSet(), model.defaultFontCs)
        val flow = Flow(sec, s)
        val cx = sec.ml * s
        val availPt = sec.pw - sec.ml - sec.mr
        val total = max(1, model.blocks.size)

        for ((i, b) in model.blocks.withIndex()) {
            currentCoroutineContext().ensureActive()
            if (i % 20 == 0) onProgress(i.toFloat() / total)
            when (b) {
                is WPara -> flow.addPara(layoutPara(b, availPt, ctx, 1, 1), cx)
                is WTable -> flow.addTable(layoutTable(b, availPt, ctx, 1, 1), cx)
                is WPageBreakBlock -> if (flow.y > flow.top + 0.5f || flow.cur.isNotEmpty()) flow.newPage()
            }
        }
        // drop a trailing empty page
        if (flow.pages.size > 1 && flow.pages.last().isEmpty()) flow.pages.removeAt(flow.pages.size - 1)

        // headers and footers (page numbers differ per page)
        val n = flow.pages.size
        for (i in 0 until n) {
            val page = flow.pages[i]
            model.header?.let { h ->
                val laid = layoutBlocks(h, availPt, ctx, i + 1, n)
                placeStack(laid, cx, sec.headerDist * s, page)
            }
            model.footer?.let { f ->
                val laid = layoutBlocks(f, availPt, ctx, i + 1, n)
                val fh = stackHeight(laid)
                placeStack(laid, cx, (sec.ph - sec.footerDist) * s - fh, page)
            }
        }
        // decode the pictures now (background thread) so scrolling never stalls
        for ((entry, w) in ctx.images.distinct().take(60)) {
            currentCoroutineContext().ensureActive()
            EpubImages.get(model.book, entry, w)
        }
        onProgress(1f)
        return WordDoc(flow.pages, sec.pw * s, sec.ph * s, ctx.missing, flow.outline, model.book)
    }
}

class WordDoc internal constructor(
    private val pages: List<List<Draw>>,
    override val pageW: Float,
    override val pageH: Float,
    override val missingFonts: Set<String>,
    override val outline: List<Pair<String, Int>>,
    private val book: EpubBook
) : FixedDoc {
    override val pageCount: Int get() = pages.size

    override fun drawPage(c: android.graphics.Canvas, index: Int) {
        if (index !in pages.indices) return
        for (d in pages[index]) d.draw(c)
    }

    fun close() {
        book.close()
    }
}

/** Opens a .docx with the fixed-layout engine (throws if the file can't be parsed). */
object WordOpen {
    fun parse(path: String): Any = WordParser.parse(path)

    suspend fun build(model: Any, viewW: Float, onProgress: (Float) -> Unit): WordDoc =
        WordLayout.build(model as WordModel, viewW, onProgress)
}
