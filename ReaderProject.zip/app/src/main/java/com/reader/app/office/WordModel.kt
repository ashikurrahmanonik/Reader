package com.reader.app.office

import android.graphics.Color
import com.reader.app.epub.EpubBook
import com.reader.app.epub.resolvePath
import java.util.zip.ZipFile

// ------------------------------------------------------------------ model

internal class WBorder(val w: Float, val color: Int)

internal class WP {
    var before: Float? = null
    var after: Float? = null
    var line: Float? = null
    var lineRule: String? = null
    var left: Float? = null
    var right: Float? = null
    var first: Float? = null
    var hanging: Float? = null
    var jc: String? = null
    var numId: Int? = null
    var ilvl: Int? = null
    var shd: Int? = null
    var pageBreakBefore: Boolean? = null
    var borders: Array<WBorder?>? = null // top, left, bottom, right
    var tabs: List<Float>? = null

    fun merge(o: WP) {
        o.before?.let { before = it }
        o.after?.let { after = it }
        o.line?.let { line = it }
        o.lineRule?.let { lineRule = it }
        o.left?.let { left = it }
        o.right?.let { right = it }
        o.first?.let { first = it }
        o.hanging?.let { hanging = it }
        o.jc?.let { jc = it }
        o.numId?.let { numId = it }
        o.ilvl?.let { ilvl = it }
        o.shd?.let { shd = it }
        o.pageBreakBefore?.let { pageBreakBefore = it }
        o.borders?.let { borders = it }
        o.tabs?.let { tabs = it }
    }
}

internal class WStyle(
    val id: String,
    val type: String,
    val name: String,
    val basedOn: String?,
    val p: WP,
    val r: RProps,
    val tblBorders: Array<WBorder?>?, // top, left, bottom, right, insideH, insideV
    val isDefault: Boolean
)

internal sealed class WInline
internal class WText(val text: String, val rp: RProps) : WInline()
internal class WImg(val entry: String, val wPt: Float, val hPt: Float) : WInline()
internal class WPageNo(val kind: Int, val rp: RProps) : WInline()
internal object WPageBreakMarker : WInline()

internal sealed class WBlock
internal class WPara(
    val p: WP,
    val runs: List<WInline>,
    val markRp: RProps,
    val label: String?,
    val labelRp: RProps?,
    val heading: Int,
    val plain: String
) : WBlock()

internal object WPageBreakBlock : WBlock()

internal class WCellM(
    val blocks: List<WBlock>,
    val span: Int,
    val vMerge: Int, // 0 none, 1 restart, 2 continue
    val shd: Int?,
    val borders: Array<WBorder?>?,
    val vAlign: String?
)

internal class WRowM(val cells: List<WCellM>, val height: Float?, val exact: Boolean)

internal class WTable(
    val grid: FloatArray,
    val rows: List<WRowM>,
    val borders: Array<WBorder?>?,
    val indent: Float,
    val marL: Float,
    val marR: Float,
    val marT: Float,
    val marB: Float
) : WBlock()

internal class WSection(
    val pw: Float, val ph: Float,
    val mt: Float, val mb: Float, val ml: Float, val mr: Float,
    val headerDist: Float, val footerDist: Float
)

internal class WordModel(
    val sec: WSection,
    val blocks: List<WBlock>,
    val header: List<WBlock>?,
    val footer: List<WBlock>?,
    val book: EpubBook,
    val defaultFont: String?,
    val defaultSizePt: Float
)

// ------------------------------------------------------------------ numbering

internal class NumLevel(val fmt: String, val text: String, val start: Int, val left: Float?, val hanging: Float?)

internal class Numbering(
    val abstracts: Map<Int, Map<Int, NumLevel>>,
    val nums: Map<Int, Int>,
    val overrides: Map<Long, Int>
) {
    fun level(numId: Int, ilvl: Int): NumLevel? {
        val aid = nums[numId] ?: return null
        return abstracts[aid]?.get(ilvl)
    }
    fun abstractId(numId: Int): Int? = nums[numId]
}

internal fun fmtNumber(n: Int, fmt: String): String {
    return when (fmt) {
        "decimal" -> n.toString()
        "decimalZero" -> n.toString().padStart(2, '0')
        "lowerLetter" -> letters(n).lowercase()
        "upperLetter" -> letters(n)
        "lowerRoman" -> roman(n).lowercase()
        "upperRoman" -> roman(n)
        "bengali" -> n.toString().map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")
        else -> n.toString()
    }
}

private fun letters(n: Int): String {
    var x = max1(n)
    val sb = StringBuilder()
    while (x > 0) {
        x--
        sb.insert(0, 'A' + x % 26)
        x /= 26
    }
    return sb.toString()
}

private fun max1(n: Int) = if (n < 1) 1 else n

private fun roman(n: Int): String {
    var x = max1(n)
    val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
    val s = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
    val sb = StringBuilder()
    for (i in v.indices) while (x >= v[i]) {
        sb.append(s[i])
        x -= v[i]
    }
    return sb.toString()
}

internal fun bulletChar(t: String): String {
    if (t.isEmpty()) return "•"
    val c = t[0]
    return when {
        c == 'o' -> "◦"
        c == '\uF0A7' || c == '§' -> "▪"
        c == '\uF0FC' -> "✓"
        c == '\uF0D8' -> "➢"
        c.code in 0xE000..0xF8FF -> "•"
        c == '·' || c == '•' -> "•"
        else -> t.take(1)
    }
}

// ------------------------------------------------------------------ helpers

private val HIGHLIGHTS = mapOf(
    "yellow" to 0xFFFFFF00.toInt(), "green" to 0xFF00FF00.toInt(), "cyan" to 0xFF00FFFF.toInt(),
    "magenta" to 0xFFFF00FF.toInt(), "blue" to 0xFF0000FF.toInt(), "red" to 0xFFFF0000.toInt(),
    "darkBlue" to 0xFF000080.toInt(), "darkCyan" to 0xFF008080.toInt(), "darkGreen" to 0xFF008000.toInt(),
    "darkMagenta" to 0xFF800080.toInt(), "darkRed" to 0xFF800000.toInt(), "darkYellow" to 0xFF808000.toInt(),
    "darkGray" to 0xFF808080.toInt(), "lightGray" to 0xFFC0C0C0.toInt(), "black" to 0xFF000000.toInt(),
    "white" to 0xFFFFFFFF.toInt()
)

internal fun hexColor(c: String?): Int? {
    if (c == null || c == "auto" || c.length != 6) return null
    return try {
        Color.parseColor("#$c")
    } catch (_: Throwable) {
        null
    }
}

private fun twip(s: String?): Float? = s?.toFloatOrNull()?.div(20f)

private fun readBorder(n: XN?): WBorder? {
    if (n == null) return null
    val v = n.a("val") ?: return null
    if (v == "nil" || v == "none") return null
    val sz = (n.a("sz")?.toFloatOrNull() ?: 4f) / 8f
    return WBorder(sz.coerceAtLeast(0.25f), hexColor(n.a("color")) ?: Color.BLACK)
}

internal fun readPPr(n: XN?, into: WP) {
    if (n == null) return
    n.kid("spacing")?.let { sp ->
        twip(sp.a("before"))?.let { into.before = it }
        twip(sp.a("after"))?.let { into.after = it }
        sp.a("line")?.toFloatOrNull()?.let { into.line = it }
        sp.a("lineRule")?.let { into.lineRule = it }
    }
    n.kid("ind")?.let { ind ->
        (twip(ind.a("left")) ?: twip(ind.a("start")))?.let { into.left = it }
        (twip(ind.a("right")) ?: twip(ind.a("end")))?.let { into.right = it }
        twip(ind.a("firstLine"))?.let {
            into.first = it
            into.hanging = null
        }
        twip(ind.a("hanging"))?.let {
            into.hanging = it
            into.first = null
        }
    }
    n.kid("jc")?.a("val")?.let { into.jc = it }
    n.kid("numPr")?.let { np ->
        np.kid("numId")?.a("val")?.toIntOrNull()?.let { into.numId = it }
        np.kid("ilvl")?.a("val")?.toIntOrNull()?.let { into.ilvl = it }
    }
    n.kid("shd")?.a("fill")?.let { f -> hexColor(f)?.let { into.shd = it } }
    if (n.kid("pageBreakBefore") != null) into.pageBreakBefore = n.kid("pageBreakBefore")?.a("val") != "0"
    n.kid("pBdr")?.let { b ->
        into.borders = arrayOf(readBorder(b.kid("top")), readBorder(b.kid("left")), readBorder(b.kid("bottom")), readBorder(b.kid("right")))
    }
    n.kid("tabs")?.let { t ->
        val list = ArrayList<Float>()
        for (tab in t.kidsNamed("tab")) {
            if (tab.a("val") == "clear") continue
            twip(tab.a("pos"))?.let { list.add(it) }
        }
        into.tabs = list
    }
}

private fun onOff(n: XN): Boolean {
    val v = n.a("val") ?: return true
    return !(v == "0" || v == "false" || v == "off" || v == "none")
}

internal fun readRPr(n: XN?, into: RProps, themeMajor: String?, themeMinor: String?) {
    if (n == null) return
    for (k in n.kids) {
        when (k.ln) {
            "rFonts" -> {
                var f = k.a("ascii") ?: k.a("hAnsi") ?: k.a("cs") ?: k.a("eastAsia")
                if (f == null) {
                    val th = k.a("asciiTheme") ?: k.a("hAnsiTheme")
                    if (th != null) f = if (th.startsWith("major")) themeMajor else themeMinor
                }
                if (f != null) into.font = f
            }
            "b" -> into.bold = onOff(k)
            "i" -> into.italic = onOff(k)
            "u" -> into.underline = (k.a("val") ?: "single") != "none"
            "strike", "dstrike" -> into.strike = onOff(k)
            "sz" -> k.a("val")?.toFloatOrNull()?.let { into.sizePt = it / 2f }
            "color" -> hexColor(k.a("val"))?.let { into.color = it }
            "highlight" -> k.a("val")?.let { h -> HIGHLIGHTS[h]?.let { into.highlight = it } }
            "shd" -> if (into.highlight == null) hexColor(k.a("fill"))?.let { into.highlight = it }
            "vertAlign" -> when (k.a("val")) {
                "superscript" -> into.vert = 1
                "subscript" -> into.vert = -1
                else -> into.vert = 0
            }
            "caps", "smallCaps" -> into.caps = onOff(k)
        }
    }
}

// ------------------------------------------------------------------ parser

internal object WordParser {
    private fun parseStyles(
        bytes: ByteArray?, themeMajor: String?, themeMinor: String?
    ): Triple<WP, RProps, Map<String, WStyle>> {
        val dp = WP()
        val dr = RProps()
        val map = LinkedHashMap<String, WStyle>()
        if (bytes == null) return Triple(dp, dr, map)
        try {
            val root = parseXml(bytes)
            val st = root.find("styles") ?: return Triple(dp, dr, map)
            for (k in st.kids) {
                when (k.ln) {
                    "docDefaults" -> {
                        readRPr(k.kid("rPrDefault")?.kid("rPr"), dr, themeMajor, themeMinor)
                        readPPr(k.kid("pPrDefault")?.kid("pPr"), dp)
                    }
                    "style" -> {
                        val id = k.a("styleId") ?: continue
                        val p = WP()
                        val r = RProps()
                        readPPr(k.kid("pPr"), p)
                        readRPr(k.kid("rPr"), r, themeMajor, themeMinor)
                        var tb: Array<WBorder?>? = null
                        k.kid("tblPr")?.kid("tblBorders")?.let { b ->
                            tb = arrayOf(
                                readBorder(b.kid("top")), readBorder(b.kid("left")), readBorder(b.kid("bottom")),
                                readBorder(b.kid("right")), readBorder(b.kid("insideH")), readBorder(b.kid("insideV"))
                            )
                        }
                        map[id] = WStyle(
                            id, k.a("type") ?: "", k.kid("name")?.a("val") ?: "", k.kid("basedOn")?.a("val"),
                            p, r, tb, k.a("default") == "1"
                        )
                    }
                }
            }
        } catch (_: Throwable) {
        }
        return Triple(dp, dr, map)
    }

    private fun parseNumbering(bytes: ByteArray?): Numbering {
        val abstracts = HashMap<Int, Map<Int, NumLevel>>()
        val nums = HashMap<Int, Int>()
        val overrides = HashMap<Long, Int>()
        if (bytes != null) {
            try {
                val root = parseXml(bytes)
                val n = root.find("numbering")
                if (n != null) {
                    for (k in n.kids) {
                        if (k.ln == "abstractNum") {
                            val id = k.a("abstractNumId")?.toIntOrNull() ?: continue
                            val lv = HashMap<Int, NumLevel>()
                            for (l in k.kidsNamed("lvl")) {
                                val il = l.a("ilvl")?.toIntOrNull() ?: continue
                                val ind = l.kid("pPr")?.kid("ind")
                                lv[il] = NumLevel(
                                    l.kid("numFmt")?.a("val") ?: "decimal",
                                    l.kid("lvlText")?.a("val") ?: "",
                                    l.kid("start")?.a("val")?.toIntOrNull() ?: 1,
                                    twip(ind?.a("left") ?: ind?.a("start")),
                                    twip(ind?.a("hanging"))
                                )
                            }
                            abstracts[id] = lv
                        } else if (k.ln == "num") {
                            val id = k.a("numId")?.toIntOrNull() ?: continue
                            val aid = k.kid("abstractNumId")?.a("val")?.toIntOrNull() ?: continue
                            nums[id] = aid
                            for (o in k.kidsNamed("lvlOverride")) {
                                val il = o.a("ilvl")?.toIntOrNull() ?: continue
                                o.kid("startOverride")?.a("val")?.toIntOrNull()?.let { overrides[id.toLong() * 100 + il] = it }
                            }
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return Numbering(abstracts, nums, overrides)
    }

    private fun parseRels(bytes: ByteArray?): Map<String, String> {
        val map = HashMap<String, String>()
        if (bytes == null) return map
        try {
            val root = parseXml(bytes)
            for (r in root.kids.firstOrNull()?.kids ?: emptyList()) {
                val id = r.a("Id")
                val t = r.a("Target")
                if (id != null && t != null) map[id] = t
            }
        } catch (_: Throwable) {
        }
        return map
    }

    private fun themeFonts(bytes: ByteArray?): Pair<String?, String?> {
        if (bytes == null) return Pair(null, null)
        return try {
            val root = parseXml(bytes)
            val major = root.find("majorFont")?.kid("latin")?.a("typeface")
            val minor = root.find("minorFont")?.kid("latin")?.a("typeface")
            Pair(major, minor)
        } catch (_: Throwable) {
            Pair(null, null)
        }
    }

    fun parse(path: String): WordModel {
        val zip = ZipFile(path)
        try {
            fun read(name: String): ByteArray? {
                val e = zip.getEntry(name) ?: return null
                return zip.getInputStream(e).use { it.readBytes() }
            }

            var mainName = "word/document.xml"
            if (zip.getEntry(mainName) == null) {
                val en = zip.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.name.startsWith("word/document") && e.name.endsWith(".xml")) {
                        mainName = e.name
                        break
                    }
                }
            }
            val docBytes = read(mainName) ?: throw IllegalArgumentException("not a docx")
            val (themeMajor, themeMinor) = themeFonts(read("word/theme/theme1.xml"))
            val (dp, dr, styles) = parseStyles(read("word/styles.xml"), themeMajor, themeMinor)
            val numbering = parseNumbering(read("word/numbering.xml"))
            val relName = mainName.substringBeforeLast('/') + "/_rels/" + mainName.substringAfterLast('/') + ".rels"
            val rels = parseRels(read(relName))

            val book = EpubBook(path, zip, "", emptyList(), null)
            val root = parseXml(docBytes)
            val document = root.kids.firstOrNull { it.ln == "document" } ?: throw IllegalArgumentException("no document")
            val body = document.kid("body") ?: throw IllegalArgumentException("no body")

            val mainB = WBuilder(styles, dp, dr, numbering, rels, themeMajor, themeMinor, false)
            val blocks = mainB.blocks(body)

            // page geometry from the last (body level) or first section properties
            var sect = body.kid("sectPr")
            if (sect == null) sect = body.find("sectPr")
            val pgSz = sect?.kid("pgSz")
            var pw = twip(pgSz?.a("w")) ?: 595.3f
            var ph = twip(pgSz?.a("h")) ?: 841.9f
            if (pgSz?.a("orient") == "landscape" && pw < ph) {
                val t = pw
                pw = ph
                ph = t
            }
            val pm = sect?.kid("pgMar")
            val sec = WSection(
                pw, ph,
                twip(pm?.a("top")) ?: 72f, twip(pm?.a("bottom")) ?: 72f,
                twip(pm?.a("left")) ?: 72f, twip(pm?.a("right")) ?: 72f,
                twip(pm?.a("header")) ?: 36f, twip(pm?.a("footer")) ?: 36f
            )

            fun hf(tag: String): List<WBlock>? {
                val ref = sect?.kidsNamed(tag)?.let { l -> l.firstOrNull { it.a("type") == "default" } ?: l.firstOrNull() } ?: return null
                val rid = ref.a("id") ?: return null
                val target = rels[rid] ?: return null
                val entry = resolvePath("word", target)
                val b = read(entry) ?: return null
                return try {
                    val r = parseXml(b)
                    val hfRels = parseRels(read(entry.substringBeforeLast('/') + "/_rels/" + entry.substringAfterLast('/') + ".rels"))
                    val root2 = r.kids.firstOrNull() ?: return null
                    WBuilder(styles, dp, dr, numbering, hfRels, themeMajor, themeMinor, true).blocks(root2)
                } catch (_: Throwable) {
                    null
                }
            }

            val defFont = dr.font ?: themeMinor
            return WordModel(sec, blocks, hf("headerReference"), hf("footerReference"), book, defFont, dr.sizePt ?: 11f)
        } catch (e: Throwable) {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
            throw e
        }
    }
}

internal class WBuilder(
    val styles: Map<String, WStyle>,
    val defP: WP,
    val defR: RProps,
    val numbering: Numbering,
    val rels: Map<String, String>,
    val themeMajor: String?,
    val themeMinor: String?,
    val hf: Boolean
) {
    private val defaultPara = styles.values.firstOrNull { it.type == "paragraph" && it.isDefault }
    private val counters = HashMap<Int, IntArray>()
    private var fieldCode = false
    private val instr = StringBuilder()
    private var skipResult = false

    private fun chain(id: String?): List<WStyle> {
        val out = ArrayList<WStyle>()
        var cur = id
        var guard = 0
        while (cur != null && guard < 10) {
            val s = styles[cur] ?: break
            out.add(0, s)
            cur = s.basedOn
            guard++
        }
        return out
    }

    private fun resolveP(pStyle: String?, direct: WP): WP {
        val o = WP()
        o.merge(defP)
        defaultPara?.let { o.merge(it.p) }
        for (s in chain(pStyle)) o.merge(s.p)
        o.merge(direct)
        return o
    }

    private fun resolveR(pStyle: String?, rStyle: String?, direct: RProps): RProps {
        val o = RProps()
        o.copyFrom(defR)
        defaultPara?.let { o.copyFrom(it.r) }
        for (s in chain(pStyle)) o.copyFrom(s.r)
        for (s in chain(rStyle)) o.copyFrom(s.r)
        o.copyFrom(direct)
        return o
    }

    private fun tblBordersFor(style: String?, direct: XN?): Array<WBorder?>? {
        var b: Array<WBorder?>? = null
        for (s in chain(style)) s.tblBorders?.let { b = it }
        if (direct != null) {
            b = arrayOf(
                readBorder(direct.kid("top")), readBorder(direct.kid("left")), readBorder(direct.kid("bottom")),
                readBorder(direct.kid("right")), readBorder(direct.kid("insideH")), readBorder(direct.kid("insideV"))
            )
        }
        return b
    }

    fun blocks(container: XN): List<WBlock> {
        val out = ArrayList<WBlock>()
        walk(container, out)
        return out
    }

    private fun walk(node: XN, out: ArrayList<WBlock>) {
        for (k in node.kids) {
            when (k.ln) {
                "p" -> paragraph(k, out)
                "tbl" -> table(k, out)
                "body", "sdt", "sdtContent", "customXml", "ins", "smartTag", "moveTo", "hdr", "ftr" -> walk(k, out)
            }
        }
    }

    // ---- paragraphs

    private fun findBlip(n: XN): String? {
        if (n.ln == "blip") return n.a("embed")
        for (c in n.kids) {
            val r = findBlip(c)
            if (r != null) return r
        }
        return null
    }

    private fun extentPt(n: XN): Pair<Float, Float>? {
        val e = n.find("extent") ?: return null
        val cx = e.a("cx")?.toFloatOrNull() ?: return null
        val cy = e.a("cy")?.toFloatOrNull() ?: return null
        return Pair(cx / 12700f, cy / 12700f)
    }

    private fun vmlSize(n: XN): Pair<Float, Float>? {
        val shape = n.find("shape") ?: return null
        val style = shape.a("style") ?: return null
        fun dim(key: String): Float? {
            val m = Regex("$key:\\s*([0-9.]+)(pt|in|px|cm|mm)?").find(style) ?: return null
            val v = m.groupValues[1].toFloatOrNull() ?: return null
            return when (m.groupValues[2]) {
                "in" -> v * 72f
                "px" -> v * 0.75f
                "cm" -> v * 28.35f
                "mm" -> v * 2.835f
                else -> v
            }
        }
        val w = dim("width") ?: return null
        val h = dim("height") ?: return null
        return Pair(w, h)
    }

    private fun runChildren(
        r: XN, pStyle: String?, out: ArrayList<WInline>
    ) {
        val direct = RProps()
        var rStyle: String? = null
        val rpr = r.kid("rPr")
        if (rpr != null) {
            readRPr(rpr, direct, themeMajor, themeMinor)
            rStyle = rpr.kid("rStyle")?.a("val")
        }
        val rp = resolveR(pStyle, rStyle, direct)
        val sb = StringBuilder()
        fun flush() {
            if (sb.isNotEmpty()) {
                out.add(WText(sb.toString(), rp))
                sb.setLength(0)
            }
        }
        fun child(k: XN) {
            when (k.ln) {
                "fldChar" -> when (k.a("fldCharType")) {
                    "begin" -> {
                        fieldCode = true
                        instr.setLength(0)
                    }
                    "separate" -> {
                        fieldCode = false
                        val ins = instr.toString().uppercase()
                        if (hf && ins.contains("NUMPAGES")) {
                            flush()
                            out.add(WPageNo(2, rp))
                            skipResult = true
                        } else if (hf && ins.contains("PAGE")) {
                            flush()
                            out.add(WPageNo(1, rp))
                            skipResult = true
                        }
                    }
                    "end" -> {
                        fieldCode = false
                        skipResult = false
                    }
                }
                "instrText" -> if (fieldCode) instr.append(k.text ?: "")
                "t" -> if (!skipResult && !fieldCode) sb.append(k.text ?: "")
                "tab" -> if (!skipResult) sb.append('\t')
                "br" -> if (k.a("type") == "page") {
                    flush()
                    out.add(WPageBreakMarker)
                } else if (!skipResult) sb.append('\n')
                "cr" -> if (!skipResult) sb.append('\n')
                "noBreakHyphen" -> sb.append('-')
                "drawing" -> {
                    val rid = findBlip(k)
                    val target = if (rid != null) rels[rid] else null
                    val ext = extentPt(k)
                    if (target != null && ext != null) {
                        flush()
                        out.add(WImg(resolvePath("word", target), ext.first, ext.second))
                    }
                }
                "pict", "object" -> {
                    val id = k.find("imagedata")?.a("id")
                    val target = if (id != null) rels[id] else null
                    val ext = vmlSize(k)
                    if (target != null && ext != null) {
                        flush()
                        out.add(WImg(resolvePath("word", target), ext.first, ext.second))
                    }
                }
                "AlternateContent" -> {
                    for (c in k.kids) if (c.ln == "Choice") for (g in c.kids) child(g)
                }
            }
        }
        for (k in r.kids) child(k)
        flush()
    }

    private fun collect(node: XN, pStyle: String?, out: ArrayList<WInline>) {
        for (k in node.kids) {
            when (k.ln) {
                "r" -> runChildren(k, pStyle, out)
                "hyperlink", "ins", "smartTag", "sdt", "sdtContent", "customXml", "moveTo", "bdo", "dir" -> collect(k, pStyle, out)
                "fldSimple" -> {
                    val ins = (k.a("instr") ?: "").uppercase()
                    if (hf && ins.contains("NUMPAGES")) out.add(WPageNo(2, resolveR(pStyle, null, RProps())))
                    else if (hf && ins.contains("PAGE")) out.add(WPageNo(1, resolveR(pStyle, null, RProps())))
                    else collect(k, pStyle, out)
                }
                "AlternateContent" -> {
                    for (c in k.kids) if (c.ln == "Choice") collect(c, pStyle, out)
                }
            }
        }
    }

    private fun labelFor(p: WP): Triple<String?, NumLevel?, Int> {
        val nid = p.numId ?: return Triple(null, null, 0)
        if (nid == 0) return Triple(null, null, 0)
        val il = (p.ilvl ?: 0).coerceIn(0, 8)
        val lvl = numbering.level(nid, il) ?: return Triple(null, null, 0)
        val aid = numbering.abstractId(nid) ?: return Triple(null, null, 0)
        val arr = counters.getOrPut(aid) { IntArray(9) { -1 } }
        // start values
        for (i in 0..il) {
            if (arr[i] < 0) {
                val lv = numbering.abstracts[aid]?.get(i)
                arr[i] = (numbering.overrides[nid.toLong() * 100 + i] ?: lv?.start ?: 1) - 1
            }
        }
        arr[il] = arr[il] + 1
        for (i in il + 1..8) arr[i] = -1
        if (lvl.fmt == "bullet") return Triple(bulletChar(lvl.text), lvl, il)
        var text = lvl.text
        for (i in 1..9) {
            val ph = "%$i"
            if (text.contains(ph)) {
                val f = numbering.abstracts[aid]?.get(i - 1)?.fmt ?: "decimal"
                val value = if (arr[i - 1] < 0) 1 else arr[i - 1]
                text = text.replace(ph, fmtNumber(value, f))
            }
        }
        return Triple(text, lvl, il)
    }

    private fun paragraph(p: XN, out: ArrayList<WBlock>) {
        val pPr = p.kid("pPr")
        val pStyle = pPr?.kid("pStyle")?.a("val")
        val direct = WP()
        readPPr(pPr, direct)
        val resolved = resolveP(pStyle, direct)
        val inl = ArrayList<WInline>()
        collect(p, pStyle, inl)

        val styleName = (styles[pStyle ?: ""]?.name ?: pStyle ?: "").lowercase()
        var heading = 0
        if (styleName.startsWith("heading")) heading = styleName.filter { it.isDigit() }.toIntOrNull() ?: 1
        else if (styleName == "title") heading = 1

        // numbering from the paragraph or its style
        val (labelText, lvl, _) = labelFor(resolved)
        if (lvl != null) {
            if (direct.left == null && lvl.left != null) resolved.left = lvl.left
            if (direct.hanging == null && direct.first == null && lvl.hanging != null) {
                resolved.hanging = lvl.hanging
                resolved.first = null
            }
        }
        val markRp = resolveR(pStyle, null, RProps().also { readRPr(pPr?.kid("rPr"), it, themeMajor, themeMinor) })
        val labelRp: RProps? = if (labelText != null) {
            val lr = RProps()
            lr.copyFrom(markRp)
            val firstText = inl.firstOrNull { it is WText } as? WText
            if (firstText != null) {
                lr.sizePt = firstText.rp.sizePt ?: lr.sizePt
                lr.color = firstText.rp.color ?: lr.color
                lr.bold = firstText.rp.bold ?: lr.bold
            }
            lr
        } else null

        // split at explicit page breaks
        var seg = ArrayList<WInline>()
        var first = true
        fun emit(last: Boolean) {
            val plain = seg.filterIsInstance<WText>().joinToString("") { it.text }
            val pp = WP()
            pp.merge(resolved)
            if (!first) pp.before = 0f
            if (!last) pp.after = 0f
            out.add(WPara(pp, seg, markRp, if (first) labelText else null, if (first) labelRp else null, heading, plain))
            first = false
            seg = ArrayList()
        }
        if (resolved.pageBreakBefore == true && out.isNotEmpty()) out.add(WPageBreakBlock)
        for (item in inl) {
            if (item === WPageBreakMarker) {
                emit(false)
                out.add(WPageBreakBlock)
            } else seg.add(item)
        }
        emit(true)
    }

    // ---- tables

    private fun table(t: XN, out: ArrayList<WBlock>) {
        val tblPr = t.kid("tblPr")
        val borders = tblBordersFor(tblPr?.kid("tblStyle")?.a("val"), tblPr?.kid("tblBorders"))
        val grid = t.kid("tblGrid")?.kidsNamed("gridCol")?.map { (twip(it.a("w")) ?: 60f) }?.toFloatArray() ?: FloatArray(0)
        val indent = twip(tblPr?.kid("tblInd")?.a("w")) ?: 0f
        val mar = tblPr?.kid("tblCellMar")
        val marL = twip(mar?.kid("left")?.a("w") ?: mar?.kid("start")?.a("w")) ?: 5.4f
        val marR = twip(mar?.kid("right")?.a("w") ?: mar?.kid("end")?.a("w")) ?: 5.4f
        val marT = twip(mar?.kid("top")?.a("w")) ?: 0f
        val marB = twip(mar?.kid("bottom")?.a("w")) ?: 0f

        val rows = ArrayList<WRowM>()
        for (tr in t.kidsNamed("tr")) {
            val cells = ArrayList<WCellM>()
            for (tc in tr.kidsNamed("tc")) {
                val pr = tc.kid("tcPr")
                val span = pr?.kid("gridSpan")?.a("val")?.toIntOrNull() ?: 1
                val vm = pr?.kid("vMerge")
                val vMerge = if (vm == null) 0 else if (vm.a("val") == "restart") 1 else 2
                val shd = hexColor(pr?.kid("shd")?.a("fill"))
                val b = pr?.kid("tcBorders")
                val cb = if (b == null) null else arrayOf(
                    readBorder(b.kid("top")), readBorder(b.kid("left")), readBorder(b.kid("bottom")), readBorder(b.kid("right"))
                )
                val cellBlocks = ArrayList<WBlock>()
                walk(tc, cellBlocks)
                cells.add(WCellM(cellBlocks, span, vMerge, shd, cb, pr?.kid("vAlign")?.a("val")))
            }
            val trh = tr.kid("trPr")?.kid("trHeight")
            val h = twip(trh?.a("val"))
            rows.add(WRowM(cells, if (h != null && h > 0f) h else null, trh?.a("hRule") == "exact"))
        }
        out.add(WTable(grid, rows, borders, indent, marL, marR, marT, marB))
    }
}
