package com.reader.app.office

import android.graphics.Color
import com.reader.app.epub.resolvePath
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipFile
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class XlBorder(val w: Float, val color: Int)

class XlStyle(
    val fontName: String?,
    val sizePt: Float,
    val bold: Boolean,
    val italic: Boolean,
    val underline: Boolean,
    val strike: Boolean,
    val color: Int?,
    val fill: Int?,
    val left: XlBorder?,
    val right: XlBorder?,
    val top: XlBorder?,
    val bottom: XlBorder?,
    val halign: String?,
    val valign: String?,
    val wrap: Boolean
)

class SheetData(
    val name: String,
    val rows: List<Array<String>>,
    val cols: Int,
    val styleIdx: List<IntArray>? = null,
    val styles: List<XlStyle>? = null,
    val colWidth: FloatArray? = null,   // in Excel character units, index = column
    val rowHeight: Map<Int, Float>? = null, // points, index = row
    val defaultRowH: Float = 15f,
    val defaultColW: Float = 8.43f,
    val merges: List<IntArray>? = null, // r1, c1, r2, c2 (0-based, inclusive)
    val showGrid: Boolean = true
)

/** Excel number / date format codes -> display text. */
internal object XlFormat {
    private val builtIn = mapOf(
        1 to "0", 2 to "0.00", 3 to "#,##0", 4 to "#,##0.00", 9 to "0%", 10 to "0.00%",
        11 to "0.00E+00", 14 to "m/d/yyyy", 15 to "d-mmm-yy", 16 to "d-mmm", 17 to "mmm-yy",
        18 to "h:mm AM/PM", 19 to "h:mm:ss AM/PM", 20 to "h:mm", 21 to "h:mm:ss", 22 to "m/d/yyyy h:mm",
        37 to "#,##0;(#,##0)", 38 to "#,##0;(#,##0)", 39 to "#,##0.00;(#,##0.00)", 40 to "#,##0.00;(#,##0.00)",
        41 to "#,##0", 42 to "#,##0", 43 to "#,##0.00", 44 to "#,##0.00", 45 to "mm:ss", 46 to "[h]:mm:ss",
        47 to "mm:ss.0", 48 to "##0.0E+0", 49 to "@"
    )

    fun codeFor(id: Int, custom: Map<Int, String>): String? = custom[id] ?: builtIn[id]

    private val months = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    private val days = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    fun general(raw: String): String {
        return try {
            val bd = BigDecimal(raw)
            if (bd.abs() >= BigDecimal("1E11") || (bd.signum() != 0 && bd.abs() < BigDecimal("1E-9"))) {
                String.format(Locale.US, "%.5E", bd.toDouble())
            } else bd.round(MathContext(12)).stripTrailingZeros().toPlainString()
        } catch (e: Throwable) {
            raw
        }
    }

    private fun sections(code: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        for (c in code) {
            if (c == '"') q = !q
            if (c == ';' && !q) {
                out.add(sb.toString())
                sb.setLength(0)
            } else sb.append(c)
        }
        out.add(sb.toString())
        return out
    }

    private fun isDate(fmt: String): Boolean {
        var q = false
        var br = false
        var i = 0
        while (i < fmt.length) {
            val c = fmt[i]
            when {
                c == '"' -> q = !q
                q -> {}
                c == '[' -> br = true
                c == ']' -> br = false
                br -> if (c == 'h' || c == 's') return true
                c == '\\' || c == '_' || c == '*' -> i++
                c.lowercaseChar() in "ydhs" -> return true
            }
            i++
        }
        return false
    }

    fun format(raw: String, codeIn: String?): String {
        if (codeIn == null || codeIn.equals("General", true)) return general(raw)
        val v = raw.toDoubleOrNull() ?: return raw
        val secs = sections(codeIn)
        var code = secs[0]
        var value = v
        var negSection = false
        if (v < 0 && secs.size > 1) {
            code = secs[1]
            value = -v
            negSection = true
        } else if (v == 0.0 && secs.size > 2) code = secs[2]
        // currency / locale brackets: [$$-409] -> $ ; other brackets dropped
        code = Regex("\\[\\$([^\\]-]*)(?:-[^\\]]*)?\\]").replace(code) { it.groupValues[1] }
        val elapsed = code.contains("[h]", true)
        code = Regex("\\[[^\\]]*\\]").replace(code, "")
        if (code == "@" || code.isEmpty()) return general(raw)
        return if (isDate(code)) formatDate(v, code, elapsed) else formatNumber(value, code, v < 0 && !negSection)
    }

    private fun formatDate(serial: Double, code: String, elapsed: Boolean): String {
        val days0 = floor(serial)
        val frac = serial - days0
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.clear()
        cal.set(1899, 11, 30)
        cal.add(Calendar.DAY_OF_YEAR, days0.toInt())
        var totalSec = Math.round(frac * 86400.0).toInt()
        var hour = totalSec / 3600
        val min = (totalSec % 3600) / 60
        val sec = totalSec % 60
        val ampm = code.contains("AM/PM", true) || code.contains("A/P", true)
        val hourShown = if (elapsed) (days0.toInt() * 24 + hour) else if (ampm) (if (hour % 12 == 0) 12 else hour % 12) else hour
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH)
        val d = cal.get(Calendar.DAY_OF_MONTH)
        val dow = cal.get(Calendar.DAY_OF_WEEK) - 1
        val out = StringBuilder()
        var i = 0
        var lastWasHour = false
        while (i < code.length) {
            val c = code[i]
            val lc = c.lowercaseChar()
            fun run(ch: Char): Int {
                var n = 0
                while (i + n < code.length && code[i + n].lowercaseChar() == ch) n++
                return n
            }
            when {
                c == '"' -> {
                    val end = code.indexOf('"', i + 1).let { if (it < 0) code.length else it }
                    out.append(code, i + 1, end)
                    i = end + 1
                    continue
                }
                c == '\\' && i + 1 < code.length -> {
                    out.append(code[i + 1])
                    i += 2
                    continue
                }
                c == '_' || c == '*' -> {
                    if (c == '_') out.append(' ')
                    i += 2
                    continue
                }
                lc == 'y' -> {
                    val n = run('y')
                    out.append(if (n <= 2) (y % 100).toString().padStart(2, '0') else y.toString())
                    i += n
                }
                lc == 'd' -> {
                    val n = run('d')
                    out.append(
                        when {
                            n == 1 -> d.toString()
                            n == 2 -> d.toString().padStart(2, '0')
                            n == 3 -> days[dow].take(3)
                            else -> days[dow]
                        }
                    )
                    i += n
                }
                lc == 'h' -> {
                    val n = run('h')
                    out.append(if (n >= 2) hourShown.toString().padStart(2, '0') else hourShown.toString())
                    i += n
                    lastWasHour = true
                    continue
                }
                lc == 'm' -> {
                    val n = run('m')
                    // minutes right after hours or right before seconds
                    var j = i + n
                    while (j < code.length && !code[j].isLetter()) j++
                    val nextIsSec = j < code.length && code[j].lowercaseChar() == 's'
                    if (lastWasHour || nextIsSec) {
                        out.append(if (n >= 2) min.toString().padStart(2, '0') else min.toString())
                    } else {
                        out.append(
                            when {
                                n == 1 -> (m + 1).toString()
                                n == 2 -> (m + 1).toString().padStart(2, '0')
                                n == 3 -> months[m].take(3)
                                else -> months[m]
                            }
                        )
                    }
                    i += n
                    lastWasHour = false
                    continue
                }
                lc == 's' -> {
                    val n = run('s')
                    out.append(if (n >= 2) sec.toString().padStart(2, '0') else sec.toString())
                    i += n
                }
                (c == 'A' || c == 'a') && code.regionMatches(i, "AM/PM", 0, 5, true) -> {
                    out.append(if (hour < 12) "AM" else "PM")
                    i += 5
                }
                (c == 'A' || c == 'a') && code.regionMatches(i, "A/P", 0, 3, true) -> {
                    out.append(if (hour < 12) "A" else "P")
                    i += 3
                }
                else -> {
                    out.append(c)
                    i++
                    if (c != ':' && c != ' ') lastWasHour = false
                    continue
                }
            }
            lastWasHour = false
        }
        return out.toString()
    }

    private fun floor(d: Double): Double = Math.floor(d)

    private fun formatNumber(valueIn: Double, code: String, addMinus: Boolean): String {
        var value = valueIn
        // split the code into literal prefix / numeric pattern / literal suffix
        val prefix = StringBuilder()
        val pattern = StringBuilder()
        val suffix = StringBuilder()
        var phase = 0
        var q = false
        var i = 0
        var percent = false
        while (i < code.length) {
            val c = code[i]
            if (c == '"') {
                q = !q
                i++
                continue
            }
            val lit: Char? = when {
                q -> c
                c == '\\' && i + 1 < code.length -> {
                    i++
                    code[i]
                }
                c == '_' -> {
                    i++
                    ' '
                }
                c == '*' -> {
                    i++
                    null
                }
                else -> null
            }
            if (q || lit != null) {
                val ch = lit ?: c
                if (phase == 0) prefix.append(ch) else {
                    phase = 2
                    suffix.append(ch)
                }
            } else if (c == '#' || c == '0' || c == '?' || c == '.' || c == ',' || c == 'E' || c == 'e' || c == '+' && pattern.endsWith("E") || c == '-' && pattern.endsWith("E")) {
                if (phase == 2) suffix.append(c) else {
                    phase = 1
                    pattern.append(c)
                }
            } else if (c == '%') {
                percent = true
                if (phase == 0) prefix.append('%') else {
                    phase = 2
                    suffix.append('%')
                }
            } else {
                if (phase == 0) prefix.append(c) else {
                    phase = 2
                    suffix.append(c)
                }
            }
            i++
        }
        if (percent) value *= 100.0
        val pat = pattern.toString()
        val body: String
        if (pat.contains('E', true)) {
            val decimals = pat.substringAfter('.', "").takeWhile { it == '0' || it == '#' }.length
            body = String.format(Locale.US, "%.${decimals}E", value)
        } else {
            val decimals = pat.substringAfter('.', "").count { it == '0' || it == '#' }
            val minDecimals = pat.substringAfter('.', "").count { it == '0' }
            val grouping = pat.substringBefore('.').contains(',')
            val minInt = pat.substringBefore('.').count { it == '0' }
            val df = DecimalFormat("0", DecimalFormatSymbols(Locale.US))
            df.maximumFractionDigits = decimals
            df.minimumFractionDigits = minDecimals
            df.isGroupingUsed = grouping
            if (grouping) df.groupingSize = 3
            df.minimumIntegerDigits = max(minInt, if (pat.isEmpty()) 1 else 0)
            df.roundingMode = RoundingMode.HALF_UP
            body = df.format(value)
        }
        val s = prefix.toString() + body + suffix.toString()
        return if (addMinus) "-$s" else s
    }
}

/** Reads sheet data AND the visual formatting (fonts, fills, borders, widths, merges). */
object SheetParser {
    private fun colIndex(ref: String): Int {
        var n = 0
        for (c in ref) {
            if (c in 'A'..'Z') n = n * 26 + (c - 'A' + 1)
            else if (c in 'a'..'z') n = n * 26 + (c - 'a' + 1)
            else break
        }
        return n - 1
    }

    private val indexedColors = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt()
    )

    private class Palette(val theme: IntArray)

    private fun xlColor(n: XN?, pal: Palette): Int? {
        if (n == null) return null
        n.a("rgb")?.let { rgb ->
            return try {
                Color.parseColor("#" + rgb.takeLast(6))
            } catch (_: Throwable) {
                null
            }
        }
        n.a("theme")?.toIntOrNull()?.let { t ->
            // Excel theme order: lt1, dk1, lt2, dk2, accent1..6, hlink, folHlink
            val base = pal.theme.getOrElse(t) { Color.BLACK }
            val tint = n.a("tint")?.toFloatOrNull() ?: 0f
            return applyTint(base, tint)
        }
        n.a("indexed")?.toIntOrNull()?.let { i ->
            return if (i < 8) indexedColors[i] else if (i < 16) indexedColors[i - 8] else if (i == 64) Color.BLACK else Color.BLACK
        }
        return null
    }

    private fun applyTint(c: Int, tint: Float): Int {
        if (tint == 0f) return c
        fun ch(v: Int): Int = if (tint > 0) (v + (255 - v) * tint).toInt() else (v * (1 + tint)).toInt()
        return Color.rgb(ch(Color.red(c)).coerceIn(0, 255), ch(Color.green(c)).coerceIn(0, 255), ch(Color.blue(c)).coerceIn(0, 255))
    }

    private fun border(n: XN?, pal: Palette): XlBorder? {
        if (n == null) return null
        val style = n.a("style") ?: return null
        if (style == "none") return null
        val w = when (style) {
            "hair" -> 0.5f
            "thin", "dashed", "dotted", "dashDot", "dashDotDot" -> 1f
            "medium", "mediumDashed", "mediumDashDot", "mediumDashDotDot", "slantDashDot" -> 2f
            "thick" -> 3f
            "double" -> 2.5f
            else -> 1f
        }
        return XlBorder(w, xlColor(n.kid("color"), pal) ?: Color.BLACK)
    }

    private fun parseStyles(b: ByteArray?, pal: Palette): Triple<List<XlStyle>, List<String?>, Map<Int, String>> {
        val styles = ArrayList<XlStyle>()
        val fmts = ArrayList<String?>()
        val custom = HashMap<Int, String>()
        if (b == null) return Triple(styles, fmts, custom)
        try {
            val root = parseXml(b)
            val ss = root.find("styleSheet") ?: return Triple(styles, fmts, custom)
            ss.kid("numFmts")?.kidsNamed("numFmt")?.forEach { n ->
                val id = n.a("numFmtId")?.toIntOrNull()
                val code = n.a("formatCode")
                if (id != null && code != null) custom[id] = code
            }
            class F(val name: String?, val sz: Float, val b: Boolean, val i: Boolean, val u: Boolean, val st: Boolean, val color: Int?)
            val fonts = ArrayList<F>()
            ss.kid("fonts")?.kidsNamed("font")?.forEach { f ->
                fonts.add(
                    F(
                        f.kid("name")?.a("val"),
                        f.kid("sz")?.a("val")?.toFloatOrNull() ?: 11f,
                        f.kid("b") != null && f.kid("b")?.a("val") != "0",
                        f.kid("i") != null && f.kid("i")?.a("val") != "0",
                        f.kid("u") != null && f.kid("u")?.a("val") != "none",
                        f.kid("strike") != null,
                        xlColor(f.kid("color"), pal)
                    )
                )
            }
            val fills = ArrayList<Int?>()
            ss.kid("fills")?.kidsNamed("fill")?.forEach { f ->
                val pf = f.kid("patternFill")
                fills.add(if (pf?.a("patternType") == "solid") (xlColor(pf.kid("fgColor"), pal) ?: Color.WHITE) else null)
            }
            class Bd(val l: XlBorder?, val r: XlBorder?, val t: XlBorder?, val bt: XlBorder?)
            val borders = ArrayList<Bd>()
            ss.kid("borders")?.kidsNamed("border")?.forEach { bd ->
                borders.add(
                    Bd(
                        border(bd.kid("left") ?: bd.kid("start"), pal), border(bd.kid("right") ?: bd.kid("end"), pal),
                        border(bd.kid("top"), pal), border(bd.kid("bottom"), pal)
                    )
                )
            }
            ss.kid("cellXfs")?.kidsNamed("xf")?.forEach { xf ->
                val f = fonts.getOrNull(xf.a("fontId")?.toIntOrNull() ?: 0)
                val fill = fills.getOrNull(xf.a("fillId")?.toIntOrNull() ?: 0)
                val bd = borders.getOrNull(xf.a("borderId")?.toIntOrNull() ?: 0)
                val al = xf.kid("alignment")
                styles.add(
                    XlStyle(
                        f?.name, f?.sz ?: 11f, f?.b ?: false, f?.i ?: false, f?.u ?: false, f?.st ?: false, f?.color,
                        fill, bd?.l, bd?.r, bd?.t, bd?.bt,
                        al?.a("horizontal"), al?.a("vertical"), al?.a("wrapText") == "1" || al?.a("wrapText") == "true"
                    )
                )
                val id = xf.a("numFmtId")?.toIntOrNull() ?: 0
                fmts.add(XlFormat.codeFor(id, custom))
            }
        } catch (_: Throwable) {
        }
        return Triple(styles, fmts, custom)
    }

    fun parseXlsx(path: String): List<SheetData> {
        val zip = ZipFile(path)
        try {
            fun read(name: String): ByteArray? {
                val e = zip.getEntry(name) ?: return null
                return zip.getInputStream(e).use { it.readBytes() }
            }

            // theme colours (lt1, dk1, lt2, dk2, accents...)
            val themeColors = IntArray(12) { Color.BLACK }
            themeColors[0] = Color.WHITE
            read("xl/theme/theme1.xml")?.let { tb ->
                try {
                    val cs = parseXml(tb).find("clrScheme")
                    val order = listOf("lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink")
                    if (cs != null) {
                        for ((i, nm) in order.withIndex()) {
                            val c = cs.kid(nm)?.kids?.firstOrNull() ?: continue
                            val v = if (c.ln == "sysClr") (hexColor(c.a("lastClr")) ?: if (nm == "lt1") Color.WHITE else Color.BLACK) else hexColor(c.a("val"))
                            if (v != null) themeColors[i] = v
                        }
                    }
                } catch (_: Throwable) {
                }
            }
            val pal = Palette(themeColors)
            val (styles, fmts, _) = parseStyles(read("xl/styles.xml"), pal)

            // shared strings
            val shared = ArrayList<String>()
            read("xl/sharedStrings.xml")?.let { b ->
                try {
                    val root = parseXml(b)
                    val sst = root.find("sst")
                    if (sst != null) for (si in sst.kidsNamed("si")) shared.add(collectT(si))
                } catch (_: Throwable) {
                }
            }

            // sheets + relationships
            val rels = HashMap<String, String>()
            read("xl/_rels/workbook.xml.rels")?.let { b ->
                try {
                    parseXml(b).kids.firstOrNull()?.kids?.forEach { r ->
                        val id = r.a("Id")
                        val t = r.a("Target")
                        if (id != null && t != null) rels[id] = t
                    }
                } catch (_: Throwable) {
                }
            }
            val sheetRefs = ArrayList<Pair<String, String>>()
            val wb = read("xl/workbook.xml") ?: throw IllegalStateException("not an xlsx")
            try {
                val sheets = parseXml(wb).find("sheets")
                if (sheets != null) {
                    for (sh in sheets.kidsNamed("sheet")) {
                        val name = sh.a("name") ?: "Sheet"
                        var rid: String? = null
                        for ((k, v) in sh.attrs) if (k.substringAfter(':') == "id" && k.contains(':')) rid = v
                        val target = if (rid != null) rels[rid] else null
                        if (target != null) {
                            val entry = if (target.startsWith("/")) target.substring(1) else resolvePath("xl", target)
                            sheetRefs.add(Pair(name, entry))
                        }
                    }
                }
            } catch (_: Throwable) {
            }
            if (sheetRefs.isEmpty()) {
                val found = ArrayList<String>()
                val en = zip.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.name.startsWith("xl/worksheets/sheet") && e.name.endsWith(".xml")) found.add(e.name)
                }
                found.sortBy { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
                for ((i, f) in found.withIndex()) sheetRefs.add(Pair("Sheet ${i + 1}", f))
            }

            val out = ArrayList<SheetData>()
            for ((name, entry) in sheetRefs) {
                val bytes = read(entry) ?: continue
                val rows = ArrayList<Array<String>>()
                val styleRows = ArrayList<IntArray>()
                val rowHeights = HashMap<Int, Float>()
                var maxCols = 1
                var defRowH = 15f
                var defColW = 8.43f
                val colDefs = ArrayList<FloatArray>() // min, max, width(-1 hidden)
                val merges = ArrayList<IntArray>()
                var showGrid = true

                val p = android.util.Xml.newPullParser()
                try {
                    p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
                } catch (_: Throwable) {
                }
                p.setInput(java.io.ByteArrayInputStream(bytes), null)
                var cells = ArrayList<String>()
                var cst = ArrayList<Int>()
                var rowIdx = 0
                var rowHt: Float? = null
                var rowHidden = false
                var cellCol = 0
                var cellType = ""
                var cellStyle = 0
                var value = StringBuilder()
                var inIs = false
                var ev = p.eventType
                while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                    if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                        val n = (p.name ?: "").substringAfter(':')
                        when (n) {
                            "sheetFormatPr" -> {
                                p.getAttributeValue(null, "defaultRowHeight")?.toFloatOrNull()?.let { defRowH = it }
                                p.getAttributeValue(null, "defaultColWidth")?.toFloatOrNull()?.let { defColW = it }
                            }
                            "sheetView" -> if (p.getAttributeValue(null, "showGridLines") == "0") showGrid = false
                            "col" -> {
                                val mn = (p.getAttributeValue(null, "min")?.toIntOrNull() ?: 1) - 1
                                val mx = (p.getAttributeValue(null, "max")?.toIntOrNull() ?: 1) - 1
                                val w = p.getAttributeValue(null, "width")?.toFloatOrNull() ?: -2f
                                val hidden = p.getAttributeValue(null, "hidden") == "1"
                                colDefs.add(floatArrayOf(mn.toFloat(), mx.toFloat(), if (hidden) -1f else w))
                            }
                            "row" -> {
                                if (rows.size < 20000) {
                                    val r = p.getAttributeValue(null, "r")?.toIntOrNull()
                                    if (r != null) {
                                        while (rows.size < r - 1 && rows.size < 20000) {
                                            rows.add(emptyArray())
                                            styleRows.add(IntArray(0))
                                        }
                                    }
                                }
                                rowIdx = rows.size
                                cells = ArrayList()
                                cst = ArrayList()
                                rowHt = p.getAttributeValue(null, "ht")?.toFloatOrNull()
                                rowHidden = p.getAttributeValue(null, "hidden") == "1"
                            }
                            "c" -> {
                                val ref = p.getAttributeValue(null, "r") ?: ""
                                cellCol = if (ref.isNotEmpty()) colIndex(ref) else cells.size
                                if (cellCol < 0) cellCol = cells.size
                                cellType = p.getAttributeValue(null, "t") ?: ""
                                cellStyle = p.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                                value = StringBuilder()
                                inIs = false
                            }
                            "v" -> try {
                                value.append(p.nextText())
                            } catch (_: Throwable) {
                            }
                            "is" -> inIs = true
                            "t" -> if (inIs) {
                                try {
                                    value.append(p.nextText())
                                } catch (_: Throwable) {
                                }
                            }
                            "mergeCell" -> {
                                val ref = p.getAttributeValue(null, "ref")
                                val parts = ref?.split(':')
                                if (parts != null && parts.size == 2) {
                                    fun split(a: String): Pair<Int, Int> {
                                        val letters = a.takeWhile { it.isLetter() }
                                        val num = a.drop(letters.length).toIntOrNull() ?: 1
                                        return Pair(num - 1, colIndex(letters))
                                    }
                                    val (r1, c1) = split(parts[0])
                                    val (r2, c2) = split(parts[1])
                                    merges.add(intArrayOf(r1, c1, r2, c2))
                                }
                            }
                        }
                    } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                        when ((p.name ?: "").substringAfter(':')) {
                            "is" -> inIs = false
                            "c" -> {
                                val raw = value.toString()
                                val text = when (cellType) {
                                    "s" -> raw.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                                    "b" -> if (raw == "1") "TRUE" else "FALSE"
                                    "str", "e", "inlineStr" -> raw
                                    else -> if (raw.isEmpty()) "" else XlFormat.format(raw, fmts.getOrNull(cellStyle))
                                }
                                if (cellCol in 0..300) {
                                    while (cells.size < cellCol) {
                                        cells.add("")
                                        cst.add(0)
                                    }
                                    if (cells.size == cellCol) {
                                        cells.add(text)
                                        cst.add(cellStyle)
                                    } else {
                                        cells[cellCol] = text
                                        cst[cellCol] = cellStyle
                                    }
                                }
                            }
                            "row" -> {
                                if (rows.size < 20000) {
                                    maxCols = max(maxCols, cells.size)
                                    rows.add(cells.toTypedArray())
                                    styleRows.add(cst.toIntArray())
                                    val ht = rowHt
                                    if (rowHidden) rowHeights[rowIdx] = 0f else if (ht != null) rowHeights[rowIdx] = ht
                                }
                            }
                        }
                    }
                    ev = p.next()
                }
                val colWidths = FloatArray(max(maxCols, 1)) { defColW }
                for (d in colDefs) {
                    val mn = d[0].toInt()
                    val mx = d[1].toInt()
                    for (i in max(0, mn)..min(mx, colWidths.size - 1)) {
                        if (d[2] == -1f) colWidths[i] = 0f else if (d[2] >= 0f) colWidths[i] = d[2]
                    }
                }
                out.add(
                    SheetData(
                        name, rows, max(1, maxCols), styleRows, styles, colWidths,
                        rowHeights, defRowH, defColW, merges, showGrid
                    )
                )
            }
            if (out.isEmpty()) throw IllegalStateException("no sheets")
            return out
        } finally {
            try {
                zip.close()
            } catch (_: Throwable) {
            }
        }
    }

    private fun nodeText(n: XN?): String = n?.text?.toString() ?: ""

    /** All <t> text below a node (shared string item or inline string). */
    private fun collectT(n: XN?): String {
        if (n == null) return ""
        val sb = StringBuilder()
        fun walk(x: XN) {
            if (x.ln == "t") sb.append(x.text ?: "")
            else if (x.ln != "rPh" && x.ln != "phoneticPr") for (k in x.kids) walk(k)
        }
        walk(n)
        return sb.toString()
    }

    fun parseCsv(path: String): List<SheetData> {
        val bytes = java.io.File(path).readBytes()
        var text = String(bytes, Charsets.UTF_8)
        if (text.startsWith("\uFEFF")) text = text.substring(1)
        val firstLine = text.lineSequence().firstOrNull() ?: ""
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } } ?: ','
        val rows = ArrayList<Array<String>>()
        var maxCols = 0
        for (line in text.lineSequence()) {
            if (rows.size >= 20000) break
            val cells = ArrayList<String>()
            val sb = StringBuilder()
            var q = false
            var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (q) {
                    if (ch == '"') {
                        if (i + 1 < line.length && line[i + 1] == '"') {
                            sb.append('"')
                            i++
                        } else q = false
                    } else sb.append(ch)
                } else if (ch == '"') q = true
                else if (ch == delim) {
                    cells.add(sb.toString())
                    sb.setLength(0)
                } else sb.append(ch)
                i++
            }
            cells.add(sb.toString())
            maxCols = max(maxCols, cells.size)
            rows.add(cells.toTypedArray())
        }
        return listOf(SheetData("CSV", rows, max(1, min(maxCols, 300))))
    }
}
