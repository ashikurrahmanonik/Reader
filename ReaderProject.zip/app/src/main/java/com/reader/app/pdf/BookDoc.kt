package com.reader.app.pdf

import android.graphics.Bitmap

data class TocEntry(val title: String, val page: Int)

/** Anything the reader can page through: a PDF or an EPUB. */
interface BookDoc {
    val pageCount: Int
    val supportsZoom: Boolean get() = false

    fun renderPage(index: Int, w: Int, h: Int): Bitmap

    /** Sharp render of the visible part while zoomed (PDF only). */
    fun renderRegion(index: Int, w: Int, h: Int, zoom: Float, tx: Float, ty: Float): Bitmap? = null

    /** A position that survives re-pagination (EPUB). -1 when not needed. */
    fun locatorOf(page: Int): Long = -1L

    fun toc(): List<TocEntry> = emptyList()

    /** Legacy fonts used by the document that are not installed in the app. */
    val missingFonts: Set<String> get() = emptySet()

    fun close()
}
