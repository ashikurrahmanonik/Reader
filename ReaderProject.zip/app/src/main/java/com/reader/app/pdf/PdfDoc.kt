package com.reader.app.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer
) {
    val pageCount: Int = renderer.pageCount
    private val lock = Any()

    @Volatile
    private var closed = false

    /** Renders a page fitted & centered into a w x h bitmap on a white background. */
    fun renderPage(index: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        synchronized(lock) {
            if (closed) return bmp
            val page = renderer.openPage(index)
            try {
                val scale = min(w.toFloat() / page.width, h.toFloat() / page.height)
                val dx = (w - page.width * scale) / 2f
                val dy = (h - page.height * scale) / 2f
                val m = Matrix()
                m.setScale(scale, scale)
                m.postTranslate(dx, dy)
                page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            } finally {
                page.close()
            }
        }
        return bmp
    }

    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            try {
                renderer.close()
            } catch (_: Throwable) {
            }
            try {
                pfd.close()
            } catch (_: Throwable) {
            }
        }
    }

    class OpenResult(val doc: PdfDoc?, val error: String?)

    companion object {
        fun open(path: String): OpenResult {
            return try {
                val pfd = ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    val r = PdfRenderer(pfd)
                    if (r.pageCount <= 0) {
                        r.close()
                        pfd.close()
                        OpenResult(null, "This PDF has no pages")
                    } else {
                        OpenResult(PdfDoc(pfd, r), null)
                    }
                } catch (e: Throwable) {
                    try {
                        pfd.close()
                    } catch (_: Throwable) {
                    }
                    throw e
                }
            } catch (e: SecurityException) {
                OpenResult(null, "This PDF is password protected")
            } catch (e: Throwable) {
                OpenResult(null, "Couldn't open this PDF")
            }
        }
    }
}

/** Small in-memory cache of first-page thumbnails for the file lists. */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(64)
    private val gate = Semaphore(2)

    suspend fun load(path: String, modified: Long): Bitmap? {
        val key = "$path:$modified"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                cache.get(key) ?: render(path)?.also { cache.put(key, it) }
            }
        }
    }

    private fun render(path: String): Bitmap? {
        val res = PdfDoc.open(path)
        val doc = res.doc ?: return null
        return try {
            doc.renderPage(0, 240, 320)
        } catch (e: Throwable) {
            null
        } finally {
            doc.close()
        }
    }
}
