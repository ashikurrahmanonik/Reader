package com.reader.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.reader.app.data.isEpubPath
import com.reader.app.epub.EpubParser
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    private val tempFile: File?
) : BookDoc {
    override val pageCount: Int = renderer.pageCount
    override val supportsZoom: Boolean = true
    private val lock = Any()

    @Volatile
    private var closed = false

    /** Renders a page fitted & centered into a w x h bitmap on a white background. */
    override fun renderPage(index: Int, w: Int, h: Int): Bitmap = renderRegionInternal(index, w, h, 1f, 0f, 0f)

    override fun renderRegion(index: Int, w: Int, h: Int, zoom: Float, tx: Float, ty: Float): Bitmap? =
        renderRegionInternal(index, w, h, zoom, tx, ty)

    /**
     * Screen = zoom * fitted + (tx, ty). With zoom=1, tx=ty=0 this is the normal fit-to-screen page.
     * Only the visible area is rasterised, so zoomed text stays sharp.
     */
    private fun renderRegionInternal(index: Int, w: Int, h: Int, zoom: Float, tx: Float, ty: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        synchronized(lock) {
            if (closed) return bmp
            val page = renderer.openPage(index)
            try {
                val s0 = min(w.toFloat() / page.width, h.toFloat() / page.height)
                val dx0 = (w - page.width * s0) / 2f
                val dy0 = (h - page.height * s0) / 2f
                val m = Matrix()
                m.setScale(s0 * zoom, s0 * zoom)
                m.postTranslate(dx0 * zoom + tx, dy0 * zoom + ty)
                page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            } finally {
                page.close()
            }
        }
        return bmp
    }

    override fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            try {
                renderer.close()
            } catch (_: Throwable) {
            }
            try {
                pfd.close()
            } catch (_: Throwable) {
            }
            try {
                tempFile?.delete()
            } catch (_: Throwable) {
            }
        }
    }

    class OpenResult(
        val doc: PdfDoc?,
        val error: String? = null,
        val needsPassword: Boolean = false,
        val wrongPassword: Boolean = false
    )

    companion object {
        fun open(path: String): OpenResult = openFile(path, null)

        /** Removes the encryption into a private temp copy (deleted on close) and opens that. */
        fun openWithPassword(ctx: Context, path: String, password: String): OpenResult {
            val dir = File(ctx.cacheDir, "decrypted").apply { mkdirs() }
            val out = File(dir, "d_${System.nanoTime()}.pdf")
            try {
                PDFBoxResourceLoader.init(ctx.applicationContext)
                val d = PDDocument.load(File(path), password)
                try {
                    d.setAllSecurityToBeRemoved(true)
                    d.save(out)
                } finally {
                    d.close()
                }
            } catch (e: InvalidPasswordException) {
                out.delete()
                return OpenResult(null, null, needsPassword = true, wrongPassword = true)
            } catch (e: Throwable) {
                out.delete()
                return OpenResult(null, "open")
            }
            return openFile(out.absolutePath, out)
        }

        fun clearTempCopies(ctx: Context) {
            try {
                File(ctx.cacheDir, "decrypted").deleteRecursively()
            } catch (_: Throwable) {
            }
        }

        private fun openFile(path: String, temp: File?): OpenResult {
            return try {
                val pfd = ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    val r = PdfRenderer(pfd)
                    if (r.pageCount <= 0) {
                        r.close()
                        pfd.close()
                        OpenResult(null, "empty")
                    } else {
                        OpenResult(PdfDoc(pfd, r, temp))
                    }
                } catch (e: Throwable) {
                    try {
                        pfd.close()
                    } catch (_: Throwable) {
                    }
                    throw e
                }
            } catch (e: SecurityException) {
                OpenResult(null, null, needsPassword = true)
            } catch (e: Throwable) {
                OpenResult(null, "open")
            }
        }
    }
}

/** Small in-memory cache of cover thumbnails for the file lists (PDF first page / EPUB cover). */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(64)
    private val gate = Semaphore(2)

    suspend fun load(path: String, modified: Long): Bitmap? {
        val key = "$path:$modified"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                cache.get(key) ?: render(path)?.also { cache.put(key, it) }
            }
        }
    }

    private fun render(path: String): Bitmap? {
        if (isEpubPath(path)) {
            return try {
                EpubParser.cover(path, 320)
            } catch (e: Throwable) {
                null
            }
        }
        val res = PdfDoc.open(path)
        val doc = res.doc ?: return null
        return try {
            doc.renderPage(0, 240, 320)
        } catch (e: Throwable) {
            null
        } finally {
            doc.close()
        }
    }
}
