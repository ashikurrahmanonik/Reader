@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.R
import com.reader.app.UpdateState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ReaderApp(vm: AppViewModel) {
    var splash by rememberSaveable { mutableStateOf(true) }
    val reader = vm.reader
    Box(Modifier.fillMaxSize()) {
        AppBackground()
        when {
            reader != null -> androidx.compose.runtime.key(reader.path) { ReaderScreen(vm, reader) }
            vm.showSettings -> SettingsScreen(vm)
            else -> HomeScreen(vm)
        }
        UpdateDialog(vm)
        if (splash) SplashOverlay { splash = false }
    }
}

@Composable
private fun SplashOverlay(onDone: () -> Unit) {
    var visible by remember { mutableStateOf(true) }
    val s = remember { Animatable(0.7f) }
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { s.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
        launch { a.animateTo(1f, tween(500)) }
        delay(1400)
        visible = false
        delay(450)
        onDone()
    }
    AnimatedVisibility(visible = visible, exit = fadeOut(tween(400))) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(RC.Navy950, RC.Navy900, Color(0xFF0A1B4D)))),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .scale(s.value)
                    .alpha(a.value)
            ) {
                Image(
                    painterResource(R.drawable.logo_full),
                    contentDescription = "Reader",
                    modifier = Modifier
                        .size(240.dp)
                        .clip(RoundedCornerShape(48.dp))
                        .background(Color.White)
                )
                Spacer(Modifier.height(18.dp))
                Text("Read beautifully", color = RC.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun UpdateDialog(vm: AppViewModel) {
    if (!vm.showUpdateDialog) return
    val u = vm.update
    val shape = RoundedCornerShape(28.dp)
    when (u) {
        is UpdateState.Available -> AlertDialog(
            onDismissRequest = { vm.dismissUpdateDialog() },
            containerColor = RC.Navy800,
            shape = shape,
            title = { Text("Update available", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Reader ${u.info.name} is ready. Your books and progress stay as they are.", color = RC.Muted)
                    if (u.info.notes.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(u.info.notes.take(300), color = RC.Muted, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.downloadUpdate(u.info) }) {
                    Text("Update now", color = RC.BlueLight, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { vm.dismissUpdateDialog() }) { Text("Later", color = RC.Muted) }
            }
        )
        is UpdateState.Downloading -> AlertDialog(
            onDismissRequest = { },
            containerColor = RC.Navy800,
            shape = shape,
            title = { Text("Downloading update", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    LinearProgressIndicator(
                        progress = { u.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = RC.BlueLight,
                        trackColor = Color.White.copy(alpha = 0.15f)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("${(u.progress * 100).toInt()}%", color = RC.Muted)
                }
            },
            confirmButton = {}
        )
        is UpdateState.Ready -> AlertDialog(
            onDismissRequest = { vm.dismissUpdateDialog() },
            containerColor = RC.Navy800,
            shape = shape,
            title = { Text("Ready to install", fontWeight = FontWeight.Bold) },
            text = { Text("Tap Install to update Reader in place.", color = RC.Muted) },
            confirmButton = {
                TextButton(onClick = { vm.installUpdate() }) {
                    Text("Install", color = RC.BlueLight, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { vm.dismissUpdateDialog() }) { Text("Close", color = RC.Muted) }
            }
        )
        is UpdateState.Failed -> AlertDialog(
            onDismissRequest = { vm.dismissUpdateDialog() },
            containerColor = RC.Navy800,
            shape = shape,
            title = { Text("Update failed", fontWeight = FontWeight.Bold) },
            text = { Text(u.message, color = RC.Muted) },
            confirmButton = {
                TextButton(onClick = { vm.dismissUpdateDialog() }) { Text("OK", color = RC.BlueLight) }
            }
        )
        else -> {}
    }
}
