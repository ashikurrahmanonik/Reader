@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.reader.app.ui

import android.content.Intent
import android.text.format.DateFormat
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.reader.app.AppViewModel
import com.reader.app.data.BOOK_EXT_REGEX
import com.reader.app.data.FmEntry
import com.reader.app.data.Kind
import com.reader.app.data.kindOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Date

// ------------------------------------------------------------------ helpers

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
private val AUDIO_EXT = setOf("mp3", "m4a", "wav", "ogg", "aac", "flac", "opus")
private val VIDEO_EXT = setOf("mp4", "mkv", "3gp", "webm", "avi", "mov")
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz")

private fun isBook(name: String) = BOOK_EXT_REGEX.containsMatchIn(name)

private fun iconFor(e: FmEntry): Pair<ImageVector, Color> {
    if (e.isDir) return Pair(Icons.Rounded.Folder, RC.OrangeLight)
    val ext = e.name.substringAfterLast('.', "").lowercase()
    return when {
        isBook(e.name) -> when (kindOf(e.name)) {
            Kind.PDF -> Pair(Icons.Rounded.PictureAsPdf, RC.Danger)
            Kind.EPUB -> Pair(Icons.Rounded.Book, RC.Blue)
            Kind.DOCX, Kind.TXT -> Pair(Icons.Rounded.Description, Color(0xFF2B6CD6))
            Kind.XLSX, Kind.CSV -> Pair(Icons.Rounded.TableChart, Color(0xFF1E9E5A))
            Kind.PPTX -> Pair(Icons.Rounded.Slideshow, Color(0xFFE2662A))
        }
        ext in IMAGE_EXT -> Pair(Icons.Rounded.Image, Color(0xFFB07CFF))
        ext in AUDIO_EXT -> Pair(Icons.Rounded.MusicNote, Color(0xFF3DD6C6))
        ext in VIDEO_EXT -> Pair(Icons.Rounded.Movie, Color(0xFFFF6FA8))
        ext in ARCHIVE_EXT -> Pair(Icons.Rounded.FolderZip, RC.OrangeLight)
        else -> Pair(Icons.Rounded.InsertDriveFile, RC.Muted)
    }
}

/** Opens a file that Reader itself can't show with whatever app on the phone can. */
fun openExternally(ctx: android.content.Context, path: String, noApp: String = "") {
    try {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Throwable) {
        if (noApp.isNotEmpty()) Toast.makeText(ctx, noApp, Toast.LENGTH_SHORT).show()
    }
}

private fun prettyPath(vm: AppViewModel, path: String, root: String): String {
    val rel = path.removePrefix(vm.fmRoot).trim('/')
    return if (rel.isEmpty()) root else "$root / ${rel.replace("/", " / ")}"
}

// ------------------------------------------------------------------ screen

@Composable
fun FileManagerScreen(vm: AppViewModel, query: String, onGrant: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalStr.current

    if (!vm.hasAccess) {
        Column(Modifier.padding(horizontal = 20.dp)) { PermissionCard(onGrant) }
        return
    }

    val path = vm.fmPath
    val list by produceState<List<FmEntry>?>(null, path, vm.fmHidden, vm.fmSort, vm.fmTick) {
        value = vm.fmList(path, vm.fmHidden, vm.fmSort)
    }
    val all = list
    val shown = remember(all, query) {
        val q = query.trim()
        if (all == null) emptyList() else if (q.isEmpty()) all else all.filter { it.name.contains(q, ignoreCase = true) }
    }
    val selected = vm.fmSelected
    val clip = vm.fmClip

    var menuFor by remember { mutableStateOf<String?>(null) }
    var askNewFolder by remember { mutableStateOf(false) }
    var askDeleteSel by remember { mutableStateOf(false) }
    var detailsFor by remember { mutableStateOf<String?>(null) }
    var renameFor by remember { mutableStateOf<String?>(null) }

    FileActionHost(
        vm, menuFor, fm = true,
        onOpen = { menuFor?.let { p -> openEntry(vm, ctx, p, t.noAppToOpen) } },
        onClose = { menuFor = null }
    )
    if (renameFor != null) RenameDialog(vm, renameFor!!) { renameFor = null }
    if (detailsFor != null) DetailsDialog(detailsFor!!) { detailsFor = null }
    if (askNewFolder) NewFolderDialog(vm) { askNewFolder = false }
    if (askDeleteSel) {
        ConfirmDialog(
            text = t.deleteAsk(selected.size),
            confirm = t.delete,
            onConfirm = { vm.delete(selected.toList()) },
            onClose = { askDeleteSel = false }
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ---- path bar ----
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (vm.fmCanGoUp) {
                    MiniIcon(Icons.Rounded.ArrowUpward, t.up, Color.White) { vm.fmUp() }
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    prettyPath(vm, path, t.internalStorage),
                    modifier = Modifier.weight(1f),
                    color = RC.Muted,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                MiniIcon(Icons.Rounded.Sort, t.size, RC.Muted) { vm.fmSort = (vm.fmSort + 1) % 3 }
                MiniIcon(
                    if (vm.fmHidden) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                    t.showHidden, if (vm.fmHidden) RC.OrangeLight else RC.Muted
                ) { vm.fmHidden = !vm.fmHidden }
                MiniIcon(Icons.Rounded.CreateNewFolder, t.newFolder, RC.Muted) { askNewFolder = true }
            }
            Text(
                listOf(t.name, t.newest, t.size)[vm.fmSort] + "  •  " + t.items(shown.size),
                color = RC.Muted, fontSize = 11.sp,
                modifier = Modifier.padding(start = 22.dp, bottom = 6.dp)
            )

            // ---- paste banner ----
            if (clip != null) {
                Row(
                    Modifier
                        .padding(horizontal = 20.dp, vertical = 4.dp)
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(18.dp), 0.14f)
                        .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        t.pasteInfo(clip.paths.size, clip.move),
                        modifier = Modifier.weight(1f), fontSize = 13.sp
                    )
                    TextButton(onClick = { vm.fmPaste() }) {
                        Text(t.paste, color = RC.OrangeLight, fontWeight = FontWeight.Bold)
                    }
                    MiniIcon(Icons.Rounded.Close, t.cancel, RC.Muted) { vm.fmClearClip() }
                }
            }

            // ---- list ----
            LazyColumn(
                state = vm.listState("fm:$path"),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 210.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (all != null && shown.isEmpty()) {
                    item {
                        Text(
                            if (query.isNotBlank()) t.emptySearch else t.emptyFolder,
                            color = RC.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp)
                        )
                    }
                }
                items(shown, key = { it.path }) { e ->
                    EntryRow(
                        e = e,
                        selected = e.path in selected,
                        selecting = selected.isNotEmpty(),
                        onClick = {
                            if (selected.isNotEmpty()) vm.fmToggleSelect(e.path) else openEntry(vm, ctx, e.path, t.noAppToOpen)
                        },
                        onLong = { vm.fmToggleSelect(e.path) },
                        onMenu = { menuFor = e.path }
                    )
                }
            }
        }

        // ---- selection action bar (sits above the navigation bar) ----
        if (selected.isNotEmpty()) {
            val single = if (selected.size == 1) selected.first() else null
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(start = 20.dp, end = 20.dp, bottom = 100.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(26.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.92f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MiniIcon(Icons.Rounded.Close, t.cancel, Color.White) { vm.fmSelected = emptySet() }
                Text(
                    t.selected(selected.size),
                    modifier = Modifier.weight(1f),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1
                )
                MiniIcon(Icons.Rounded.SelectAll, t.selectAll, Color.White) {
                    vm.fmSelected = shown.map { it.path }.toSet()
                }
                MiniIcon(Icons.Rounded.ContentCopy, t.copy, Color.White) { vm.fmCopyOrCut(selected.toList(), false) }
                MiniIcon(Icons.Rounded.ContentCut, t.move, Color.White) { vm.fmCopyOrCut(selected.toList(), true) }
                if (single != null) {
                    MiniIcon(Icons.Rounded.Edit, t.rename, Color.White) { renameFor = single }
                    MiniIcon(Icons.Rounded.Info, t.details, Color.White) { detailsFor = single }
                }
                MiniIcon(Icons.Rounded.Delete, t.delete, RC.Danger) { askDeleteSel = true }
            }
        }
    }
}

private fun openEntry(vm: AppViewModel, ctx: android.content.Context, path: String, noApp: String) {
    val f = File(path)
    when {
        f.isDirectory -> vm.fmOpen(path)
        isBook(f.name) -> vm.openPath(path)
        else -> openExternally(ctx, path, noApp)
    }
}

@Composable
private fun EntryRow(
    e: FmEntry,
    selected: Boolean,
    selecting: Boolean,
    onClick: () -> Unit,
    onLong: () -> Unit,
    onMenu: () -> Unit
) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val (icon, tint) = iconFor(e)
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(18.dp), if (selected) 0.30f else 0.08f)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(tint.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Icon(Icons.Rounded.Check, null, tint = RC.BlueLight, modifier = Modifier.size(24.dp))
            else Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            val date = DateFormat.getMediumDateFormat(ctx).format(Date(e.modified))
            Text(
                (if (e.isDir) t.items(e.children) else Formatter.formatShortFileSize(ctx, e.size)) + "  •  " + date,
                color = RC.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (!selecting) MiniIcon(Icons.Rounded.MoreVert, t.actions, RC.Muted, onMenu)
    }
}

// ------------------------------------------------------------------ dialogs (shared with the Library)

@Composable
private fun dialogShape() = RoundedCornerShape(28.dp)

@Composable
private fun DlgTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
}

/** Long-press / ⋮ menu of one file or folder, with rename, delete and details behind it. */
@Composable
fun FileActionHost(vm: AppViewModel, path: String?, fm: Boolean, onOpen: () -> Unit, onClose: () -> Unit) {
    if (path == null) return
    val ctx = LocalContext.current
    val t = LocalStr.current
    var mode by remember(path) { mutableStateOf(0) } // 0 menu, 1 rename, 2 delete, 3 details
    val f = File(path)
    if (!f.exists()) {
        LaunchedEffect(path) { onClose() }
        return
    }
    when (mode) {
        1 -> RenameDialog(vm, path) { onClose() }
        2 -> ConfirmDialog(
            text = t.deleteOne(f.name),
            confirm = t.delete,
            onConfirm = { vm.delete(listOf(path)) },
            onClose = onClose
        )
        3 -> DetailsDialog(path) { onClose() }
        else -> AlertDialog(
            onDismissRequest = onClose,
            containerColor = RC.Navy800,
            shape = dialogShape(),
            title = { DlgTitle(f.name) },
            text = {
                Column {
                    ActionRow(Icons.Rounded.OpenInNew, if (f.isDirectory || isBook(f.name)) t.openAction else t.openWith) {
                        // open first: onOpen reads the same "menuFor" state that onClose clears
                        if (f.isDirectory || isBook(f.name)) onOpen() else openExternally(ctx, path, t.noAppToOpen)
                        onClose()
                    }
                    ActionRow(Icons.Rounded.Edit, t.rename) { mode = 1 }
                    if (fm) {
                        ActionRow(Icons.Rounded.ContentCopy, t.copy) {
                            vm.fmCopyOrCut(listOf(path), false); onClose()
                        }
                        ActionRow(Icons.Rounded.ContentCut, t.move) {
                            vm.fmCopyOrCut(listOf(path), true); onClose()
                        }
                    }
                    if (f.isFile) ActionRow(Icons.Rounded.Share, t.share) {
                        shareBook(ctx, path); onClose()
                    }
                    ActionRow(Icons.Rounded.Info, t.details) { mode = 3 }
                    ActionRow(Icons.Rounded.Delete, t.delete, RC.Danger) { mode = 2 }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onClose) { Text(t.close, color = RC.Muted) } }
        )
    }
}

@Composable
private fun ActionRow(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, color = tint, fontSize = 15.sp)
    }
}

@Composable
private fun ConfirmDialog(text: String, confirm: String, onConfirm: () -> Unit, onClose: () -> Unit) {
    val t = LocalStr.current
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = RC.Navy800,
        shape = dialogShape(),
        title = { DlgTitle(confirm) },
        text = { Text(text, color = RC.Muted) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onClose() }) {
                Text(confirm, color = RC.Danger, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(t.cancel, color = RC.Muted) } }
    )
}

@Composable
private fun RenameDialog(vm: AppViewModel, path: String, onClose: () -> Unit) {
    val t = LocalStr.current
    val f = File(path)
    // for files only the part before the extension is edited, the extension is kept as it is
    val ext = if (f.isDirectory || f.extension.isEmpty()) "" else "." + f.extension
    var text by remember(path) { mutableStateOf(if (ext.isEmpty()) f.name else f.nameWithoutExtension) }
    var err by remember(path) { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = RC.Navy800,
        shape = dialogShape(),
        title = { DlgTitle(t.rename) },
        text = {
            val shownErr = err
            OutlinedTextField(
                value = text,
                onValueChange = { text = it; err = null },
                singleLine = true,
                label = { Text(t.newName) },
                suffix = if (ext.isNotEmpty()) ({ Text(ext, color = RC.Muted) }) else null,
                isError = shownErr != null,
                supportingText = if (shownErr != null) ({ Text(shownErr, color = RC.Danger) }) else null
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val e = vm.rename(path, text.trim() + ext)
                if (e == null) onClose() else err = e
            }) { Text(t.rename, color = RC.BlueLight, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(t.cancel, color = RC.Muted) } }
    )
}

@Composable
private fun NewFolderDialog(vm: AppViewModel, onClose: () -> Unit) {
    val t = LocalStr.current
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = RC.Navy800,
        shape = dialogShape(),
        title = { DlgTitle(t.newFolder) },
        text = {
            val shownErr = err
            OutlinedTextField(
                value = text,
                onValueChange = { text = it; err = null },
                singleLine = true,
                label = { Text(t.folderName) },
                isError = shownErr != null,
                supportingText = if (shownErr != null) ({ Text(shownErr, color = RC.Danger) }) else null
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val e = vm.newFolder(text)
                if (e == null) onClose() else err = e
            }) { Text(t.create, color = RC.BlueLight, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(t.cancel, color = RC.Muted) } }
    )
}

@Composable
private fun DetailsDialog(path: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val f = File(path)
    // folders: add up everything inside, off the main thread
    val size by produceState<Long?>(if (f.isFile) f.length() else null, path) {
        if (f.isDirectory) {
            value = withContext(Dispatchers.IO) { f.walkTopDown().filter { it.isFile }.sumOf { it.length() } }
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = RC.Navy800,
        shape = dialogShape(),
        title = { DlgTitle(t.details) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailLine(t.dName, f.name)
                DetailLine(t.dPath, f.parent ?: "/")
                DetailLine(
                    t.dType,
                    if (f.isDirectory) t.dFolder else f.extension.uppercase().ifEmpty { "–" }
                )
                DetailLine(t.dSize, size?.let { Formatter.formatFileSize(ctx, it) } ?: t.dCalculating)
                DetailLine(
                    t.dModified,
                    DateFormat.getMediumDateFormat(ctx).format(Date(f.lastModified())) + "  " +
                        DateFormat.getTimeFormat(ctx).format(Date(f.lastModified()))
                )
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text(t.ok, color = RC.BlueLight) } }
    )
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column {
        Text(label, color = RC.OrangeLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(value, fontSize = 14.sp)
    }
}
