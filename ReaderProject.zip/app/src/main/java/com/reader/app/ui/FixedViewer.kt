@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.graphics.Paint
import android.graphics.RectF
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.data.BOOK_EXT_REGEX
import com.reader.app.data.ReaderTarget
import com.reader.app.office.FixedDoc
import kotlinx.coroutines.Job
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

@Stable
private class PageViewState : PanZoomTarget {
    override var z by mutableFloatStateOf(1f)
    override var ux by mutableFloatStateOf(0f)
    override var uy by mutableFloatStateOf(0f)
    override var fling: Job? = null
    var w = 0f
    var h = 0f
    var contentW = 0f
    var contentH = 0f

    override fun clamp() {
        ux = ux.coerceIn(0f, max(0f, contentW - w / z))
        uy = uy.coerceIn(0f, max(0f, contentH - h / z))
    }
}

/** Word pages / PowerPoint slides: vector pages, vertical scroll, pinch zoom, always sharp. */
@Composable
fun FixedViewer(vm: AppViewModel, target: ReaderTarget, doc: FixedDoc, isSlides: Boolean) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val density = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    val theme = vm.readerTheme
    val st = remember(doc) { PageViewState() }
    var showUi by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) }
    var missingDismissed by remember(doc) { mutableStateOf(false) }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importFonts(uris)
    }
    val gap = 14f * density
    val unit = doc.pageH + gap
    val n = doc.pageCount
    val fav = target.path in vm.favorites

    st.contentW = doc.pageW
    st.contentH = gap + n * unit

    val bg = when (theme) {
        1 -> 0xFFCDBF99.toInt()
        2 -> 0xFF0B0D12.toInt()
        else -> 0xFFD9DDE3.toInt()
    }
    val layerPaint = remember(theme) { if (theme == 0) null else themedBitmapPaint(theme) }
    val pageFill = remember { Paint().apply { color = 0xFFFFFFFF.toInt() } }
    val shadow = remember { Paint().apply { color = 0x33000000 } }
    val rect = remember { RectF() }

    BackHandler(enabled = panel != 0) { panel = 0 }

    fun pageTop(i: Int) = gap + i * unit

    var initialised by remember(doc) { mutableStateOf(false) }
    val page by remember(doc) {
        derivedStateOf {
            val centre = st.uy + (st.h / st.z) / 2f
            floor((centre - gap / 2f) / unit).toInt().coerceIn(0, n - 1)
        }
    }

    LaunchedEffect(page) {
        if (initialised) vm.recordProgress(target.path, target.name, page, n, -1L)
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged {
                st.w = it.width.toFloat()
                st.h = it.height.toFloat()
                if (!initialised) {
                    initialised = true
                    st.uy = max(0f, pageTop(target.startPage.coerceIn(0, n - 1)) - gap)
                }
                st.clamp()
            }
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .panZoom(doc, st, scope, 0.6f, 5f)
                .tapZoom(doc, st) {
                    showUi = !showUi
                    if (!showUi) panel = 0
                }
        ) {
            drawIntoCanvas { cv ->
                val c = cv.nativeCanvas
                val W = size.width
                val H = size.height
                c.drawColor(bg)
                c.save()
                c.scale(st.z, st.z)
                c.translate(-st.ux, -st.uy)
                val vh = H / st.z
                val first = max(0, floor((st.uy - gap) / unit).toInt())
                val last = min(n - 1, ceil((st.uy + vh) / unit).toInt())
                val xOff = max(0f, (W / st.z - doc.pageW) / 2f)
                for (i in first..last) {
                    val top = pageTop(i)
                    c.save()
                    c.translate(xOff, top)
                    rect.set(0f, 0f, doc.pageW, doc.pageH)
                    c.drawRect(3f, 3f, doc.pageW + 3f, doc.pageH + 3f, shadow)
                    if (layerPaint != null) {
                        val sc = c.saveLayer(0f, 0f, doc.pageW, doc.pageH, layerPaint)
                        c.drawRect(rect, pageFill)
                        c.clipRect(rect)
                        doc.drawPage(c, i)
                        c.restoreToCount(sc)
                    } else {
                        c.drawRect(rect, pageFill)
                        c.save()
                        c.clipRect(rect)
                        doc.drawPage(c, i)
                        c.restore()
                    }
                    c.restore()
                }
                c.restore()
            }
        }

        // page chip
        Text(
            "${t.n(page + 1)} / ${t.n(n)}",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                .padding(bottom = 10.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x99000000))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )

        // missing legacy fonts banner
        val missingNames = doc.missingFonts
        if (missingNames.isNotEmpty() && !missingDismissed) {
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(start = 12.dp, end = 12.dp, top = if (showUi) 76.dp else 12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(20.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.92f))
                    .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    t.missingFonts(missingNames.joinToString(", ")),
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                TextButton(onClick = { fontPicker.launch(arrayOf("*/*")) }) {
                    Text(t.goFonts, color = RC.OrangeLight, fontWeight = FontWeight.Bold)
                }
                MiniIcon(Icons.Rounded.Close, t.dismiss, RC.Muted) { missingDismissed = true }
            }
        }

        // top bar
        AnimatedVisibility(
            visible = showUi,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            Row(
                Modifier
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(26.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.86f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MiniIcon(Icons.AutoMirrored.Rounded.ArrowBack, t.back, Color.White) { vm.closeReader() }
                Spacer(Modifier.width(6.dp))
                Text(
                    target.name.replace(BOOK_EXT_REGEX, ""),
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                MiniIcon(Icons.Rounded.Palette, t.theme, RC.OrangeLight) { vm.cycleReaderTheme() }
                MiniIcon(
                    if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    t.favorite,
                    if (fav) RC.OrangeLight else Color.White
                ) { vm.toggleFavorite(target.path) }
                MiniIcon(Icons.Rounded.Share, t.share, Color.White) { shareBook(ctx, target.path) }
            }
        }

        // bottom: outline + slider
        AnimatedVisibility(
            visible = showUi,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it }
        ) {
            var slider by remember { mutableFloatStateOf(page.toFloat()) }
            var sliding by remember { mutableStateOf(false) }
            LaunchedEffect(page) { if (!sliding) slider = page.toFloat() }
            val shown = if (sliding) slider.toInt() else page
            Column(
                Modifier
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(12.dp)
            ) {
                if (panel == 1 && doc.outline.isNotEmpty()) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 320.dp)
                            .glass(RoundedCornerShape(26.dp), 0.18f)
                            .background(RC.Navy900.copy(alpha = 0.92f))
                            .padding(vertical = 8.dp)
                    ) {
                        LazyColumn {
                            itemsIndexed(doc.outline) { _, e ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            st.uy = max(0f, pageTop(e.second) - gap)
                                            st.clamp()
                                            panel = 0
                                        }
                                        .padding(horizontal = 18.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        e.first,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                    Text(t.n(e.second + 1), color = RC.Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.padding(4.dp))
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(26.dp), 0.18f)
                        .background(RC.Navy900.copy(alpha = 0.86f))
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            t.pageOf(shown + 1, n),
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                        if (doc.outline.isNotEmpty()) {
                            MiniIcon(
                                Icons.Rounded.FormatListBulleted, t.contents,
                                if (panel == 1) RC.OrangeLight else Color.White
                            ) { panel = if (panel == 1) 0 else 1 }
                        }
                    }
                    if (n > 1) {
                        Slider(
                            value = slider,
                            onValueChange = {
                                sliding = true
                                slider = it
                            },
                            onValueChangeFinished = {
                                st.uy = max(0f, pageTop(slider.toInt().coerceIn(0, n - 1)) - gap)
                                st.clamp()
                                sliding = false
                            },
                            valueRange = 0f..(n - 1).toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = RC.OrangeLight,
                                activeTrackColor = RC.BlueLight,
                                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                            )
                        )
                    }
                }
            }
        }
    }
}

private fun Modifier.tapZoom(key: Any?, st: PageViewState, onTap: () -> Unit): Modifier =
    this.pointerInput(key) {
        detectTapGestures(
            onTap = { onTap() },
            onDoubleTap = { off ->
                // double tap toggles between fit-to-width and 2.3x about the tapped point
                val oldZ = st.z
                val newZ = if (oldZ > 1.2f) 1f else 2.3f
                val px = st.ux + off.x / oldZ
                val py = st.uy + off.y / oldZ
                st.z = newZ
                st.ux = px - off.x / newZ
                st.uy = py - off.y / newZ
                st.clamp()
            }
        )
    }
