package com.reader.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.R
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot

/** Frosted-glass surface: translucent gradient fill + light edge border. */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    strength: Float = 0.10f
): Modifier = this
    .clip(shape)
    .background(
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = strength + 0.05f),
                Color.White.copy(alpha = strength * 0.4f)
            )
        ),
        shape
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.38f),
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.14f)
            )
        ),
        shape
    )

@Composable
fun AppBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "blob"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(RC.Navy950, RC.Navy900, Color(0xFF0A1B4D)))
            )
            .drawBehind {
                val w = size.width
                val h = size.height
                val c1 = Offset(w * (0.12f + 0.3f * a), h * 0.10f)
                drawCircle(
                    Brush.radialGradient(listOf(RC.Blue.copy(alpha = 0.40f), Color.Transparent), center = c1, radius = w * 0.85f),
                    radius = w * 0.85f,
                    center = c1
                )
                val c2 = Offset(w * (0.95f - 0.3f * a), h * 0.78f)
                drawCircle(
                    Brush.radialGradient(listOf(RC.Orange.copy(alpha = 0.15f), Color.Transparent), center = c2, radius = w * 0.75f),
                    radius = w * 0.75f,
                    center = c2
                )
            }
    )
}

@Composable
fun LogoBadge(size: Dp) {
    Image(
        painter = painterResource(R.drawable.logo_mark),
        contentDescription = "Reader",
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(Color.White)
            .padding(size * 0.06f)
    )
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    Box(
        modifier
            .size(42.dp)
            .glass(CircleShape, 0.12f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun MiniIcon(icon: ImageVector, desc: String, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun GradientButton(
    text: String,
    icon: ImageVector?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(RC.Blue, RC.BlueLight)))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) RC.Blue else Color.White.copy(alpha = 0.10f))
            .border(1.dp, if (selected) RC.BlueLight else Color.White.copy(alpha = 0.16f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) Color.White else RC.Muted
        )
    }
}


/**
 * Real "frosted glass": the screen content is captured into a layer; bars drawn above it show a
 * blurred copy of whatever is scrolling underneath. (Blur needs Android 12+, older phones get a
 * more solid tint instead.)
 */
class Backdrop(val sharp: GraphicsLayer, val blurred: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

val blurSupported: Boolean get() = Build.VERSION.SDK_INT >= 31

@Composable
fun rememberBackdrop(): Backdrop {
    val sharp = rememberGraphicsLayer()
    val blurred = rememberGraphicsLayer()
    return remember(sharp, blurred) {
        if (blurSupported) blurred.renderEffect = BlurEffect(38f, 38f, TileMode.Clamp)
        Backdrop(sharp, blurred)
    }
}

fun Modifier.recordBackdrop(b: Backdrop): Modifier = this
    .onGloballyPositioned { b.origin = it.positionInRoot() }
    .drawWithContent {
        b.sharp.record {
            this@drawWithContent.drawContent()
        }
        if (blurSupported) {
            b.blurred.record {
                drawLayer(b.sharp)
            }
        }
        drawLayer(b.sharp)
    }

@Composable
fun Modifier.backdropGlass(
    b: Backdrop,
    shape: Shape,
    tint: Color = RC.Navy900.copy(alpha = if (blurSupported) 0.38f else 0.90f)
): Modifier {
    var pos by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            if (blurSupported) {
                translate(b.origin.x - pos.x, b.origin.y - pos.y) {
                    drawLayer(b.blurred)
                }
            }
            drawRect(tint)
        }
        .background(
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.04f))
            ),
            shape
        )
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.45f),
                    Color.White.copy(alpha = 0.05f),
                    Color.White.copy(alpha = 0.18f)
                )
            ),
            shape
        )
}
