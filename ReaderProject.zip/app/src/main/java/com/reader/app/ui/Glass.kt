package com.reader.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.R

/** Frosted-glass surface: translucent gradient fill + light edge border. */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    strength: Float = 0.10f
): Modifier = this
    .clip(shape)
    .background(
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = strength + 0.05f),
                Color.White.copy(alpha = strength * 0.4f)
            )
        ),
        shape
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.38f),
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.14f)
            )
        ),
        shape
    )

@Composable
fun AppBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "blob"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(RC.Navy950, RC.Navy900, Color(0xFF0A1B4D)))
            )
            .drawBehind {
                val w = size.width
                val h = size.height
                val c1 = Offset(w * (0.12f + 0.3f * a), h * 0.10f)
                drawCircle(
                    Brush.radialGradient(listOf(RC.Blue.copy(alpha = 0.40f), Color.Transparent), center = c1, radius = w * 0.85f),
                    radius = w * 0.85f,
                    center = c1
                )
                val c2 = Offset(w * (0.95f - 0.3f * a), h * 0.78f)
                drawCircle(
                    Brush.radialGradient(listOf(RC.Orange.copy(alpha = 0.15f), Color.Transparent), center = c2, radius = w * 0.75f),
                    radius = w * 0.75f,
                    center = c2
                )
            }
    )
}

@Composable
fun LogoBadge(size: Dp) {
    Image(
        painter = painterResource(R.drawable.logo_mark),
        contentDescription = "Reader",
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(Color.White)
            .padding(size * 0.06f)
    )
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.White
) {
    Box(
        modifier
            .size(42.dp)
            .glass(CircleShape, 0.12f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun MiniIcon(icon: ImageVector, desc: String, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun GradientButton(
    text: String,
    icon: ImageVector?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(RC.Blue, RC.BlueLight)))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}
