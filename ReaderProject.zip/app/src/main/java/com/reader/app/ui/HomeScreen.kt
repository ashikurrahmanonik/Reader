@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.format.DateFormat
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.reader.app.AppViewModel
import com.reader.app.data.BookRow
import com.reader.app.pdf.Thumbs
import java.util.Date

private fun cleanName(n: String) = n.replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), "")

private fun requestAllFilesAccess(ctx: android.content.Context) {
    if (Build.VERSION.SDK_INT >= 30) {
        try {
            ctx.startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Throwable) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var sort by rememberSaveable { mutableIntStateOf(0) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openUri(uri)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.onResume()
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) vm.onResume()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    BackHandler(enabled = searching) {
        searching = false
        query = ""
    }

    val rows = remember(tab, vm.files, vm.history, vm.favorites, query, sort) {
        vm.rowsFor(tab, query, sort)
    }
    val last = remember(vm.history) { vm.history.firstOrNull { java.io.File(it.path).exists() } }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 130.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    LogoBadge(44.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Reader",
                        modifier = Modifier.weight(1f),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                    GlassIconButton(Icons.Rounded.Search, "Search", { searching = !searching; if (!searching) query = "" })
                    Spacer(Modifier.width(10.dp))
                    GlassIconButton(Icons.Rounded.Settings, "Settings", { vm.showSettings = true })
                }
            }

            if (searching) {
                item { SearchField(query) { query = it } }
            }

            if (!searching && last != null) {
                item {
                    HeroCard(
                        path = last.path,
                        name = last.name,
                        page = last.lastPage,
                        pages = last.pageCount,
                        onOpen = { vm.openPath(last.path) }
                    )
                }
            }

            item { Tabs(tab) { tab = it } }

            if (tab == 0 && vm.hasAccess) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        val labels = listOf("Newest", "Name", "Size")
                        labels.forEachIndexed { i, l ->
                            val sel = sort == i
                            Box(
                                Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (sel) Color.White.copy(alpha = 0.18f) else Color.Transparent)
                                    .clickable { sort = i }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    l, fontSize = 13.sp,
                                    color = if (sel) Color.White else RC.Muted,
                                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        Text("${rows.size} files", color = RC.Muted, fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        if (vm.scanning) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = RC.BlueLight)
                        } else {
                            MiniIcon(Icons.Rounded.Refresh, "Rescan", RC.Muted) { vm.scan() }
                        }
                    }
                }
            }

            when {
                tab == 0 && !vm.hasAccess -> item {
                    PermissionCard {
                        if (Build.VERSION.SDK_INT >= 30) requestAllFilesAccess(ctx)
                        else permLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                }
                rows.isEmpty() -> item {
                    EmptyState(
                        when {
                            vm.scanning && tab == 0 -> "Looking for PDFs on your phone…"
                            query.isNotBlank() -> "No PDFs match your search"
                            tab == 1 -> "Books you read will show up here"
                            tab == 2 -> "Tap the star on a book to keep it here"
                            else -> "No PDFs found yet"
                        }
                    )
                }
                else -> items(rows, key = { it.path }) { row ->
                    BookCard(
                        row = row,
                        showRemove = tab == 1,
                        onOpen = { vm.openPath(row.path) },
                        onFav = { vm.toggleFavorite(row.path) },
                        onShare = { sharePdf(ctx, row.path) },
                        onRemove = { vm.removeFromHistory(row.path) }
                    )
                }
            }
        }

        GradientButton(
            text = "Open PDF",
            icon = Icons.Rounded.FolderOpen,
            onClick = { picker.launch(arrayOf("application/pdf")) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(20.dp)
        )
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(18.dp), 0.10f)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = RC.Muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) Text("Search your PDFs", color = RC.Muted, fontSize = 16.sp)
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(RC.BlueLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(fr)
            )
        }
        if (query.isNotEmpty()) {
            Icon(
                Icons.Rounded.Close, "Clear", tint = RC.Muted,
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onChange("") }
            )
        }
    }
}

@Composable
private fun Tabs(selected: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("Library", "Recent", "Favorites")
    val icons = listOf(Icons.Rounded.AutoStories, Icons.Rounded.History, Icons.Rounded.Star)
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(20.dp), 0.08f)
            .padding(4.dp)
    ) {
        labels.forEachIndexed { i, l ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) RC.Blue else Color.Transparent, label = "tab")
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icons[i], null, Modifier.size(18.dp), tint = if (sel) Color.White else RC.Muted)
                Spacer(Modifier.width(6.dp))
                Text(
                    l, fontSize = 13.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                    color = if (sel) Color.White else RC.Muted
                )
            }
        }
    }
}

@Composable
fun PdfThumb(path: String, modified: Long, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, path, modified) {
        value = Thumbs.load(path, modified)
    }
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
    ) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), null,
                Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter
            )
        } else {
            Icon(
                Icons.Rounded.PictureAsPdf, null,
                tint = RC.Danger,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(26.dp)
            )
        }
    }
}

@Composable
private fun HeroCard(path: String, name: String, page: Int, pages: Int, onOpen: () -> Unit) {
    val modified = remember(path) { java.io.File(path).lastModified() }
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(26.dp), 0.14f)
            .background(
                androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(RC.Blue.copy(alpha = 0.30f), Color.Transparent)
                )
            )
            .clickable(onClick = onOpen)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PdfThumb(path, modified, Modifier.size(width = 84.dp, height = 112.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "CONTINUE READING", color = RC.OrangeLight, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                cleanName(name), fontSize = 17.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (pages > 0) {
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { ((page + 1).toFloat() / pages).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(CircleShape),
                    color = RC.OrangeLight,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )
                Spacer(Modifier.height(6.dp))
                Text("Page ${page + 1} of $pages", color = RC.Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            GradientButton("Resume", Icons.Rounded.PlayArrow, onOpen)
        }
    }
}

@Composable
private fun BookCard(
    row: BookRow,
    showRemove: Boolean,
    onOpen: () -> Unit,
    onFav: () -> Unit,
    onShare: () -> Unit,
    onRemove: () -> Unit
) {
    val ctx = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .glass()
            .clickable(onClick = onOpen)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PdfThumb(row.path, row.modified, Modifier.size(width = 60.dp, height = 80.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                cleanName(row.name), fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                Formatter.formatShortFileSize(ctx, row.size) + "  •  " +
                    DateFormat.getMediumDateFormat(ctx).format(Date(row.modified)),
                color = RC.Muted, fontSize = 12.sp
            )
            if (row.pages > 0) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { ((row.page + 1).toFloat() / row.pages).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape),
                    color = RC.BlueLight,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )
                Spacer(Modifier.height(4.dp))
                Text("Page ${row.page + 1} of ${row.pages}", color = RC.Muted, fontSize = 11.sp)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            MiniIcon(
                if (row.fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                "Favorite",
                if (row.fav) RC.OrangeLight else RC.Muted,
                onFav
            )
            if (showRemove) MiniIcon(Icons.Rounded.Close, "Remove from history", RC.Muted, onRemove)
            else MiniIcon(Icons.Rounded.Share, "Share", RC.Muted, onShare)
        }
    }
}

@Composable
private fun PermissionCard(onGrant: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(26.dp), 0.10f)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.FolderOpen, null, tint = RC.OrangeLight, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp))
        Text("Find every PDF on your phone", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Allow file access once and Reader will list all your PDFs automatically. " +
                "You can also use “Open PDF” to pick a single file.",
            color = RC.Muted, fontSize = 14.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        GradientButton("Allow access", null, onGrant)
    }
}

@Composable
private fun EmptyState(msg: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.AutoStories, null, tint = RC.Muted.copy(alpha = 0.6f), modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(msg, color = RC.Muted, fontSize = 14.sp)
    }
}
