package com.reader.app.ui

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val MAX_ZOOM = 5f

/** A sharp re-render of the visible part of a zoomed page. */
class ZoomRegion(val page: Int, val z: Float, val tx: Float, val ty: Float, val bitmap: Bitmap)

/**
 * Geometry of one page turn. The current page is folded around the perpendicular bisector of
 * the anchor corner C and the dragged corner P; the page underneath shows through.
 * mode: 0 idle, 1 turning forward (anchor on the right), -1 turning back (anchor on the left).
 */
@Stable
class CurlState {
    var mode by mutableIntStateOf(0)
    var cx by mutableFloatStateOf(0f)
    var cy by mutableFloatStateOf(0f)
    var px by mutableFloatStateOf(0f)
    var py by mutableFloatStateOf(0f)
    var w = 0f
    var h = 0f
    var busy = false
    private var job: Job? = null

    fun begin(m: Int, width: Float, height: Float, bottom: Boolean) {
        job?.cancel()
        w = width
        h = height
        cx = if (m == 1) width else 0f
        cy = if (bottom) height else 0f
        px = cx
        py = cy
        mode = m
    }

    /** dx, dy = finger movement since the touch started. */
    fun drag(dx: Float, dy: Float) {
        var x = cx + dx * 2f
        x = if (mode == 1) x.coerceIn(-w, cx) else x.coerceIn(cx, 2f * w)
        var y = cy + dy * 1.4f
        y = if (cy >= h) y.coerceIn(h * 0.35f, h) else y.coerceIn(0f, h * 0.65f)
        px = x
        py = y
    }

    fun animateTo(scope: CoroutineScope, toX: Float, toY: Float, ms: Int, arc: Float, onEnd: () -> Unit) {
        job?.cancel()
        val x0 = px
        val y0 = py
        val sg = if (cy >= h) -1f else 1f
        busy = true
        job = scope.launch {
            animate(0f, 1f, animationSpec = tween(ms, easing = LinearEasing)) { k, _ ->
                val e = 0.5f - 0.5f * cos(PI.toFloat() * k)
                px = x0 + (toX - x0) * e
                py = y0 + (toY - y0) * e + sg * arc * sin(PI.toFloat() * e)
            }
            busy = false
            onEnd()
        }
    }

    fun commitX(forward: Boolean) = if (forward) -w - 2f else 2f * w + 2f
}

@Stable
class ZoomState {
    var z by mutableFloatStateOf(1f)
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)
    var anim: Job? = null

    fun clamp(w: Float, h: Float) {
        tx = tx.coerceIn(w - w * z, 0f)
        ty = ty.coerceIn(h - h * z, 0f)
    }

    fun reset() {
        anim?.cancel()
        z = 1f
        tx = 0f
        ty = 0f
    }
}

private class TapState {
    var lastTime = 0L
    var lastX = 0f
    var lastY = 0f
    var pending: Job? = null
}

private class CurlPaints(private val theme: Int, val density: Float) {
    val pageColor: Int = when (theme) {
        1 -> 0xFFF5E6B8.toInt()
        2 -> 0xFF070709.toInt()
        else -> 0xFFFFFFFF.toInt()
    }

    private fun base(): ColorMatrix = when (theme) {
        1 -> ColorMatrix(
            floatArrayOf(
                0.96f, 0f, 0f, 0f, 0f,
                0f, 0.90f, 0f, 0f, 0f,
                0f, 0f, 0.72f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        2 -> ColorMatrix(
            floatArrayOf(
                -0.86f, 0f, 0f, 0f, 226f,
                0f, -0.86f, 0f, 0f, 228f,
                0f, 0f, -0.86f, 0f, 236f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        else -> ColorMatrix()
    }

    val bmp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(base())
    }

    /** The back of a page: mostly paper colour with a faint ghost of the print showing through. */
    val back = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        val cm = base()
        val k = 0.16f
        val r = ((pageColor shr 16) and 0xFF) * (1f - k)
        val g = ((pageColor shr 8) and 0xFF) * (1f - k)
        val b = (pageColor and 0xFF) * (1f - k)
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    k, 0f, 0f, 0f, r,
                    0f, k, 0f, 0f, g,
                    0f, 0f, k, 0f, b,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        colorFilter = ColorMatrixColorFilter(cm)
    }
    val shade = Paint()
    val path = Path()
    val matrix = Matrix()
    val dst = RectF()
}

private fun clipPoly(poly: List<FloatArray>, nx: Float, ny: Float, d0: Float, sign: Float): List<FloatArray> {
    val out = ArrayList<FloatArray>()
    val n = poly.size
    for (i in 0 until n) {
        val a = poly[i]
        val b = poly[(i + 1) % n]
        val sa = sign * (a[0] * nx + a[1] * ny - d0)
        val sb = sign * (b[0] * nx + b[1] * ny - d0)
        if (sa >= 0f) out.add(a)
        if ((sa >= 0f) != (sb >= 0f)) {
            val t = sa / (sa - sb)
            out.add(floatArrayOf(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
        }
    }
    return out
}

private fun setPath(path: Path, poly: List<FloatArray>) {
    path.reset()
    path.moveTo(poly[0][0], poly[0][1])
    for (i in 1 until poly.size) path.lineTo(poly[i][0], poly[i][1])
    path.close()
}

private fun drawFlat(c: android.graphics.Canvas, bmp: Bitmap?, w: Float, h: Float, p: CurlPaints) {
    c.drawColor(p.pageColor)
    if (bmp != null) {
        p.dst.set(0f, 0f, w, h)
        c.drawBitmap(bmp, null, p.dst, p.bmp)
    }
}

private fun drawZoomed(
    c: android.graphics.Canvas, w: Float, h: Float, bmp: Bitmap?,
    region: ZoomRegion?, page: Int, z: Float, tx: Float, ty: Float, p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    if (region != null && region.page == page && abs(region.z - z) < 0.003f &&
        abs(region.tx - tx) < 1.5f && abs(region.ty - ty) < 1.5f
    ) {
        c.drawBitmap(region.bitmap, null, p.dst, p.bmp)
    } else if (bmp != null) {
        c.save()
        c.translate(tx, ty)
        c.scale(z, z)
        c.drawBitmap(bmp, null, p.dst, p.bmp)
        c.restore()
    }
}

private fun drawSlide(
    c: android.graphics.Canvas, w: Float, h: Float, turning: Bitmap?, under: Bitmap?,
    px: Float, forward: Boolean, p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    val t = (if (forward) (w - px) / (2f * w) else px / (2f * w)).coerceIn(0f, 1f)
    if (under != null) {
        c.save()
        c.translate(if (forward) w * 0.2f * (1f - t) else -w * 0.2f * (1f - t), 0f)
        c.drawBitmap(under, null, p.dst, p.bmp)
        c.restore()
    }
    if (turning != null) {
        val x = if (forward) -t * w else t * w
        c.save()
        c.translate(x, 0f)
        c.drawBitmap(turning, null, p.dst, p.bmp)
        c.restore()
        if (forward) {
            val edge = x + w
            p.shade.shader = LinearGradient(edge, 0f, edge + 36f, 0f, 0x55000000, 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(edge, 0f, edge + 36f, h, p.shade)
        } else {
            p.shade.shader = LinearGradient(x, 0f, x - 36f, 0f, 0x55000000, 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(x - 36f, 0f, x, h, p.shade)
        }
        p.shade.shader = null
    }
}

/**
 * Page curl: fold the current page [turning] around the bisector of C (anchor) and P (finger),
 * mirror the lifted part on top, and let [under] show where the page was lifted.
 */
private fun drawCurl(
    c: android.graphics.Canvas,
    w: Float,
    h: Float,
    turning: Bitmap?,
    under: Bitmap?,
    cx: Float,
    cy: Float,
    px: Float,
    py: Float,
    p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    var nx = px - cx
    var ny = py - cy
    val len = hypot(nx, ny)
    if (len < 2f) {
        if (turning != null) c.drawBitmap(turning, null, p.dst, p.bmp)
        return
    }
    nx /= len
    ny /= len
    val mx = (px + cx) / 2f
    val my = (py + cy) / 2f
    val d0 = mx * nx + my * ny
    val rect = listOf(floatArrayOf(0f, 0f), floatArrayOf(w, 0f), floatArrayOf(w, h), floatArrayOf(0f, h))
    val flat = clipPoly(rect, nx, ny, d0, 1f)
    val folded = clipPoly(rect, nx, ny, d0, -1f)
    val sw = 46f * p.density

    // 1) the page underneath, shaded next to the fold
    if (under != null) c.drawBitmap(under, null, p.dst, p.bmp)
    if (folded.size > 2) {
        c.save()
        setPath(p.path, folded)
        c.clipPath(p.path)
        p.shade.shader = LinearGradient(mx, my, mx - nx * sw, my - ny * sw, 0x6B000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(p.dst, p.shade)
        c.restore()
    }

    // 2) the part of the current page that is still flat
    if (flat.size > 2) {
        c.save()
        setPath(p.path, flat)
        c.clipPath(p.path)
        if (turning != null) c.drawBitmap(turning, null, p.dst, p.bmp)
        p.shade.shader = LinearGradient(mx, my, mx + nx * sw, my + ny * sw, 0x61000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(p.dst, p.shade)
        c.restore()
    }

    // 3) the lifted part, folded over: mirror image of the page across the fold line
    if (folded.size > 2 && turning != null) {
        val refl = ArrayList<FloatArray>(folded.size)
        for (q in folded) {
            val k = 2f * (q[0] * nx + q[1] * ny - d0)
            refl.add(floatArrayOf(q[0] - k * nx, q[1] - k * ny))
        }
        c.save()
        c.clipRect(p.dst)
        setPath(p.path, refl)
        c.clipPath(p.path)
        c.save()
        p.matrix.setValues(
            floatArrayOf(
                1f - 2f * nx * nx, -2f * nx * ny, 2f * d0 * nx,
                -2f * nx * ny, 1f - 2f * ny * ny, 2f * d0 * ny,
                0f, 0f, 1f
            )
        )
        c.concat(p.matrix)
        c.drawBitmap(turning, null, p.dst, p.back)
        c.restore()
        // soft light across the whole flap
        p.shade.shader = LinearGradient(
            mx, my, px, py,
            intArrayOf(0x4D000000, 0x0F000000, 0x1AFFFFFF, 0x1F000000),
            floatArrayOf(0f, 0.12f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(p.dst, p.shade)
        // the rolled edge: a dark crease, then a bright highlight, right at the fold
        val band = 30f * p.density
        p.shade.shader = LinearGradient(
            mx, my, mx + nx * band, my + ny * band,
            intArrayOf(0x45000000, 0x38FFFFFF, 0x10FFFFFF, 0x00000000),
            floatArrayOf(0f, 0.32f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(p.dst, p.shade)
        c.restore()
    }
    p.shade.shader = null
}

/**
 * Full-screen pager. Single finger: curl (or slide) page turn / pan when zoomed.
 * Two fingers or double-tap: zoom (when [zoomEnabled]). Tap the screen edges to turn pages.
 */
@Composable
fun PageCurlPager(
    pageCount: Int,
    page: Int,
    onPageChange: (Int) -> Unit,
    bitmapFor: (Int) -> Bitmap?,
    cacheVersion: Int,
    theme: Int,
    curl: Boolean,
    zoomEnabled: Boolean,
    region: ZoomRegion?,
    onZoomSettled: (Int, Float, Float, Float) -> Unit,
    onCenterTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val st = remember { CurlState() }
    val zs = remember { ZoomState() }
    val taps = remember { TapState() }
    val curPage by rememberUpdatedState(page)
    val curCount by rememberUpdatedState(pageCount)
    val onChange by rememberUpdatedState(onPageChange)
    val onTap by rememberUpdatedState(onCenterTap)
    val zoomOn by rememberUpdatedState(zoomEnabled)
    val onSettle by rememberUpdatedState(onZoomSettled)
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val paints = remember(theme, density) { CurlPaints(theme, density) }

    LaunchedEffect(page) { zs.reset() }

    // ask for a sharp re-render once zooming / panning has settled
    LaunchedEffect(Unit) {
        snapshotFlow { Triple(zs.z, zs.tx, zs.ty) }.collectLatest { v ->
            if (v.first > 1.02f && zoomOn) {
                delay(180)
                onSettle(curPage, v.first, v.second, v.third)
            }
        }
    }

    fun animateZoom(z1: Float, ax: Float, ay: Float, w: Float, h: Float) {
        zs.anim?.cancel()
        val z0 = zs.z
        val tx0 = zs.tx
        val ty0 = zs.ty
        var tx1 = 0f
        var ty1 = 0f
        if (z1 > 1f) {
            val px = (ax - tx0) / z0
            val py = (ay - ty0) / z0
            tx1 = (ax - px * z1).coerceIn(w - w * z1, 0f)
            ty1 = (ay - py * z1).coerceIn(h - h * z1, 0f)
        }
        zs.anim = scope.launch {
            animate(0f, 1f, animationSpec = tween(260, easing = FastOutSlowInEasing)) { f, _ ->
                zs.z = z0 + (z1 - z0) * f
                zs.tx = tx0 + (tx1 - tx0) * f
                zs.ty = ty0 + (ty1 - ty0) * f
            }
        }
    }

    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (st.busy) return@awaitEachGesture
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val start = down.position
                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, start)
                    val slop = viewConfiguration.touchSlop
                    zs.anim?.cancel()

                    // 0 undecided, 1 curl drag, 2 pan, 3 pinch, 4 ignore
                    var mode = 0
                    var dir = 0
                    var lastDx = 0f
                    var maxMove = 0f
                    var lastSpan = 0f
                    var lastCen = Offset.Zero
                    var lastPos = start

                    while (true) {
                        val ev = awaitPointerEvent()
                        val pressed = ev.changes.filter { it.pressed }

                        if (pressed.isEmpty()) {
                            // ---- all fingers up ----
                            if (mode == 1) {
                                val vx = tracker.calculateVelocity().x
                                val d = dir
                                val mag = -d * lastDx
                                val along = -d * vx
                                val commit = (mag > w * 0.22f || along > 1000f) && along > -1000f
                                val newPage = curPage + d
                                if (commit) {
                                    st.animateTo(scope, st.commitX(d == 1), st.cy, 380, 0f) {
                                        onChange(newPage)
                                        st.mode = 0
                                    }
                                } else {
                                    st.animateTo(scope, st.cx, st.cy, 240, 0f) { st.mode = 0 }
                                }
                            } else if (mode == 2 || mode == 3) {
                                if (zs.z < 1.05f) animateZoom(1f, w / 2f, h / 2f, w, h)
                            } else if (mode == 0 && maxMove < slop * 2) {
                                val x = start.x
                                val zoomed = zs.z > 1.01f
                                val centre = x > w * 0.25f && x < w * 0.75f
                                val now = down.uptimeMillis
                                val isDouble = zoomOn && (centre || zoomed) &&
                                    now - taps.lastTime < 300 &&
                                    hypot(start.x - taps.lastX, start.y - taps.lastY) < 90f
                                if (isDouble) {
                                    taps.pending?.cancel()
                                    taps.lastTime = 0L
                                    if (zoomed) animateZoom(1f, start.x, start.y, w, h)
                                    else animateZoom(2.5f, start.x, start.y, w, h)
                                } else {
                                    taps.lastTime = now
                                    taps.lastX = start.x
                                    taps.lastY = start.y
                                    taps.pending?.cancel()
                                    if (zoomed) {
                                        taps.pending = scope.launch { delay(280); onTap() }
                                    } else if (x > w * 0.7f && curPage < curCount - 1) {
                                        st.begin(1, w, h, start.y > h / 2f)
                                        st.px = st.cx - 2f
                                        st.animateTo(scope, st.commitX(true), st.cy, 600, h * 0.1f) {
                                            onChange(curPage + 1)
                                            st.mode = 0
                                        }
                                    } else if (x < w * 0.3f && curPage > 0) {
                                        st.begin(-1, w, h, start.y > h / 2f)
                                        st.px = st.cx + 2f
                                        st.animateTo(scope, st.commitX(false), st.cy, 600, h * 0.1f) {
                                            onChange(curPage - 1)
                                            st.mode = 0
                                        }
                                    } else if (x > w * 0.7f || x < w * 0.3f) {
                                        // first / last page: nothing to turn, just show the controls
                                        onTap()
                                    } else {
                                        val d = if (zoomOn) 280L else 0L
                                        taps.pending = scope.launch { delay(d); onTap() }
                                    }
                                }
                            }
                            break
                        }

                        // ---- two fingers: pinch to zoom ----
                        if (pressed.size >= 2 && zoomOn && mode != 1) {
                            val a = pressed[0].position
                            val b = pressed[1].position
                            val cen = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                            val span = hypot(a.x - b.x, a.y - b.y)
                            if (mode != 3) {
                                mode = 3
                                lastSpan = span
                                lastCen = cen
                                taps.pending?.cancel()
                            } else if (lastSpan > 1f) {
                                val oldZ = zs.z
                                val newZ = (oldZ * span / lastSpan).coerceIn(1f, MAX_ZOOM)
                                zs.tx = cen.x - (lastCen.x - zs.tx) * newZ / oldZ
                                zs.ty = cen.y - (lastCen.y - zs.ty) * newZ / oldZ
                                zs.z = newZ
                                zs.clamp(w, h)
                                lastSpan = span
                                lastCen = cen
                            }
                            pressed.forEach { it.consume() }
                            continue
                        }

                        // ---- one finger ----
                        val ch = pressed.firstOrNull { it.id == down.id } ?: pressed[0]
                        val pos = ch.position
                        if (mode == 3) {
                            // a finger was lifted after pinching: continue as pan if zoomed
                            mode = if (zs.z > 1.01f) 2 else 4
                            lastPos = pos
                            ch.consume()
                            continue
                        }
                        tracker.addPosition(ch.uptimeMillis, pos)
                        val dx = pos.x - start.x
                        val dy = pos.y - start.y
                        maxMove = max(maxMove, hypot(dx, dy))

                        if (mode == 0 && maxMove > slop) {
                            if (zs.z > 1.01f) {
                                mode = 2
                                lastPos = pos
                                taps.pending?.cancel()
                            } else if (abs(dx) > slop && abs(dx) > abs(dy) * 0.6f) {
                                val m = if (dx < 0) 1 else -1
                                val ok = (m == 1 && curPage < curCount - 1) || (m == -1 && curPage > 0)
                                if (ok) {
                                    mode = 1
                                    dir = m
                                    taps.pending?.cancel()
                                    st.begin(m, w, h, start.y > h / 2f)
                                } else {
                                    mode = 4
                                }
                            } else if (abs(dy) > slop) {
                                mode = 4
                            }
                        }
                        if (mode == 1) {
                            lastDx = dx
                            st.drag(dx, dy)
                            ch.consume()
                        } else if (mode == 2) {
                            zs.tx += pos.x - lastPos.x
                            zs.ty += pos.y - lastPos.y
                            zs.clamp(w, h)
                            lastPos = pos
                            ch.consume()
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            @Suppress("UNUSED_VARIABLE")
            val version = cacheVersion
            drawIntoCanvas { cv ->
                val c = cv.nativeCanvas
                when (st.mode) {
                    1 -> if (curl) {
                        drawCurl(c, w, h, bitmapFor(page), bitmapFor(page + 1), st.cx, st.cy, st.px, st.py, paints)
                    } else {
                        drawSlide(c, w, h, bitmapFor(page), bitmapFor(page + 1), st.px, true, paints)
                    }
                    -1 -> if (curl) {
                        drawCurl(c, w, h, bitmapFor(page), bitmapFor(page - 1), st.cx, st.cy, st.px, st.py, paints)
                    } else {
                        drawSlide(c, w, h, bitmapFor(page), bitmapFor(page - 1), st.px, false, paints)
                    }
                    else -> if (zs.z > 1.001f) {
                        drawZoomed(c, w, h, bitmapFor(page), region, page, zs.z, zs.tx, zs.ty, paints)
                    } else {
                        drawFlat(c, bitmapFor(page), w, h, paints)
                    }
                }
            }
        }
    }
}
