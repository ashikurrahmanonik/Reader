package com.reader.app.ui

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot

private const val OFF = 1.05f      // how far (in page widths) the flap travels off-screen
private const val DRAG_SPAN = 0.85f // finger travel (in page widths) for a full turn

/** Holds the live geometry of a page turn. */
@Stable
class CurlState {
    /** 0 = idle, 1 = turning current page forward, -1 = bringing previous page back */
    var mode by mutableIntStateOf(0)
    var tx by mutableFloatStateOf(0f)   // where the lifted corner currently is
    var ty by mutableFloatStateOf(0f)
    var cy by mutableFloatStateOf(0f)   // y of the corner being lifted (0 or H)
    var w = 0f
    var h = 0f
    var busy = false
    private var job: Job? = null

    fun begin(m: Int, width: Float, height: Float, bottom: Boolean) {
        job?.cancel()
        w = width
        h = height
        cy = if (bottom) height else 0f
        mode = m
        if (m == 1) {
            tx = width
        } else {
            tx = -OFF * width
        }
        ty = cy
    }

    /** t in 0..1 = how far the turn has progressed. */
    fun drag(t: Float, dy: Float) {
        val from = if (mode == 1) w else -OFF * w
        val to = if (mode == 1) -OFF * w else w
        tx = from + (to - from) * t.coerceIn(0f, 1f)
        ty = (cy + dy * 0.6f).coerceIn(-0.15f * h, 1.15f * h)
    }

    fun animateTo(scope: CoroutineScope, toX: Float, toY: Float, ms: Int, onEnd: () -> Unit) {
        job?.cancel()
        val x0 = tx
        val y0 = ty
        busy = true
        job = scope.launch {
            animate(0f, 1f, animationSpec = tween(ms, easing = FastOutSlowInEasing)) { f, _ ->
                tx = x0 + (toX - x0) * f
                ty = y0 + (toY - y0) * f
            }
            busy = false
            onEnd()
        }
    }

    fun finishX(forward: Boolean) = if (forward) -OFF * w else w
    fun restX(forward: Boolean) = if (forward) w else -OFF * w
}

private class CurlPaints(private val theme: Int) {
    val pageColor: Int = when (theme) {
        1 -> 0xFFF5E6B8.toInt()
        2 -> 0xFF070709.toInt()
        else -> 0xFFFFFFFF.toInt()
    }
    private fun base(): ColorMatrix = when (theme) {
        1 -> ColorMatrix(
            floatArrayOf(
                0.96f, 0f, 0f, 0f, 0f,
                0f, 0.90f, 0f, 0f, 0f,
                0f, 0f, 0.72f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        2 -> ColorMatrix(
            floatArrayOf(
                -0.86f, 0f, 0f, 0f, 226f,
                0f, -0.86f, 0f, 0f, 228f,
                0f, 0f, -0.86f, 0f, 236f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        else -> ColorMatrix()
    }

    val bmp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(base())
    }
    val back = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        val cm = base()
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    0.93f, 0f, 0f, 0f, 14f,
                    0f, 0.93f, 0f, 0f, 14f,
                    0f, 0f, 0.93f, 0f, 14f,
                    0f, 0f, 0f, 0.98f, 0f
                )
            )
        )
        colorFilter = ColorMatrixColorFilter(cm)
    }
    val shade = Paint()
    val path = Path()
    val matrix = Matrix()
    val dst = RectF()
}

/** Builds a huge half-plane through (mx,my). side=+1 -> the corner side, -1 -> the far side. */
private fun halfPlane(path: Path, mx: Float, my: Float, ux: Float, uy: Float, side: Float) {
    val big = 6000f
    val dx = -uy * big
    val dy = ux * big
    val ox = ux * big * side
    val oy = uy * big * side
    path.reset()
    path.moveTo(mx + dx, my + dy)
    path.lineTo(mx - dx, my - dy)
    path.lineTo(mx - dx + ox, my - dy + oy)
    path.lineTo(mx + dx + ox, my + dy + oy)
    path.close()
}

private fun drawFlat(c: android.graphics.Canvas, bmp: Bitmap?, w: Float, h: Float, p: CurlPaints) {
    c.drawColor(p.pageColor)
    if (bmp != null) {
        p.dst.set(0f, 0f, w, h)
        c.drawBitmap(bmp, null, p.dst, p.bmp)
    }
}

private fun drawCurl(
    c: android.graphics.Canvas,
    w: Float,
    h: Float,
    turning: Bitmap?,
    under: Bitmap?,
    tx: Float,
    ty: Float,
    cy: Float,
    p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    if (under != null) c.drawBitmap(under, null, p.dst, p.bmp)
    if (turning == null) return

    val dxv = w - tx
    val dyv = cy - ty
    val dist = hypot(dxv, dyv)
    if (dist < 1f) {
        c.drawBitmap(turning, null, p.dst, p.bmp)
        return
    }
    val ux = dxv / dist
    val uy = dyv / dist
    val mx = (tx + w) / 2f
    val my = (ty + cy) / 2f

    // 1) soft shadow cast on the page underneath, next to the fold
    c.save()
    halfPlane(p.path, mx, my, ux, uy, 1f)
    c.clipPath(p.path)
    c.clipRect(p.dst)
    p.shade.shader = LinearGradient(
        mx, my, mx + ux * 56f, my + uy * 56f,
        0x70000000, 0x00000000, Shader.TileMode.CLAMP
    )
    c.drawRect(p.dst, p.shade)
    c.restore()

    // 2) the part of the page that has not been lifted
    c.save()
    halfPlane(p.path, mx, my, ux, uy, -1f)
    c.clipPath(p.path)
    c.clipRect(p.dst)
    c.drawBitmap(turning, null, p.dst, p.bmp)
    c.restore()

    // 3) the folded-over flap: mirror of the lifted part across the fold line
    c.save()
    halfPlane(p.path, mx, my, ux, uy, -1f)
    c.clipPath(p.path)
    c.clipRect(p.dst)
    val k = 2f * (mx * ux + my * uy)
    p.matrix.setValues(
        floatArrayOf(
            1f - 2f * ux * ux, -2f * ux * uy, k * ux,
            -2f * ux * uy, 1f - 2f * uy * uy, k * uy,
            0f, 0f, 1f
        )
    )
    c.concat(p.matrix)
    c.drawBitmap(turning, null, p.dst, p.back)
    // shading across the flap, in its own (pre-mirror) space
    p.shade.shader = LinearGradient(
        mx, my, mx + ux * 90f, my + uy * 90f,
        intArrayOf(0x66000000, 0x22FFFFFF, 0x00000000),
        floatArrayOf(0f, 0.22f, 1f),
        Shader.TileMode.CLAMP
    )
    c.drawRect(p.dst, p.shade)
    c.restore()
    p.shade.shader = null
}

/**
 * Full-screen pager with a real page-curl. Drag from either side, or tap the screen edges.
 * Bitmaps are supplied by the caller (rendered at the pager's size).
 */
@Composable
fun PageCurlPager(
    pageCount: Int,
    page: Int,
    onPageChange: (Int) -> Unit,
    bitmapFor: (Int) -> Bitmap?,
    cacheVersion: Int,
    theme: Int,
    onCenterTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val st = remember { CurlState() }
    val curPage by rememberUpdatedState(page)
    val curCount by rememberUpdatedState(pageCount)
    val onChange by rememberUpdatedState(onPageChange)
    val onTap by rememberUpdatedState(onCenterTap)
    val paints = remember(theme) { CurlPaints(theme) }

    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (st.busy) return@awaitEachGesture
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val start = down.position
                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, down.position)
                    val slop = viewConfiguration.touchSlop
                    var dragging = false
                    var blocked = false
                    var dir = 0
                    var progress = 0f
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) {
                            if (dragging) {
                                val vx = tracker.calculateVelocity().x
                                val forward = dir == 1
                                val complete = if (forward) {
                                    vx < -1000f || (progress > 0.35f && vx < 400f)
                                } else {
                                    vx > 1000f || (progress > 0.35f && vx > -400f)
                                }
                                if (complete) {
                                    val target = st.finishX(forward)
                                    val newPage = if (forward) curPage + 1 else curPage - 1
                                    st.animateTo(scope, target, st.cy, 320) {
                                        onChange(newPage)
                                        st.mode = 0
                                    }
                                } else {
                                    val target = st.restX(forward)
                                    st.animateTo(scope, target, st.cy, 260) { st.mode = 0 }
                                }
                            } else if (!blocked) {
                                val x = start.x
                                val moved = hypot(ch.position.x - start.x, ch.position.y - start.y)
                                if (moved < slop * 2) {
                                    if (x > w * 0.7f && curPage < curCount - 1) {
                                        st.begin(1, w, h, true)
                                        st.animateTo(scope, st.finishX(true), h * 0.92f, 480) {
                                            onChange(curPage + 1)
                                            st.mode = 0
                                        }
                                    } else if (x < w * 0.3f && curPage > 0) {
                                        st.begin(-1, w, h, true)
                                        st.animateTo(scope, st.finishX(false), h, 480) {
                                            onChange(curPage - 1)
                                            st.mode = 0
                                        }
                                    } else {
                                        onTap()
                                    }
                                }
                            }
                            break
                        }
                        tracker.addPosition(ch.uptimeMillis, ch.position)
                        val dx = ch.position.x - start.x
                        val dy = ch.position.y - start.y
                        if (!dragging && !blocked) {
                            if (abs(dx) > slop && abs(dx) > abs(dy) * 0.6f) {
                                val m = if (dx < 0) 1 else -1
                                val ok = (m == 1 && curPage < curCount - 1) || (m == -1 && curPage > 0)
                                if (ok) {
                                    dragging = true
                                    dir = m
                                    st.begin(m, w, h, start.y > h / 2f)
                                } else {
                                    blocked = true
                                }
                            }
                        }
                        if (dragging) {
                            progress = if (dir == 1) (-dx) / (DRAG_SPAN * w) else dx / (DRAG_SPAN * w)
                            progress = progress.coerceIn(0f, 1f)
                            st.drag(progress, dy)
                            ch.consume()
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            @Suppress("UNUSED_VARIABLE")
            val version = cacheVersion
            drawIntoCanvas { cv ->
                val c = cv.nativeCanvas
                when (st.mode) {
                    1 -> drawCurl(c, w, h, bitmapFor(page), bitmapFor(page + 1), st.tx, st.ty, st.cy, paints)
                    -1 -> drawCurl(c, w, h, bitmapFor(page - 1), bitmapFor(page), st.tx, st.ty, st.cy, paints)
                    else -> drawFlat(c, bitmapFor(page), w, h, paints)
                }
            }
        }
    }
}
