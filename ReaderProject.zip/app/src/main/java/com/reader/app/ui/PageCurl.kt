package com.reader.app.ui

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val OFF = 1.05f       // how far (in page widths) the flap travels off-screen
private const val DRAG_SPAN = 0.85f // finger travel (in page widths) for a full turn
private const val MAX_ZOOM = 5f

/** A sharp re-render of the visible part of a zoomed page. */
class ZoomRegion(val page: Int, val z: Float, val tx: Float, val ty: Float, val bitmap: Bitmap)

/** Holds the live geometry of a page turn. */
@Stable
class CurlState {
    /** 0 = idle, 1 = turning current page forward, -1 = bringing previous page back */
    var mode by mutableIntStateOf(0)
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)
    var cy by mutableFloatStateOf(0f)
    var w = 0f
    var h = 0f
    var busy = false
    private var job: Job? = null

    fun begin(m: Int, width: Float, height: Float, bottom: Boolean) {
        job?.cancel()
        w = width
        h = height
        cy = if (bottom) height else 0f
        mode = m
        tx = if (m == 1) width else -OFF * width
        ty = cy
    }

    /** t in 0..1 = how far the turn has progressed. */
    fun drag(t: Float, dy: Float) {
        val from = if (mode == 1) w else -OFF * w
        val to = if (mode == 1) -OFF * w else w
        tx = from + (to - from) * t.coerceIn(0f, 1f)
        ty = (cy + dy * 0.6f).coerceIn(-0.15f * h, 1.15f * h)
    }

    fun animateTo(scope: CoroutineScope, toX: Float, toY: Float, ms: Int, onEnd: () -> Unit) {
        job?.cancel()
        val x0 = tx
        val y0 = ty
        busy = true
        job = scope.launch {
            animate(0f, 1f, animationSpec = tween(ms, easing = FastOutSlowInEasing)) { f, _ ->
                tx = x0 + (toX - x0) * f
                ty = y0 + (toY - y0) * f
            }
            busy = false
            onEnd()
        }
    }

    fun finishX(forward: Boolean) = if (forward) -OFF * w else w
    fun restX(forward: Boolean) = if (forward) w else -OFF * w
}

@Stable
class ZoomState {
    var z by mutableFloatStateOf(1f)
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)
    var anim: Job? = null

    fun clamp(w: Float, h: Float) {
        tx = tx.coerceIn(w - w * z, 0f)
        ty = ty.coerceIn(h - h * z, 0f)
    }

    fun reset() {
        anim?.cancel()
        z = 1f
        tx = 0f
        ty = 0f
    }
}

private class TapState {
    var lastTime = 0L
    var lastX = 0f
    var lastY = 0f
    var pending: Job? = null
}

private class CurlPaints(private val theme: Int) {
    val pageColor: Int = when (theme) {
        1 -> 0xFFF5E6B8.toInt()
        2 -> 0xFF070709.toInt()
        else -> 0xFFFFFFFF.toInt()
    }

    private fun base(): ColorMatrix = when (theme) {
        1 -> ColorMatrix(
            floatArrayOf(
                0.96f, 0f, 0f, 0f, 0f,
                0f, 0.90f, 0f, 0f, 0f,
                0f, 0f, 0.72f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        2 -> ColorMatrix(
            floatArrayOf(
                -0.86f, 0f, 0f, 0f, 226f,
                0f, -0.86f, 0f, 0f, 228f,
                0f, 0f, -0.86f, 0f, 236f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        else -> ColorMatrix()
    }

    val bmp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(base())
    }
    val back = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        val cm = base()
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    0.93f, 0f, 0f, 0f, 14f,
                    0f, 0.93f, 0f, 0f, 14f,
                    0f, 0f, 0.93f, 0f, 14f,
                    0f, 0f, 0f, 0.98f, 0f
                )
            )
        )
        colorFilter = ColorMatrixColorFilter(cm)
    }
    val shade = Paint()
    val path = Path()
    val matrix = Matrix()
    val dst = RectF()
}

/** Builds a huge half-plane through (mx,my). side=+1 -> the corner side, -1 -> the far side. */
private fun halfPlane(path: Path, mx: Float, my: Float, ux: Float, uy: Float, side: Float) {
    val big = 6000f
    val dx = -uy * big
    val dy = ux * big
    val ox = ux * big * side
    val oy = uy * big * side
    path.reset()
    path.moveTo(mx + dx, my + dy)
    path.lineTo(mx - dx, my - dy)
    path.lineTo(mx - dx + ox, my - dy + oy)
    path.lineTo(mx + dx + ox, my + dy + oy)
    path.close()
}

private fun drawFlat(c: android.graphics.Canvas, bmp: Bitmap?, w: Float, h: Float, p: CurlPaints) {
    c.drawColor(p.pageColor)
    if (bmp != null) {
        p.dst.set(0f, 0f, w, h)
        c.drawBitmap(bmp, null, p.dst, p.bmp)
    }
}

private fun drawZoomed(
    c: android.graphics.Canvas, w: Float, h: Float, bmp: Bitmap?,
    region: ZoomRegion?, page: Int, z: Float, tx: Float, ty: Float, p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    if (region != null && region.page == page && abs(region.z - z) < 0.003f &&
        abs(region.tx - tx) < 1.5f && abs(region.ty - ty) < 1.5f
    ) {
        c.drawBitmap(region.bitmap, null, p.dst, p.bmp)
    } else if (bmp != null) {
        c.save()
        c.translate(tx, ty)
        c.scale(z, z)
        c.drawBitmap(bmp, null, p.dst, p.bmp)
        c.restore()
    }
}

private fun drawSlide(
    c: android.graphics.Canvas, w: Float, h: Float, turning: Bitmap?, under: Bitmap?,
    tx: Float, forward: Boolean, p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    val total = (1f + OFF) * w
    val t = (if (forward) (w - tx) / total else (tx + OFF * w) / total).coerceIn(0f, 1f)
    if (under != null) {
        c.save()
        c.translate(if (forward) w * 0.22f * (1f - t) else 0f, 0f)
        c.drawBitmap(under, null, p.dst, p.bmp)
        c.restore()
    }
    if (turning != null) {
        val x = if (forward) -t * w else -w + t * w
        c.save()
        c.translate(x, 0f)
        c.drawBitmap(turning, null, p.dst, p.bmp)
        c.restore()
        val edge = x + w
        p.shade.shader = LinearGradient(edge, 0f, edge + 36f, 0f, 0x55000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(edge, 0f, edge + 36f, h, p.shade)
        p.shade.shader = null
    }
}

private fun drawCurl(
    c: android.graphics.Canvas,
    w: Float,
    h: Float,
    turning: Bitmap?,
    under: Bitmap?,
    tx: Float,
    ty: Float,
    cy: Float,
    p: CurlPaints
) {
    c.drawColor(p.pageColor)
    p.dst.set(0f, 0f, w, h)
    if (under != null) c.drawBitmap(under, null, p.dst, p.bmp)
    if (turning == null) return

    val dxv = w - tx
    val dyv = cy - ty
    val dist = hypot(dxv, dyv)
    if (dist < 1f) {
        c.drawBitmap(turning, null, p.dst, p.bmp)
        return
    }
    val ux = dxv / dist
    val uy = dyv / dist
    val mx = (tx + w) / 2f
    val my = (ty + cy) / 2f
    val angle = Math.toDegrees(atan2(uy, ux).toDouble()).toFloat()
    val pi = PI.toFloat()
    val half = dist / 2f

    // The page is wrapped around a cylinder of radius r whose axis is parallel to the fold.
    // Local frame: origin at the fold centre, +x points towards the lifted corner.
    //   page coordinate p <= a          : flat, still lying on the book
    //   a < p < a + pi*r                : wrapped around the cylinder (screen x = a + r*sin((p-a)/r))
    //   p >= a + pi*r                   : flat again, lying on top, mirrored (screen x = -p)
    val r = min(w * 0.075f, half / pi * 0.92f)
    val a = -pi * r / 2f
    val big = 6000f

    c.save()
    c.clipRect(p.dst)

    // 1) shadow the rolled page casts on the page underneath
    c.save()
    c.translate(mx, my)
    c.rotate(angle)
    p.shade.shader = LinearGradient(
        a + r, 0f, a + r + 90f, 0f,
        0x77000000, 0x00000000, Shader.TileMode.CLAMP
    )
    c.drawRect(a + r, -big, a + r + 90f, big, p.shade)
    c.restore()

    // 2) the part of the page that is still flat
    c.save()
    c.translate(mx, my)
    c.rotate(angle)
    c.clipRect(-big, -big, a, big)
    c.rotate(-angle)
    c.translate(-mx, -my)
    c.drawBitmap(turning, null, p.dst, p.bmp)
    c.restore()

    // soft darkening of the flat page just before the cylinder
    c.save()
    c.translate(mx, my)
    c.rotate(angle)
    p.shade.shader = LinearGradient(
        a, 0f, a - 46f, 0f,
        0x38000000, 0x00000000, Shader.TileMode.CLAMP
    )
    c.drawRect(a - 46f, -big, a, big, p.shade)
    // shadow of the flap's far edge on the page below it
    p.shade.shader = LinearGradient(
        -half, 0f, -half - 44f, 0f,
        0x55000000, 0x00000000, Shader.TileMode.CLAMP
    )
    c.drawRect(-half - 44f, -big, -half, big, p.shade)
    c.restore()
    p.shade.shader = null

    // 3) the cylinder itself, drawn as thin strips so the curve and its lighting look real
    val arc = pi * r
    val n = (arc / 3.5f).toInt().coerceIn(14, 70)
    for (i in 0 until n) {
        val ph0 = pi * i / n
        val ph1 = pi * (i + 1) / n
        val p0 = a + r * ph0
        val p1 = a + r * ph1
        val x0 = a + r * sin(ph0)
        val x1 = a + r * sin(ph1)
        val xl = min(x0, x1)
        val xr = max(x0, x1)
        if (xr - xl < 0.15f) continue
        val sx = (x1 - x0) / (p1 - p0)

        c.save()
        c.translate(mx, my)
        c.rotate(angle)
        c.clipRect(xl, -big, xr, big)
        c.save()
        c.translate(x0, 0f)
        c.scale(sx, 1f)
        c.translate(-p0, 0f)
        c.rotate(-angle)
        c.translate(-mx, -my)
        c.drawBitmap(turning, null, p.dst, p.back)
        c.restore()
        // lighting from the top-left: dark underneath, bright on top
        val phm = (ph0 + ph1) / 2f
        val b = -0.5f * sin(phm) - 0.85f * cos(phm)
        if (b < 0f) {
            p.shade.color = ((-b * 0.55f * 255f).toInt().coerceIn(0, 140)) shl 24
        } else {
            p.shade.color = (((b * 0.30f * 255f).toInt().coerceIn(0, 110)) shl 24) or 0x00FFFFFF
        }
        c.drawRect(xl, -big, xr, big, p.shade)
        c.restore()
    }

    // 4) the flat flap lying on top (mirror image of the lifted part)
    c.save()
    c.translate(mx, my)
    c.rotate(angle)
    c.clipRect(-big, -big, a, big)
    c.scale(-1f, 1f)
    c.rotate(-angle)
    c.translate(-mx, -my)
    c.drawBitmap(turning, null, p.dst, p.back)
    c.restore()
    // gentle sheen over the flap
    c.save()
    c.translate(mx, my)
    c.rotate(angle)
    p.shade.shader = LinearGradient(
        a, 0f, a - 120f, 0f,
        intArrayOf(0x30FFFFFF, 0x10FFFFFF, 0x00000000),
        floatArrayOf(0f, 0.35f, 1f),
        Shader.TileMode.CLAMP
    )
    c.drawRect(max(-half, a - 120f), -big, a, big, p.shade)
    c.restore()
    p.shade.shader = null
    p.shade.color = 0

    c.restore()
}

/**
 * Full-screen pager. Single finger: curl (or slide) page turn / pan when zoomed.
 * Two fingers or double-tap: zoom (when [zoomEnabled]). Tap the screen edges to turn pages.
 */
@Composable
fun PageCurlPager(
    pageCount: Int,
    page: Int,
    onPageChange: (Int) -> Unit,
    bitmapFor: (Int) -> Bitmap?,
    cacheVersion: Int,
    theme: Int,
    curl: Boolean,
    zoomEnabled: Boolean,
    region: ZoomRegion?,
    onZoomSettled: (Int, Float, Float, Float) -> Unit,
    onCenterTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val st = remember { CurlState() }
    val zs = remember { ZoomState() }
    val taps = remember { TapState() }
    val curPage by rememberUpdatedState(page)
    val curCount by rememberUpdatedState(pageCount)
    val onChange by rememberUpdatedState(onPageChange)
    val onTap by rememberUpdatedState(onCenterTap)
    val zoomOn by rememberUpdatedState(zoomEnabled)
    val onSettle by rememberUpdatedState(onZoomSettled)
    val paints = remember(theme) { CurlPaints(theme) }

    LaunchedEffect(page) { zs.reset() }

    // ask for a sharp re-render once zooming / panning has settled
    LaunchedEffect(Unit) {
        snapshotFlow { Triple(zs.z, zs.tx, zs.ty) }.collectLatest { v ->
            if (v.first > 1.02f && zoomOn) {
                delay(180)
                onSettle(curPage, v.first, v.second, v.third)
            }
        }
    }

    fun animateZoom(z1: Float, ax: Float, ay: Float, w: Float, h: Float) {
        zs.anim?.cancel()
        val z0 = zs.z
        val tx0 = zs.tx
        val ty0 = zs.ty
        var tx1 = 0f
        var ty1 = 0f
        if (z1 > 1f) {
            val px = (ax - tx0) / z0
            val py = (ay - ty0) / z0
            tx1 = (ax - px * z1).coerceIn(w - w * z1, 0f)
            ty1 = (ay - py * z1).coerceIn(h - h * z1, 0f)
        }
        zs.anim = scope.launch {
            animate(0f, 1f, animationSpec = tween(260, easing = FastOutSlowInEasing)) { f, _ ->
                zs.z = z0 + (z1 - z0) * f
                zs.tx = tx0 + (tx1 - tx0) * f
                zs.ty = ty0 + (ty1 - ty0) * f
            }
        }
    }

    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (st.busy) return@awaitEachGesture
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val start = down.position
                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, start)
                    val slop = viewConfiguration.touchSlop
                    zs.anim?.cancel()

                    // 0 undecided, 1 curl drag, 2 pan, 3 pinch, 4 ignore
                    var mode = 0
                    var dir = 0
                    var progress = 0f
                    var maxMove = 0f
                    var lastSpan = 0f
                    var lastCen = Offset.Zero
                    var lastPos = start

                    while (true) {
                        val ev = awaitPointerEvent()
                        val pressed = ev.changes.filter { it.pressed }

                        if (pressed.isEmpty()) {
                            // ---- all fingers up ----
                            if (mode == 1) {
                                val vx = tracker.calculateVelocity().x
                                val forward = dir == 1
                                val complete = if (forward) {
                                    vx < -1000f || (progress > 0.35f && vx < 400f)
                                } else {
                                    vx > 1000f || (progress > 0.35f && vx > -400f)
                                }
                                if (complete) {
                                    val newPage = if (forward) curPage + 1 else curPage - 1
                                    st.animateTo(scope, st.finishX(forward), st.cy, 320) {
                                        onChange(newPage)
                                        st.mode = 0
                                    }
                                } else {
                                    st.animateTo(scope, st.restX(forward), st.cy, 260) { st.mode = 0 }
                                }
                            } else if (mode == 2 || mode == 3) {
                                if (zs.z < 1.05f) animateZoom(1f, w / 2f, h / 2f, w, h)
                            } else if (mode == 0 && maxMove < slop * 2) {
                                val x = start.x
                                val zoomed = zs.z > 1.01f
                                val centre = x > w * 0.25f && x < w * 0.75f
                                val now = down.uptimeMillis
                                val isDouble = zoomOn && (centre || zoomed) &&
                                    now - taps.lastTime < 300 &&
                                    hypot(start.x - taps.lastX, start.y - taps.lastY) < 90f
                                if (isDouble) {
                                    taps.pending?.cancel()
                                    taps.lastTime = 0L
                                    if (zoomed) animateZoom(1f, start.x, start.y, w, h)
                                    else animateZoom(2.5f, start.x, start.y, w, h)
                                } else {
                                    taps.lastTime = now
                                    taps.lastX = start.x
                                    taps.lastY = start.y
                                    taps.pending?.cancel()
                                    if (zoomed) {
                                        taps.pending = scope.launch { delay(280); onTap() }
                                    } else if (x > w * 0.7f && curPage < curCount - 1) {
                                        st.begin(1, w, h, true)
                                        st.animateTo(scope, st.finishX(true), h * 0.92f, 480) {
                                            onChange(curPage + 1)
                                            st.mode = 0
                                        }
                                    } else if (x < w * 0.3f && curPage > 0) {
                                        st.begin(-1, w, h, true)
                                        st.animateTo(scope, st.finishX(false), h, 480) {
                                            onChange(curPage - 1)
                                            st.mode = 0
                                        }
                                    } else if (x > w * 0.7f || x < w * 0.3f) {
                                        // first / last page: nothing to turn, just show the controls
                                        onTap()
                                    } else {
                                        val d = if (zoomOn) 280L else 0L
                                        taps.pending = scope.launch { delay(d); onTap() }
                                    }
                                }
                            }
                            break
                        }

                        // ---- two fingers: pinch to zoom ----
                        if (pressed.size >= 2 && zoomOn && mode != 1) {
                            val a = pressed[0].position
                            val b = pressed[1].position
                            val cen = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                            val span = hypot(a.x - b.x, a.y - b.y)
                            if (mode != 3) {
                                mode = 3
                                lastSpan = span
                                lastCen = cen
                                taps.pending?.cancel()
                            } else if (lastSpan > 1f) {
                                val oldZ = zs.z
                                val newZ = (oldZ * span / lastSpan).coerceIn(1f, MAX_ZOOM)
                                zs.tx = cen.x - (lastCen.x - zs.tx) * newZ / oldZ
                                zs.ty = cen.y - (lastCen.y - zs.ty) * newZ / oldZ
                                zs.z = newZ
                                zs.clamp(w, h)
                                lastSpan = span
                                lastCen = cen
                            }
                            pressed.forEach { it.consume() }
                            continue
                        }

                        // ---- one finger ----
                        val ch = pressed.firstOrNull { it.id == down.id } ?: pressed[0]
                        val pos = ch.position
                        if (mode == 3) {
                            // a finger was lifted after pinching: continue as pan if zoomed
                            mode = if (zs.z > 1.01f) 2 else 4
                            lastPos = pos
                            ch.consume()
                            continue
                        }
                        tracker.addPosition(ch.uptimeMillis, pos)
                        val dx = pos.x - start.x
                        val dy = pos.y - start.y
                        maxMove = max(maxMove, hypot(dx, dy))

                        if (mode == 0 && maxMove > slop) {
                            if (zs.z > 1.01f) {
                                mode = 2
                                lastPos = pos
                                taps.pending?.cancel()
                            } else if (abs(dx) > slop && abs(dx) > abs(dy) * 0.6f) {
                                val m = if (dx < 0) 1 else -1
                                val ok = (m == 1 && curPage < curCount - 1) || (m == -1 && curPage > 0)
                                if (ok) {
                                    mode = 1
                                    dir = m
                                    taps.pending?.cancel()
                                    st.begin(m, w, h, start.y > h / 2f)
                                } else {
                                    mode = 4
                                }
                            } else if (abs(dy) > slop) {
                                mode = 4
                            }
                        }
                        if (mode == 1) {
                            progress = if (dir == 1) (-dx) / (DRAG_SPAN * w) else dx / (DRAG_SPAN * w)
                            progress = progress.coerceIn(0f, 1f)
                            st.drag(progress, dy)
                            ch.consume()
                        } else if (mode == 2) {
                            zs.tx += pos.x - lastPos.x
                            zs.ty += pos.y - lastPos.y
                            zs.clamp(w, h)
                            lastPos = pos
                            ch.consume()
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            @Suppress("UNUSED_VARIABLE")
            val version = cacheVersion
            drawIntoCanvas { cv ->
                val c = cv.nativeCanvas
                when (st.mode) {
                    1 -> if (curl) {
                        drawCurl(c, w, h, bitmapFor(page), bitmapFor(page + 1), st.tx, st.ty, st.cy, paints)
                    } else {
                        drawSlide(c, w, h, bitmapFor(page), bitmapFor(page + 1), st.tx, true, paints)
                    }
                    -1 -> if (curl) {
                        drawCurl(c, w, h, bitmapFor(page - 1), bitmapFor(page), st.tx, st.ty, st.cy, paints)
                    } else {
                        drawSlide(c, w, h, bitmapFor(page - 1), bitmapFor(page), st.tx, false, paints)
                    }
                    else -> if (zs.z > 1.001f) {
                        drawZoomed(c, w, h, bitmapFor(page), region, page, zs.z, zs.tx, zs.ty, paints)
                    } else {
                        drawFlat(c, bitmapFor(page), w, h, paints)
                    }
                }
            }
        }
    }
}
