package com.reader.app.ui

import androidx.compose.animation.core.FloatExponentialDecaySpec
import androidx.compose.animation.core.animateDecay
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Viewport over a big canvas: (ux, uy) = top-left in content units, z = zoom. */
internal interface PanZoomTarget {
    var z: Float
    var ux: Float
    var uy: Float
    var fling: Job?
    fun clamp()
}

/** One-finger pan with fling, two-finger pinch zoom about the fingers. */
internal fun Modifier.panZoom(
    key: Any?,
    t: PanZoomTarget,
    scope: CoroutineScope,
    minZ: Float,
    maxZ: Float
): Modifier = this.pointerInput(key) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        t.fling?.cancel()
        val tracker = VelocityTracker()
        val slop = viewConfiguration.touchSlop
        var zoomAcc = 1f
        var panAcc = Offset.Zero
        var past = false
        var multi = false
        do {
            val ev = awaitPointerEvent()
            if (ev.changes.size > 1) multi = true
            val zc = ev.calculateZoom()
            val pc = ev.calculatePan()
            val cen = ev.calculateCentroid(useCurrent = false)
            if (!past) {
                zoomAcc *= zc
                panAcc += pc
                val zoomMotion = abs(1f - zoomAcc) * ev.calculateCentroidSize(useCurrent = false)
                if (zoomMotion > slop || panAcc.getDistance() > slop) past = true
            }
            if (past) {
                if (zc != 1f || pc != Offset.Zero) {
                    val oldZ = t.z
                    val newZ = (oldZ * zc).coerceIn(minZ, maxZ)
                    if (cen != Offset.Unspecified) {
                        val px = t.ux + cen.x / oldZ
                        val py = t.uy + cen.y / oldZ
                        t.ux = px - cen.x / newZ
                        t.uy = py - cen.y / newZ
                    }
                    t.z = newZ
                    t.ux -= pc.x / newZ
                    t.uy -= pc.y / newZ
                    t.clamp()
                }
                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                val first = ev.changes.firstOrNull { it.pressed }
                if (first != null) tracker.addPosition(first.uptimeMillis, first.position)
            }
        } while (ev.changes.any { it.pressed })

        if (past && !multi) {
            val v = tracker.calculateVelocity()
            t.fling = scope.launch {
                launch {
                    var last = 0f
                    animateDecay(0f, -v.x, FloatExponentialDecaySpec()) { value, _ ->
                        val d = value - last
                        last = value
                        t.ux += d / t.z
                        t.clamp()
                    }
                }
                launch {
                    var last = 0f
                    animateDecay(0f, -v.y, FloatExponentialDecaySpec()) { value, _ ->
                        val d = value - last
                        last = value
                        t.uy += d / t.z
                        t.clamp()
                    }
                }
            }
        }
    }
}
