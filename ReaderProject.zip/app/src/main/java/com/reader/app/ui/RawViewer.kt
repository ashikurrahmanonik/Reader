package com.reader.app.ui

import android.graphics.BitmapFactory
import android.text.format.Formatter
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.data.ReaderTarget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

private const val RAW_LIMIT = 4 * 1024 * 1024 // first 4 MB are shown, bigger files are cut

private class RawData(val bytes: ByteArray, val total: Long, val looksText: Boolean)

private val IMG_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")

private fun looksLikeText(b: ByteArray): Boolean {
    if (b.isEmpty()) return true
    val n = minOf(b.size, 8192)
    var bad = 0
    for (i in 0 until n) {
        val v = b[i].toInt() and 0xFF
        if (v == 0) return false
        if (v < 9 || (v in 14..31)) bad++
    }
    return bad * 50 < n // fewer than 2 % control bytes
}

/** Opens ANY file: text files as text, everything else as a hex dump, pictures as pictures. */
@Composable
fun RawReader(vm: AppViewModel, target: ReaderTarget) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val file = File(target.path)
    val ext = file.extension.lowercase()
    val dark = vm.readerTheme == 2
    val fg = if (dark) Color(0xFFDDDDE6) else Color(0xFF1A1A22)
    val dim = if (dark) Color(0xFF8A8A99) else Color(0xFF777788)

    val data by produceState<RawData?>(null, target.path) {
        value = withContext(Dispatchers.IO) {
            try {
                RandomAccessFile(file, "r").use { r ->
                    val total = r.length()
                    val buf = ByteArray(minOf(total, RAW_LIMIT.toLong()).toInt())
                    r.readFully(buf)
                    RawData(buf, total, looksLikeText(buf))
                }
            } catch (_: Throwable) {
                RawData(ByteArray(0), 0, true)
            }
        }
    }
    val d = data
    var hex by remember(target.path) { mutableStateOf(false) }
    val isImage = ext in IMG_EXT

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MiniIcon(Icons.Rounded.Close, t.close, fg) { vm.closeReader() }
            Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                Text(file.name, color = fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    Formatter.formatFileSize(ctx, d?.total ?: file.length()) +
                        (if (d != null && d.total > RAW_LIMIT) "  •  4 MB" else ""),
                    color = dim, fontSize = 11.sp
                )
            }
            if (d != null && !isImage && d.looksText) {
                MiniIcon(Icons.Rounded.Code, "Hex", if (hex) RC.OrangeLight else fg) { hex = !hex }
            }
            MiniIcon(Icons.Rounded.Palette, t.theme, RC.OrangeLight) { vm.cycleReaderTheme() }
            MiniIcon(Icons.Rounded.OpenInNew, t.openWith, fg) { openExternally(ctx, target.path, t.noAppToOpen) }
            MiniIcon(Icons.Rounded.Share, t.share, fg) { shareBook(ctx, target.path) }
        }

        when {
            d == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = RC.OrangeLight)
            }
            isImage -> ImageView(file)
            d.looksText && !hex -> TextView(d.bytes, fg, dim)
            else -> HexView(d.bytes, fg, dim)
        }
    }
}

@Composable
private fun TextView(bytes: ByteArray, fg: Color, dim: Color) {
    val lines by produceState<List<String>?>(null, bytes) {
        value = withContext(Dispatchers.Default) {
            var text = String(bytes, Charsets.UTF_8)
            if (text.startsWith("\uFEFF")) text = text.substring(1)
            text.split('\n').map { it.trimEnd('\r') }
        }
    }
    val l = lines
    if (l == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = RC.OrangeLight) }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
    ) {
        items(l.size) { i ->
            Row {
                Text(
                    (i + 1).toString().padStart(4),
                    color = dim, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.width(40.dp)
                )
                // normal text font (not monospace) so Bangla and other scripts shape correctly
                Text(l[i].ifEmpty { " " }, color = fg, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun HexView(bytes: ByteArray, fg: Color, dim: Color) {
    val rows = (bytes.size + 15) / 16
    val scroll = rememberScrollState()
    LazyColumn(
        modifier = Modifier.fillMaxSize().horizontalScroll(scroll),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        items(rows) { r ->
            val off = r * 16
            val end = minOf(off + 16, bytes.size)
            val hexPart = StringBuilder()
            val asc = StringBuilder()
            for (i in off until off + 16) {
                if (i < end) {
                    val v = bytes[i].toInt() and 0xFF
                    hexPart.append("%02X ".format(v))
                    asc.append(if (v in 32..126) v.toChar() else '.')
                } else hexPart.append("   ")
            }
            Row {
                Text("%08X  ".format(off), color = dim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text(hexPart.toString(), color = fg, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text(" $asc", color = RC.OrangeLight, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun ImageView(file: File) {
    val bmp by produceState<android.graphics.Bitmap?>(null, file.path) {
        value = withContext(Dispatchers.IO) {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, o)
                var sample = 1
                while (o.outWidth / sample > 2400 || o.outHeight / sample > 2400) sample *= 2
                BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
            } catch (_: Throwable) {
                null
            }
        }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var ox by remember { mutableFloatStateOf(0f) }
    var oy by remember { mutableFloatStateOf(0f) }
    val b = bmp
    if (b == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = RC.OrangeLight) }
        return
    }
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 8f)
                    if (scale == 1f) { ox = 0f; oy = 0f } else { ox += pan.x; oy += pan.y }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            bitmap = b.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = ox, translationY = oy)
        )
    }
}
