@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.util.LruCache
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.reader.app.AppViewModel
import com.reader.app.data.ReaderTarget
import com.reader.app.pdf.PdfDoc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun sharePdf(ctx: Context, path: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(path))
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Throwable) {
    }
}

/** Renders pages off the main thread and keeps a few around. */
private class PageCache(
    private val doc: PdfDoc,
    private val scope: CoroutineScope,
    val w: Int,
    val h: Int
) {
    private val lru = object : LruCache<Int, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val pending = HashSet<Int>()
    var version by mutableIntStateOf(0)

    fun get(i: Int): Bitmap? = if (i in 0 until doc.pageCount) lru.get(i) else null

    fun request(i: Int) {
        if (i < 0 || i >= doc.pageCount) return
        if (lru.get(i) != null) return
        if (!pending.add(i)) return
        scope.launch(Dispatchers.Default) {
            val b = try {
                doc.renderPage(i, w, h)
            } catch (e: Throwable) {
                null
            }
            withContext(Dispatchers.Main) {
                pending.remove(i)
                if (b != null) {
                    lru.put(i, b)
                    version++
                }
            }
        }
    }
}

@Composable
fun ReaderScreen(vm: AppViewModel, target: ReaderTarget) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var doc by remember(target.path) { mutableStateOf<PdfDoc?>(null) }
    var error by remember(target.path) { mutableStateOf<String?>(null) }

    LaunchedEffect(target.path) {
        val res = withContext(Dispatchers.IO) { PdfDoc.open(target.path) }
        doc = res.doc
        error = res.error
    }
    DisposableEffect(target.path) {
        onDispose { doc?.close() }
    }

    BackHandler { vm.closeReader() }

    // Immersive full-screen reading + keep the screen on
    DisposableEffect(Unit) {
        val window = ctx.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        if (window != null) {
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    val theme = vm.readerTheme
    val pageBg = when (theme) {
        1 -> Color(0xFFF5E6B8)
        2 -> Color(0xFF070709)
        else -> Color.White
    }

    val visibleState = remember { MutableTransitionState(false).apply { targetState = true } }

    AnimatedVisibility(
        visibleState = visibleState,
        enter = fadeIn() + scaleIn(initialScale = 0.94f)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(pageBg)
        ) {
            val d = doc
            if (d == null) {
                if (error != null) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(error ?: "", color = Color.Gray, fontSize = 16.sp)
                        Spacer(Modifier.size(16.dp))
                        GradientButton("Back", null, { vm.closeReader() })
                    }
                } else {
                    CircularProgressIndicator(Modifier.align(Alignment.Center), color = RC.Blue)
                }
            } else {
                ReaderContent(vm, target, d, theme, pageBg)
            }
        }
    }
}

@Composable
private fun ReaderContent(
    vm: AppViewModel,
    target: ReaderTarget,
    doc: PdfDoc,
    theme: Int,
    pageBg: Color
) {
    val ctx = LocalContext.current
    val count = doc.pageCount
    var page by rememberSaveable(target.path) {
        mutableIntStateOf(target.startPage.coerceIn(0, count - 1))
    }
    var showUi by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(page) {
        vm.recordProgress(target.path, target.name, page, count)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth
        val hPx = constraints.maxHeight
        val cache = remember(doc, wPx, hPx) { PageCache(doc, scope, wPx, hPx) }

        LaunchedEffect(cache, page) {
            cache.request(page)
            cache.request(page + 1)
            cache.request(page - 1)
            cache.request(page + 2)
            cache.request(page - 2)
        }

        PageCurlPager(
            pageCount = count,
            page = page,
            onPageChange = { page = it.coerceIn(0, count - 1) },
            bitmapFor = { cache.get(it) },
            cacheVersion = cache.version,
            theme = theme,
            onCenterTap = { showUi = !showUi }
        )

        // tiny page indicator while controls are hidden
        if (!showUi) {
            Text(
                "${page + 1} / $count",
                color = if (theme == 2) Color(0x88FFFFFF) else Color(0x88000000),
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(bottom = 6.dp)
            )
        }

        // top bar
        AnimatedVisibility(
            visible = showUi,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            val fav = target.path in vm.favorites
            Row(
                Modifier
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(26.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.82f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MiniIcon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", Color.White) { vm.closeReader() }
                Spacer(Modifier.width(6.dp))
                Text(
                    target.name.replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), ""),
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                MiniIcon(
                    if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    "Favorite",
                    if (fav) RC.OrangeLight else Color.White
                ) { vm.toggleFavorite(target.path) }
                MiniIcon(Icons.Rounded.Share, "Share", Color.White) { sharePdf(ctx, target.path) }
            }
        }

        // bottom bar
        AnimatedVisibility(
            visible = showUi,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it }
        ) {
            var slider by remember { mutableFloatStateOf(page.toFloat()) }
            var sliding by remember { mutableStateOf(false) }
            LaunchedEffect(page) { if (!sliding) slider = page.toFloat() }
            val shown = if (sliding) slider.toInt() else page

            Column(
                Modifier
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(26.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.82f))
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Page ${shown + 1} of $count",
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    val label = when (theme) {
                        1 -> "Sepia"
                        2 -> "Night"
                        else -> "Day"
                    }
                    Text(label, color = RC.Muted, fontSize = 12.sp)
                    MiniIcon(Icons.Rounded.Palette, "Reading theme", RC.OrangeLight) { vm.cycleReaderTheme() }
                }
                if (count > 1) {
                    Slider(
                        value = slider,
                        onValueChange = {
                            sliding = true
                            slider = it
                        },
                        onValueChangeFinished = {
                            page = slider.toInt().coerceIn(0, count - 1)
                            sliding = false
                        },
                        valueRange = 0f..(count - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = RC.OrangeLight,
                            activeTrackColor = RC.BlueLight,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        }
    }
}
