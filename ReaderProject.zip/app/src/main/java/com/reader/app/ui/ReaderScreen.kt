@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.util.LruCache
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.reader.app.AppViewModel
import com.reader.app.data.ReaderTarget
import com.reader.app.data.Kind
import com.reader.app.data.BOOK_EXT_REGEX
import com.reader.app.data.kindOf
import com.reader.app.epub.EpubDoc
import com.reader.app.office.FixedDoc
import com.reader.app.office.OfficeOpen
import com.reader.app.office.SlideDoc
import com.reader.app.office.SlidesBuilder
import com.reader.app.office.WordDoc
import com.reader.app.office.WordOpen
import com.reader.app.office.OpenedReflow
import com.reader.app.office.OpenedSheets
import android.text.SpannableStringBuilder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Add
import com.reader.app.pdf.BookDoc
import com.reader.app.pdf.PdfDoc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun shareBook(ctx: Context, path: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(path))
        val i = Intent(Intent.ACTION_SEND).apply {
            type = when (kindOf(path)) {
                Kind.PDF -> "application/pdf"
                Kind.EPUB -> "application/epub+zip"
                Kind.DOCX -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                Kind.XLSX -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Kind.PPTX -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                Kind.CSV -> "text/csv"
                Kind.TXT -> "text/plain"
            }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Throwable) {
    }
}

/** Renders pages off the main thread and keeps a few around. */
private class PageCache(
    private val doc: BookDoc,
    private val scope: CoroutineScope,
    val w: Int,
    val h: Int
) {
    private val lru = object : LruCache<Int, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }
    private val pending = HashSet<Int>()
    var version by mutableIntStateOf(0)

    fun get(i: Int): Bitmap? = if (i in 0 until doc.pageCount) lru.get(i) else null

    fun request(i: Int) {
        if (i < 0 || i >= doc.pageCount) return
        if (lru.get(i) != null) return
        if (!pending.add(i)) return
        scope.launch(Dispatchers.Default) {
            val b = try {
                doc.renderPage(i, w, h)
            } catch (e: Throwable) {
                null
            }
            withContext(Dispatchers.Main) {
                pending.remove(i)
                if (b != null) {
                    lru.put(i, b)
                    version++
                }
            }
        }
    }
}

@Composable
fun ReaderScreen(vm: AppViewModel, target: ReaderTarget) {
    val ctx = LocalContext.current

    BackHandler { vm.closeReader() }

    // Immersive full-screen reading + keep the screen on
    DisposableEffect(Unit) {
        val window = ctx.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        if (window != null) {
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            if (window != null) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                val lp = window.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = lp
            }
        }
    }

    // reader brightness (-1 = system)
    DisposableEffect(vm.brightness) {
        val window = ctx.findActivity()?.window
        if (window != null) {
            val lp = window.attributes
            lp.screenBrightness =
                if (vm.brightness < 0f) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                else vm.brightness.coerceIn(0.02f, 1f)
            window.attributes = lp
        }
        onDispose { }
    }

    val pageBg = when (vm.readerTheme) {
        1 -> Color(0xFFF5E6B8)
        2 -> Color(0xFF070709)
        else -> Color.White
    }
    val visibleState = remember { MutableTransitionState(false).apply { targetState = true } }

    AnimatedVisibility(
        visibleState = visibleState,
        enter = fadeIn() + scaleIn(initialScale = 0.94f)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(pageBg)
        ) {
            if (!com.reader.app.data.BOOK_EXT_REGEX.containsMatchIn(target.path)) {
                // .bin, .json, .log, images ... any other file: text / hex / picture viewer
                RawReader(vm, target)
            } else when (kindOf(target.path)) {
                Kind.PDF -> PdfReader(vm, target)
                Kind.XLSX, Kind.CSV -> SheetReader(vm, target)
                Kind.DOCX, Kind.PPTX -> FixedReader(vm, target)
                else -> ReflowReader(vm, target)
            }
        }
    }
}

@Composable
private fun ErrorView(message: String, detail: String? = null, onBack: () -> Unit) {
    val t = LocalStr.current
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(message, color = Color.Gray, fontSize = 16.sp, textAlign = TextAlign.Center)
        if (!detail.isNullOrBlank()) {
            Spacer(Modifier.size(8.dp))
            Text(detail, color = Color(0xFF9AA3B5), fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.size(16.dp))
        GradientButton(t.back, null, onBack)
    }
}

@Composable
private fun LoadingView(label: String?, progress: Float? = null) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            Modifier
                .glass(RoundedCornerShape(24.dp), 0.18f)
                .background(RC.Navy900.copy(alpha = 0.85f))
                .padding(horizontal = 28.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (progress != null) {
                CircularProgressIndicator(progress = { progress }, color = RC.BlueLight, modifier = Modifier.size(36.dp))
            } else {
                CircularProgressIndicator(color = RC.BlueLight, modifier = Modifier.size(36.dp))
            }
            if (label != null) {
                Spacer(Modifier.height(12.dp))
                Text(label, color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ PDF

private sealed interface PdfPhase {
    data object Loading : PdfPhase
    data class NeedPassword(val wrong: Boolean) : PdfPhase
    data class Ready(val doc: PdfDoc) : PdfPhase
    data class Failed(val code: String) : PdfPhase
}

@Composable
private fun PdfReader(vm: AppViewModel, target: ReaderTarget) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val scope = rememberCoroutineScope()
    var phase by remember(target.path) { mutableStateOf<PdfPhase>(PdfPhase.Loading) }
    var unlocking by remember(target.path) { mutableStateOf(false) }

    LaunchedEffect(target.path) {
        val r = withContext(Dispatchers.IO) { PdfDoc.open(target.path) }
        phase = when {
            r.doc != null -> PdfPhase.Ready(r.doc)
            r.needsPassword -> PdfPhase.NeedPassword(false)
            else -> PdfPhase.Failed(r.error ?: "open")
        }
    }
    DisposableEffect(target.path) {
        onDispose {
            val p = phase
            if (p is PdfPhase.Ready) p.doc.close()
        }
    }

    when (val p = phase) {
        is PdfPhase.Loading -> LoadingView(null)
        is PdfPhase.Failed -> ErrorView(if (p.code == "empty") t.errEmpty else t.errOpen) { vm.closeReader() }
        is PdfPhase.NeedPassword -> {
            PasswordDialog(
                wrong = p.wrong,
                busy = unlocking,
                onSubmit = { pw ->
                    unlocking = true
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { PdfDoc.openWithPassword(ctx, target.path, pw) }
                        unlocking = false
                        phase = when {
                            r.doc != null -> PdfPhase.Ready(r.doc)
                            r.wrongPassword -> PdfPhase.NeedPassword(true)
                            else -> PdfPhase.Failed(r.error ?: "open")
                        }
                    }
                },
                onCancel = { vm.closeReader() }
            )
        }
        is PdfPhase.Ready -> {
            androidx.compose.runtime.key(p.doc) {
                ReaderContent(vm, target, p.doc, target.startPage, {})
            }
        }
    }
}

@Composable
private fun PasswordDialog(wrong: Boolean, busy: Boolean, onSubmit: (String) -> Unit, onCancel: () -> Unit) {
    val t = LocalStr.current
    var pw by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = RC.Navy800,
        shape = RoundedCornerShape(28.dp),
        icon = { Icon(Icons.Rounded.Lock, null, tint = RC.OrangeLight) },
        title = { Text(t.pwTitle, fontWeight = FontWeight.Bold, color = Color.White) },
        text = {
            Column {
                Text(t.pwBody, color = RC.Muted, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = pw,
                    onValueChange = { pw = it },
                    singleLine = true,
                    label = { Text(t.pwHint) },
                    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        Icon(
                            if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            if (visible) t.hide else t.show,
                            tint = RC.Muted,
                            modifier = Modifier.clickable { visible = !visible }
                        )
                    },
                    isError = wrong,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = RC.BlueLight,
                        unfocusedBorderColor = RC.Muted,
                        focusedLabelColor = RC.BlueLight,
                        unfocusedLabelColor = RC.Muted,
                        cursorColor = RC.BlueLight
                    )
                )
                if (wrong) {
                    Spacer(Modifier.height(8.dp))
                    Text(t.pwWrong, color = RC.Danger, fontSize = 13.sp)
                }
                if (busy) {
                    Spacer(Modifier.height(10.dp))
                    Text(t.unlocking, color = RC.Muted, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (!busy && pw.isNotEmpty()) onSubmit(pw) }) {
                Text(t.openAction, color = RC.BlueLight, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text(t.cancel, color = RC.Muted) }
        }
    )
}

// ------------------------------------------------------------------ EPUB / DOCX / PPTX / TXT

@Composable
private fun ReflowReader(vm: AppViewModel, target: ReaderTarget) {
    val t = LocalStr.current
    var opened by remember(target.path) { mutableStateOf<OpenedReflow?>(null) }
    var failure by remember(target.path) { mutableStateOf<String?>(null) }

    LaunchedEffect(target.path) {
        try {
            val o = withContext(Dispatchers.IO) { OfficeOpen.open(target.path) }
            if (o is OpenedReflow) opened = o else failure = "unsupported"
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            failure = "${e.javaClass.simpleName}: ${e.message ?: ""}".take(160)
        }
    }
    DisposableEffect(target.path) {
        onDispose { opened?.book?.close() }
    }

    val o = opened
    val fail = failure
    if (fail != null) {
        ErrorView(t.errOpen, fail) { vm.closeReader() }
        return
    }
    if (o == null) {
        LoadingView(null)
        return
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val density = LocalDensity.current.density
        var doc by remember(o) { mutableStateOf<EpubDoc?>(null) }
        var building by remember(o) { mutableStateOf(true) }
        var buildFailure by remember(o) { mutableStateOf<String?>(null) }
        var loc by remember(o) { mutableLongStateOf(target.extra) }
        var progress by remember(o) { mutableFloatStateOf(0f) }
        val fontSize = vm.fontSize
        val serif = vm.serif
        val fontsVersion = vm.fontsVersion
        val kind = kindOf(target.path)
        val continuous = kind == Kind.DOCX || kind == Kind.PPTX || kind == Kind.TXT

        LaunchedEffect(o, w, h, fontSize, serif, fontsVersion) {
            // a short pause so quick size / setting changes don't start several heavy layouts
            kotlinx.coroutines.delay(120)
            building = true
            try {
                val model = o.model
                val supplier = model?.let { m ->
                    { i: Int, paint: android.text.TextPaint, cw: Int, ch: Int, missing: MutableSet<String> ->
                        m.buildSpans(i, paint, density, cw, ch, o.book, missing)
                    }
                }
                // heavy text layout: never on the main thread
                val built = withContext(Dispatchers.Default) {
                    EpubDoc.build(o.book, w, h, density, fontSize, serif, { progress = it }, supplier, continuous)
                }
                doc = built
                buildFailure = null
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                buildFailure = if (e is IllegalStateException) "empty" else "${e.javaClass.simpleName}: ${e.message ?: ""}".take(160)
            }
            building = false
        }

        val d = doc
        val bf = buildFailure
        if (bf != null && d == null) {
            ErrorView(if (bf == "empty") t.errEmpty else t.errOpen, if (bf == "empty") null else bf) { vm.closeReader() }
        } else if (d != null) {
            androidx.compose.runtime.key(d) {
                ReaderContent(vm, target, d, d.pageForLocator(loc), { loc = it }, continuous)
            }
        }
        if (building) LoadingView(t.preparing, progress)
    }
}

// ------------------------------------------------------------------ DOCX / PPTX (true page layout)

@Composable
private fun FixedReader(vm: AppViewModel, target: ReaderTarget) {
    val t = LocalStr.current
    val isSlides = kindOf(target.path) == Kind.PPTX
    var failed by remember(target.path) { mutableStateOf(false) }
    if (failed) {
        // could not lay the file out with the page engine: fall back to the simple text view
        ReflowReader(vm, target)
        return
    }
    var doc by remember(target.path) { mutableStateOf<FixedDoc?>(null) }
    var building by remember(target.path) { mutableStateOf(true) }
    var progress by remember(target.path) { mutableFloatStateOf(0f) }
    var model by remember(target.path) { mutableStateOf<Any?>(null) }

    DisposableEffect(target.path) {
        onDispose {
            val d = doc
            if (d is WordDoc) d.close()
            if (d is SlideDoc) d.close()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val fontsVersion = vm.fontsVersion
        LaunchedEffect(target.path, w, fontsVersion) {
            kotlinx.coroutines.delay(100)
            building = true
            try {
                val built: FixedDoc = withContext(Dispatchers.Default) {
                    if (isSlides) {
                        SlidesBuilder.build(target.path, w) { progress = it }
                    } else {
                        val m = model ?: WordOpen.parse(target.path).also { model = it }
                        WordOpen.build(m, w) { progress = it }
                    }
                }
                val old = doc
                doc = built
                if (old is SlideDoc) old.close()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                if (doc == null) failed = true
            }
            building = false
        }
        val d = doc
        if (d != null) {
            androidx.compose.runtime.key(d) { FixedViewer(vm, target, d, isSlides) }
        }
        if (building) LoadingView(t.preparing, progress)
    }
}

// ------------------------------------------------------------------ XLSX / CSV

@Composable
private fun SheetReader(vm: AppViewModel, target: ReaderTarget) {
    val t = LocalStr.current
    var opened by remember(target.path) { mutableStateOf<OpenedSheets?>(null) }
    var failure by remember(target.path) { mutableStateOf<String?>(null) }

    LaunchedEffect(target.path) {
        try {
            val o = withContext(Dispatchers.IO) { OfficeOpen.open(target.path) }
            if (o is OpenedSheets) opened = o else failure = "unsupported"
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            failure = "${e.javaClass.simpleName}: ${e.message ?: ""}".take(160)
        }
    }

    val o = opened
    val fail = failure
    if (fail != null) {
        ErrorView(t.errOpen, fail) { vm.closeReader() }
        return
    }
    if (o == null) {
        LoadingView(null)
        return
    }

    SheetViewer(vm, target, o.sheets)
}

// ------------------------------------------------------------------ shared reader UI

@Composable
private fun ReaderContent(
    vm: AppViewModel,
    target: ReaderTarget,
    doc: BookDoc,
    startPage: Int,
    onLocator: (Long) -> Unit,
    scrollMode: Boolean = false
) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val count = doc.pageCount
    val theme = vm.readerTheme
    val adjustable = kindOf(target.path) != Kind.PDF
    val reflow = kindOf(target.path) !in listOf(Kind.PDF, Kind.XLSX, Kind.CSV)
    val curlAllowed = kindOf(target.path) == Kind.PDF || kindOf(target.path) == Kind.EPUB
    var missingDismissed by remember(doc) { mutableStateOf(false) }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importFonts(uris)
    }
    var page by remember(doc) { mutableIntStateOf(startPage.coerceIn(0, count - 1)) }
    var showUi by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) } // 0 none, 1 display, 2 contents
    var jumpToken by remember { mutableIntStateOf(0) }
    var jumpPage by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val toc = remember(doc) { doc.toc() }

    BackHandler(enabled = panel != 0) { panel = 0 }

    fun goTo(p: Int) {
        page = p.coerceIn(0, count - 1)
        if (scrollMode) {
            jumpPage = page
            jumpToken++
        }
    }

    LaunchedEffect(page) {
        val l = doc.locatorOf(page)
        onLocator(l)
        vm.recordProgress(target.path, target.name, page, count, l)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth
        val hPx = constraints.maxHeight
        val cache = remember(doc, wPx, hPx) { PageCache(doc, scope, wPx, hPx) }
        var region by remember(doc) { mutableStateOf<ZoomRegion?>(null) }
        var regionJob by remember(doc) { mutableStateOf<Job?>(null) }

        LaunchedEffect(cache, page) {
            cache.request(page)
            cache.request(page + 1)
            cache.request(page - 1)
            cache.request(page + 2)
            cache.request(page - 2)
        }

        if (scrollMode) {
            ScrollPages(
                pageCount = count,
                page = page,
                jumpToken = jumpToken,
                jumpPage = jumpPage,
                aspect = wPx.toFloat() / hPx.toFloat(),
                bitmapFor = { cache.get(it) },
                request = { cache.request(it) },
                cacheVersion = cache.version,
                theme = theme,
                onPageChange = { page = it.coerceIn(0, count - 1) },
                onTap = {
                    if (panel != 0) panel = 0
                    else showUi = !showUi
                }
            )
        } else {
            PageCurlPager(
                pageCount = count,
                page = page,
                onPageChange = { page = it.coerceIn(0, count - 1) },
                bitmapFor = { cache.get(it) },
                cacheVersion = cache.version,
                theme = theme,
                curl = vm.curl && curlAllowed,
                zoomEnabled = doc.supportsZoom,
                region = region,
                onZoomSettled = { p, z, tx, ty ->
                    regionJob?.cancel()
                    regionJob = scope.launch(Dispatchers.Default) {
                        val bmp = try {
                            doc.renderRegion(p, wPx, hPx, z, tx, ty)
                        } catch (e: Throwable) {
                            null
                        }
                        if (bmp != null) {
                            withContext(Dispatchers.Main) { region = ZoomRegion(p, z, tx, ty, bmp) }
                        }
                    }
                },
                onCenterTap = {
                    if (panel != 0) panel = 0
                    else showUi = !showUi
                }
            )
        }

        // tiny page indicator while the controls are hidden
        if (!showUi) {
            Text(
                "${t.n(page + 1)} / ${t.n(count)}",
                color = if (theme == 2) Color(0x88FFFFFF) else Color(0x88000000),
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(bottom = 6.dp)
            )
        }

        // ---------------- missing legacy font banner ----------------
        val missingNames = doc.missingFonts
        if (missingNames.isNotEmpty() && !missingDismissed) {
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(start = 12.dp, end = 12.dp, top = if (showUi) 76.dp else 12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(20.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.92f))
                    .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    t.missingFonts(missingNames.joinToString(", ")),
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                TextButton(onClick = { fontPicker.launch(arrayOf("*/*")) }) {
                    Text(t.goFonts, color = RC.OrangeLight, fontWeight = FontWeight.Bold)
                }
                MiniIcon(Icons.Rounded.Close, t.dismiss, RC.Muted) { missingDismissed = true }
            }
        }

        // ---------------- top bar ----------------
        AnimatedVisibility(
            visible = showUi,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            val fav = target.path in vm.favorites
            Row(
                Modifier
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(26.dp), 0.18f)
                    .background(RC.Navy900.copy(alpha = 0.84f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MiniIcon(Icons.AutoMirrored.Rounded.ArrowBack, t.back, Color.White) { vm.closeReader() }
                Spacer(Modifier.width(6.dp))
                Text(
                    target.name.replace(BOOK_EXT_REGEX, ""),
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                MiniIcon(
                    if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    t.favorite,
                    if (fav) RC.OrangeLight else Color.White
                ) { vm.toggleFavorite(target.path) }
                MiniIcon(Icons.Rounded.Share, t.share, Color.White) { shareBook(ctx, target.path) }
            }
        }

        // ---------------- bottom area ----------------
        AnimatedVisibility(
            visible = showUi,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it }
        ) {
            var slider by remember { mutableFloatStateOf(page.toFloat()) }
            var sliding by remember { mutableStateOf(false) }
            LaunchedEffect(page) { if (!sliding) slider = page.toFloat() }
            val shown = if (sliding) slider.toInt() else page
            val pct = if (count > 1) (shown * 100 / (count - 1)) else 100

            Column(
                Modifier
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .displayCutoutPadding()
                    .padding(12.dp)
            ) {
                AnimatedVisibility(visible = panel == 1) {
                    DisplayPanel(vm, adjustable, reflow, doc.supportsZoom && !scrollMode, curlAllowed)
                }
                AnimatedVisibility(visible = panel == 2) {
                    ContentsPanel(toc, page) { pg ->
                        goTo(pg)
                        panel = 0
                    }
                }
                if (panel != 0) Spacer(Modifier.height(10.dp))

                Column(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(26.dp), 0.18f)
                        .background(RC.Navy900.copy(alpha = 0.84f))
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            t.pageOf(shown + 1, count),
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                        Text(t.percent(pct), color = RC.Muted, fontSize = 13.sp)
                    }
                    if (count > 1) {
                        Slider(
                            value = slider,
                            onValueChange = {
                                sliding = true
                                slider = it
                            },
                            onValueChangeFinished = {
                                goTo(slider.toInt())
                                sliding = false
                            },
                            valueRange = 0f..(count - 1).toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = RC.OrangeLight,
                                activeTrackColor = RC.BlueLight,
                                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                            )
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        if (toc.isNotEmpty()) {
                            BarAction(Icons.Rounded.FormatListBulleted, t.contents, panel == 2) {
                                panel = if (panel == 2) 0 else 2
                            }
                        }
                        BarAction(Icons.Rounded.TextFields, t.display, panel == 1) {
                            panel = if (panel == 1) 0 else 1
                        }
                        if (curlAllowed) BarAction(Icons.Rounded.AutoStories, t.pageCurl, vm.curl) { vm.changeCurl(!vm.curl) }
                        BarAction(Icons.Rounded.Palette, t.theme, false) { vm.cycleReaderTheme() }
                    }
                }
            }
        }
    }
}

@Composable
private fun BarAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (active) RC.OrangeLight else Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = if (active) RC.OrangeLight else RC.Muted)
    }
}

@Composable
private fun DisplayPanel(vm: AppViewModel, adjustable: Boolean, reflow: Boolean, zoomable: Boolean, curlAllowed: Boolean) {
    val t = LocalStr.current
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(26.dp), 0.18f)
            .background(RC.Navy900.copy(alpha = 0.90f))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // theme
        Column {
            Text(t.theme, color = RC.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip(t.day, vm.readerTheme == 0, { vm.changeReaderTheme(0) })
                GlassChip(t.sepia, vm.readerTheme == 1, { vm.changeReaderTheme(1) })
                GlassChip(t.night, vm.readerTheme == 2, { vm.changeReaderTheme(2) })
            }
        }
        // brightness
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.brightness, color = RC.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(t.auto, color = RC.Muted, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = vm.brightness < 0f,
                    onCheckedChange = { vm.changeBrightness(if (it) -1f else 0.6f) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = RC.Blue,
                        checkedThumbColor = Color.White,
                        uncheckedTrackColor = Color.White.copy(alpha = 0.15f),
                        uncheckedThumbColor = RC.Muted,
                        uncheckedBorderColor = Color.Transparent
                    )
                )
            }
            if (vm.brightness >= 0f) {
                Slider(
                    value = vm.brightness.coerceIn(0.02f, 1f),
                    onValueChange = { vm.changeBrightness(it) },
                    valueRange = 0.02f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = RC.OrangeLight,
                        activeTrackColor = RC.BlueLight,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                    )
                )
            }
        }
        // page turn style (only books and PDFs turn pages)
        if (curlAllowed) {
            Column {
                Text(t.pageTurn, color = RC.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip(t.curl, vm.curl, { vm.changeCurl(true) })
                    GlassChip(t.slide, !vm.curl, { vm.changeCurl(false) })
                }
            }
        }
        if (adjustable) {
            var size by remember { mutableFloatStateOf(vm.fontSize.toFloat()) }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.textSize, color = RC.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("Aa ${t.n(size.toInt())}", color = Color.White, fontSize = 13.sp)
                }
                Slider(
                    value = size,
                    onValueChange = { size = it },
                    onValueChangeFinished = { vm.changeFontSize(size.toInt()) },
                    valueRange = 12f..32f,
                    colors = SliderDefaults.colors(
                        thumbColor = RC.OrangeLight,
                        activeTrackColor = RC.BlueLight,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                    )
                )
            }
            if (reflow) {
                Column {
                    Text(t.font, color = RC.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassChip(t.serif, vm.serif, { vm.changeSerif(true) })
                        GlassChip(t.sans, !vm.serif, { vm.changeSerif(false) })
                    }
                }
            }
        }
        if (zoomable) {
            Text(t.zoomHint, color = RC.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ContentsPanel(
    toc: List<com.reader.app.pdf.TocEntry>,
    currentPage: Int,
    onPick: (Int) -> Unit
) {
    val t = LocalStr.current
    // the entry whose page range contains the current page
    var currentIdx = -1
    for (i in toc.indices) if (toc[i].page <= currentPage) currentIdx = i
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = 340.dp)
            .glass(RoundedCornerShape(26.dp), 0.18f)
            .background(RC.Navy900.copy(alpha = 0.90f))
            .padding(vertical = 8.dp)
    ) {
        if (toc.isEmpty()) {
            Text(t.noContents, color = RC.Muted, modifier = Modifier.padding(18.dp))
        } else {
            LazyColumn {
                itemsIndexed(toc) { i, e ->
                    val sel = i == currentIdx
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(e.page) }
                            .background(if (sel) Color.White.copy(alpha = 0.10f) else Color.Transparent)
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (e.title.isBlank()) t.section(i + 1) else e.title,
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = if (sel) RC.OrangeLight else Color.White,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(t.n(e.page + 1), color = RC.Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
