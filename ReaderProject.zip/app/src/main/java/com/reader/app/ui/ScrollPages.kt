@file:OptIn(ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

/**
 * Continuous vertical reading for Word / PowerPoint / text documents (no page curl):
 * pages are drawn one under another, so scrolling feels like any document viewer.
 */
@Composable
fun ScrollPages(
    pageCount: Int,
    page: Int,
    jumpToken: Int,
    jumpPage: Int,
    aspect: Float,
    bitmapFor: (Int) -> Bitmap?,
    request: (Int) -> Unit,
    cacheVersion: Int,
    theme: Int,
    onPageChange: (Int) -> Unit,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = page.coerceIn(0, pageCount - 1))
    val paint = remember(theme) { themedBitmapPaint(theme) }
    val bg = remember(theme) { Color(themePageColor(theme)) }
    val dst = remember { RectF() }
    val density = LocalDensity.current
    val topPad = with(density) { WindowInsets.statusBarsIgnoringVisibility.getTop(density).toDp() }
    val bottomPad = with(density) { WindowInsets.navigationBarsIgnoringVisibility.getBottom(density).toDp() }

    LaunchedEffect(jumpToken) {
        if (jumpToken > 0) listState.scrollToItem(jumpPage.coerceIn(0, pageCount - 1))
    }
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { i ->
            onPageChange(i)
            for (k in (i - 1)..(i + 3)) request(k)
        }
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(top = topPad + 4.dp, bottom = bottomPad + 24.dp),
        modifier = modifier
            .fillMaxSize()
            .background(bg)
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) }
    ) {
        items(pageCount, key = { it }) { i ->
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspect)
            ) {
                @Suppress("UNUSED_VARIABLE")
                val version = cacheVersion
                val b = bitmapFor(i)
                if (b != null) {
                    drawIntoCanvas { cv ->
                        dst.set(0f, 0f, size.width, size.height)
                        cv.nativeCanvas.drawBitmap(b, null, dst, paint)
                    }
                }
            }
        }
    }
}
