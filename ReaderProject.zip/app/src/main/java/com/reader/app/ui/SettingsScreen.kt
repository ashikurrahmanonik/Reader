@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.BuildConfig
import com.reader.app.UpdateState
import com.reader.app.data.Storage

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp), 0.09f)
            .padding(18.dp)
    ) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RC.OrangeLight, letterSpacing = 1.sp)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    BackHandler { vm.showSettings = false }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", { vm.showSettings = false })
            Spacer(Modifier.width(14.dp))
            Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }

        Section("READING THEME") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val names = listOf("Day", "Sepia", "Night")
                val colors = listOf(Color.White, Color(0xFFF5E6B8), Color(0xFF111114))
                names.forEachIndexed { i, n ->
                    val sel = vm.readerTheme == i
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (sel) Color.White.copy(alpha = 0.14f) else Color.Transparent)
                            .clickable { vm.setReaderTheme(i) }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(colors[i])
                                .border(2.dp, if (sel) RC.BlueLight else Color.White.copy(alpha = 0.3f), CircleShape)
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(n, fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
        }

        Section("FILE ACCESS") {
            val ok = Storage.hasAccess(ctx)
            Text(
                if (ok) "Reader can see all PDFs on your phone." else "Access isn't granted yet, so only files you pick manually can be opened.",
                color = RC.Muted, fontSize = 14.sp
            )
            if (!ok) {
                Spacer(Modifier.height(12.dp))
                GradientButton("Allow access", Icons.Rounded.FolderOpen, {
                    if (Build.VERSION.SDK_INT >= 30) {
                        try {
                            ctx.startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:${ctx.packageName}")
                                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Throwable) {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                })
            }
        }

        Section("UPDATES") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.SystemUpdate, null, tint = RC.BlueLight, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Reader ${BuildConfig.VERSION_NAME}", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("Build ${BuildConfig.VERSION_CODE}", color = RC.Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Check for updates automatically", modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(
                    checked = vm.autoUpdate,
                    onCheckedChange = { vm.setAutoUpdate(it) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = RC.Blue,
                        checkedThumbColor = Color.White,
                        uncheckedTrackColor = Color.White.copy(alpha = 0.15f),
                        uncheckedThumbColor = RC.Muted,
                        uncheckedBorderColor = Color.Transparent
                    )
                )
            }
            Spacer(Modifier.height(12.dp))

            val u = vm.update
            val status = when (u) {
                is UpdateState.Idle -> ""
                is UpdateState.Checking -> "Checking for updates…"
                is UpdateState.UpToDate -> "You're on the latest version."
                is UpdateState.Available -> "Version ${u.info.name} is available."
                is UpdateState.Downloading -> "Downloading… ${(u.progress * 100).toInt()}%"
                is UpdateState.Ready -> "Update downloaded and ready to install."
                is UpdateState.Failed -> u.message
            }
            if (status.isNotEmpty()) {
                Text(status, color = RC.Muted, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
            }
            if (u is UpdateState.Downloading) {
                LinearProgressIndicator(
                    progress = { u.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = RC.BlueLight,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )
                Spacer(Modifier.height(10.dp))
            }
            when (u) {
                is UpdateState.Available ->
                    GradientButton("Download & install", Icons.Rounded.Download, { vm.downloadUpdate(u.info) })
                is UpdateState.Ready ->
                    GradientButton("Install now", Icons.Rounded.Download, { vm.installUpdate() })
                is UpdateState.Downloading -> {}
                else ->
                    GradientButton("Check for updates", Icons.Rounded.SystemUpdate, { vm.checkUpdate(manual = true) })
            }
        }

        Section("TIPS") {
            Text(
                "• Drag from the page edge to curl it like a real book.\n" +
                    "• Tap the left or right edge to turn a page.\n" +
                    "• Tap the middle to show or hide the controls.\n" +
                    "• Reader remembers where you stopped in every book.",
                color = RC.Muted, fontSize = 14.sp, lineHeight = 22.sp
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}
