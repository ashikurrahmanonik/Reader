@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.BuildConfig
import com.reader.app.UpdateState
import com.reader.app.data.Storage

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp), 0.09f)
            .padding(18.dp)
    ) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RC.OrangeLight, letterSpacing = 1.sp)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedTrackColor = RC.Blue,
    checkedThumbColor = Color.White,
    uncheckedTrackColor = Color.White.copy(alpha = 0.15f),
    uncheckedThumbColor = RC.Muted,
    uncheckedBorderColor = Color.Transparent
)

@Composable
fun SettingsContent(vm: AppViewModel) {
    val ctx = LocalContext.current
    val t = LocalStr.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Section(t.secLanguage) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Language, null, tint = RC.BlueLight, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip("English", vm.lang == "en", { vm.changeLang("en") })
                    GlassChip("বাংলা", vm.lang == "bn", { vm.changeLang("bn") })
                }
            }
        }

        Section(t.secReading) {
            Text(t.readingTheme, fontSize = 14.sp, color = RC.Muted)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val names = listOf(t.day, t.sepia, t.night)
                val colors = listOf(Color.White, Color(0xFFF5E6B8), Color(0xFF111114))
                names.forEachIndexed { i, n ->
                    val sel = vm.readerTheme == i
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (sel) Color.White.copy(alpha = 0.14f) else Color.Transparent)
                            .clickable { vm.changeReaderTheme(i) }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(colors[i])
                                .border(2.dp, if (sel) RC.BlueLight else Color.White.copy(alpha = 0.3f), CircleShape)
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(n, fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.curlSwitch, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(t.curlSwitchHint, fontSize = 12.sp, color = RC.Muted)
                }
                Switch(checked = vm.curl, onCheckedChange = { vm.changeCurl(it) }, colors = switchColors())
            }
        }

        Section(t.secStorage) {
            val ok = Storage.hasAccess(ctx)
            Text(if (ok) t.accessOk else t.accessNo, color = RC.Muted, fontSize = 14.sp)
            if (!ok) {
                Spacer(Modifier.height(12.dp))
                GradientButton(t.allowAccess, Icons.Rounded.FolderOpen, { requestAllFilesAccess(ctx) })
            }
        }

        Section(t.secUpdates) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.SystemUpdate, null, tint = RC.BlueLight, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.versionLine(BuildConfig.VERSION_NAME), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(t.buildLine(BuildConfig.VERSION_CODE), color = RC.Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.checkAuto, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(checked = vm.autoUpdate, onCheckedChange = { vm.changeAutoUpdate(it) }, colors = switchColors())
            }
            Spacer(Modifier.height(12.dp))

            val u = vm.update
            val status = when (u) {
                is UpdateState.Idle -> ""
                is UpdateState.Checking -> t.checking
                is UpdateState.UpToDate -> t.upToDate
                is UpdateState.Available -> t.updateAvail(u.info.name)
                is UpdateState.Downloading -> t.downloadingPct((u.progress * 100).toInt())
                is UpdateState.Ready -> t.readyInstall
                is UpdateState.Failed -> u.message
            }
            if (status.isNotEmpty()) {
                Text(status, color = RC.Muted, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
            }
            if (u is UpdateState.Downloading) {
                LinearProgressIndicator(
                    progress = { u.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = RC.BlueLight,
                    trackColor = Color.White.copy(alpha = 0.15f)
                )
                Spacer(Modifier.height(10.dp))
            }
            when (u) {
                is UpdateState.Available ->
                    GradientButton(t.downloadInstall, Icons.Rounded.Download, { vm.downloadUpdate(u.info) })
                is UpdateState.Ready ->
                    GradientButton(t.installNow, Icons.Rounded.Download, { vm.installUpdate() })
                is UpdateState.Downloading -> {}
                else ->
                    GradientButton(t.checkUpdates, Icons.Rounded.SystemUpdate, { vm.checkUpdate(manual = true) })
            }
        }

        Section(t.secTips) {
            Text(t.tips, color = RC.Muted, fontSize = 14.sp, lineHeight = 22.sp)
        }
    }
}
