@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.FontStore
import com.reader.app.data.BOOK_EXT_REGEX
import com.reader.app.data.ReaderTarget
import com.reader.app.office.SheetData
import com.reader.app.office.XlStyle
import kotlinx.coroutines.Job
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private const val HEAD_BG = 0xFFEEF1F7.toInt()
private const val HEAD_TEXT = 0xFF46506A.toInt()
private const val GRID = 0xFFD6DBE4.toInt()
private const val ACCENT = 0xFF2F6BFF.toInt()

/** Pre-computed geometry + paints for one sheet at zoom 1 (1 Excel pixel = 1 dp). */
private class SheetLay(val sheet: SheetData, val density: Float, fontScale: Float) {
    val k = density
    val pxPerPt = 96f / 72f * density * fontScale
    val pad = 4f * density
    val colX = FloatArray(sheet.cols + 1)
    val rowY = FloatArray(sheet.rows.size + 1)
    val headerH = 24f * density
    val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * 96f / 72f * density
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        color = HEAD_TEXT
    }
    val line = Paint().apply { strokeWidth = max(1f, density * 0.6f) }
    val fill = Paint()
    val rowNumW: Float
    private val faces = HashMap<String, android.graphics.Typeface>()
    val mergeAt = HashMap<Long, IntArray>()
    val covered = HashSet<Long>()
    val defaultStyle = XlStyle(null, 11f, false, false, false, false, null, null, null, null, null, null, null, null, false)

    init {
        rowNumW = head.measureText((sheet.rows.size + 1).toString().padStart(3, '9')) + 14f * density
        for (c in 0 until sheet.cols) {
            val chars = sheet.colWidth?.getOrNull(c) ?: sheet.defaultColW
            colX[c + 1] = colX[c] + (if (chars <= 0f) 0f else (chars * 7f + 5f) * density)
        }
        for (r in sheet.rows.indices) {
            val h = sheet.rowHeight?.get(r) ?: sheet.defaultRowH
            rowY[r + 1] = rowY[r] + h * 96f / 72f * density
        }
        sheet.merges?.forEach { m ->
            if (m.size == 4) {
                mergeAt[key(m[0], m[1])] = m
                for (r in m[0]..min(m[2], sheet.rows.size - 1)) for (c in m[1]..min(m[3], sheet.cols - 1)) {
                    if (r != m[0] || c != m[1]) covered.add(key(r, c))
                }
            }
        }
    }

    fun key(r: Int, c: Int): Long = r.toLong() * 1000L + c

    fun face(s: XlStyle): android.graphics.Typeface =
        faces.getOrPut("${s.fontName}|${s.bold}|${s.italic}") { FontStore.face(s.fontName, s.bold, s.italic) }

    fun style(r: Int, c: Int): XlStyle {
        val idx = sheet.styleIdx?.getOrNull(r)?.getOrNull(c) ?: 0
        return sheet.styles?.getOrNull(idx) ?: defaultStyle
    }

    fun cell(r: Int, c: Int): String = sheet.rows.getOrNull(r)?.getOrNull(c) ?: ""

    val totalW: Float get() = colX[colX.size - 1]
    val totalH: Float get() = rowY[rowY.size - 1]

    /** index i with arr[i] <= x < arr[i+1] (clamped) */
    fun index(arr: FloatArray, x: Float): Int {
        var lo = 0
        var hi = arr.size - 2
        if (hi < 0) return 0
        while (lo < hi) {
            val mid = (lo + hi) / 2
            if (arr[mid + 1] <= x) lo = mid + 1 else hi = mid
        }
        return lo
    }
}

@Stable
private class SheetViewState : PanZoomTarget {
    override var z by mutableFloatStateOf(1f)
    override var ux by mutableFloatStateOf(0f)
    override var uy by mutableFloatStateOf(0f)
    override var fling: Job? = null
    var selR by mutableIntStateOf(-1)
    var selC by mutableIntStateOf(-1)
    var w = 0f
    var h = 0f
    var contentW = 0f
    var contentH = 0f

    override fun clamp() {
        val vw = w / z
        val vh = h / z
        ux = ux.coerceIn(0f, max(0f, contentW - vw))
        uy = uy.coerceIn(0f, max(0f, contentH - vh))
    }
}

private val tmpRect = RectF()

private fun drawCell(
    c: android.graphics.Canvas, lay: SheetLay, r: Int, col: Int,
    x: Float, y: Float, w: Float, h: Float, style: XlStyle, text: String, overflowW: Float
) {
    if (style.fill != null) {
        lay.fill.color = style.fill
        c.drawRect(x, y, x + w, y + h, lay.fill)
    }
    if (text.isNotEmpty()) {
        val tp = lay.text
        tp.typeface = lay.face(style)
        tp.textSize = max(4f, style.sizePt * lay.pxPerPt)
        tp.color = style.color ?: 0xFF000000.toInt()
        tp.isUnderlineText = style.underline
        tp.isStrikeThruText = style.strike
        val numeric = text.toDoubleOrNull() != null || (text.endsWith("%") && text.dropLast(1).replace(",", "").toDoubleOrNull() != null)
        val ha = style.halign ?: if (numeric) "right" else "left"
        val pad = lay.pad
        val fm = tp.fontMetrics
        c.save()
        if (style.wrap) {
            c.clipRect(x, y, x + w, y + h)
            val align = when (ha) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, max(4, (w - 2 * pad).toInt()))
                .setAlignment(align).setIncludePad(false).build()
            val free = h - layout.height
            val ty = when (style.valign) {
                "center" -> y + max(0f, free / 2f)
                "top" -> y + pad * 0.3f
                else -> y + max(0f, free - pad * 0.3f)
            }
            c.translate(x + pad, ty)
            layout.draw(c)
        } else {
            val tw = tp.measureText(text)
            val clipR = if (ha == "left" && tw > w - 2 * pad) x + overflowW else x + w
            c.clipRect(x, y, clipR, y + h)
            val textH = fm.descent - fm.ascent
            val base = when (style.valign) {
                "center" -> y + (h - textH) / 2f - fm.ascent
                "top" -> y + pad * 0.4f - fm.ascent
                else -> y + h - pad * 0.4f - fm.descent
            }
            val tx = when (ha) {
                "center" -> x + (w - tw) / 2f
                "right" -> x + w - pad - tw
                else -> x + pad
            }
            c.drawText(text, tx, base, tp)
        }
        c.restore()
    }
    // explicit borders
    fun edge(b: com.reader.app.office.XlBorder?, x1: Float, y1: Float, x2: Float, y2: Float) {
        if (b == null) return
        lay.line.color = b.color
        lay.line.strokeWidth = max(1f, b.w * lay.density * 0.8f)
        c.drawLine(x1, y1, x2, y2, lay.line)
    }
    edge(style.top, x, y, x + w, y)
    edge(style.bottom, x, y + h, x + w, y + h)
    edge(style.left, x, y, x, y + h)
    edge(style.right, x + w, y, x + w, y + h)
}

private fun drawSheet(
    c: android.graphics.Canvas, W: Float, H: Float, lay: SheetLay,
    z: Float, ux: Float, uy: Float, selR: Int, selC: Int
) {
    val sh = lay.sheet
    c.save()
    c.scale(z, z)
    val vw = W / z
    val vh = H / z
    val rn = lay.rowNumW
    val hh = lay.headerH
    val nR = sh.rows.size
    val nC = sh.cols
    val r0 = lay.index(lay.rowY, uy)
    var r1 = r0
    while (r1 < nR - 1 && lay.rowY[r1 + 1] < uy + vh - hh) r1++
    val c0 = lay.index(lay.colX, ux)
    var c1 = c0
    while (c1 < nC - 1 && lay.colX[c1 + 1] < ux + vw - rn) c1++

    // grid lines
    if (sh.showGrid && nR > 0) {
        lay.line.color = GRID
        lay.line.strokeWidth = max(1f, lay.density * 0.6f)
        for (r in r0..r1 + 1) {
            if (r > nR) break
            val y = hh + lay.rowY[r] - uy
            c.drawLine(rn, y, vw, y, lay.line)
        }
        for (cc in c0..c1 + 1) {
            if (cc > nC) break
            val x = rn + lay.colX[cc] - ux
            c.drawLine(x, hh, x, vh, lay.line)
        }
    }
    // cells
    if (nR > 0) for (r in r0..r1) {
        val y = hh + lay.rowY[r] - uy
        val h = lay.rowY[r + 1] - lay.rowY[r]
        if (h <= 0f) continue
        for (cc in c0..c1) {
            val k = lay.key(r, cc)
            if (lay.covered.contains(k) || lay.mergeAt.containsKey(k)) continue
            val w = lay.colX[cc + 1] - lay.colX[cc]
            if (w <= 0f) continue
            val x = rn + lay.colX[cc] - ux
            val st = lay.style(r, cc)
            val txt = lay.cell(r, cc)
            if (txt.isEmpty() && st.fill == null && st.left == null && st.right == null && st.top == null && st.bottom == null) continue
            // text may flow into empty neighbours to the right
            var over = w
            if (txt.isNotEmpty()) {
                var n = cc + 1
                while (n < nC && over < vw && lay.cell(r, n).isEmpty() && !lay.covered.contains(lay.key(r, n))) {
                    over += lay.colX[n + 1] - lay.colX[n]
                    n++
                }
            }
            drawCell(c, lay, r, cc, x, y, w, h, st, txt, over)
        }
    }
    // merged ranges that touch the viewport
    for (m in sh.merges ?: emptyList()) {
        if (m.size != 4 || m[0] >= nR || m[1] >= nC) continue
        val rr2 = min(m[2], nR - 1)
        val cc2 = min(m[3], nC - 1)
        if (rr2 < r0 || m[0] > r1 || cc2 < c0 || m[1] > c1) continue
        val x = rn + lay.colX[m[1]] - ux
        val y = hh + lay.rowY[m[0]] - uy
        val w = lay.colX[cc2 + 1] - lay.colX[m[1]]
        val h = lay.rowY[rr2 + 1] - lay.rowY[m[0]]
        drawCell(c, lay, m[0], m[1], x, y, w, h, lay.style(m[0], m[1]), lay.cell(m[0], m[1]), w)
    }
    // selection
    if (selR in 0 until nR && selC in 0 until nC) {
        val m = lay.mergeAt[lay.key(selR, selC)]
        val rr2 = if (m != null) min(m[2], nR - 1) else selR
        val cc2 = if (m != null) min(m[3], nC - 1) else selC
        val x = rn + lay.colX[selC] - ux
        val y = hh + lay.rowY[selR] - uy
        lay.line.color = ACCENT
        lay.line.style = Paint.Style.STROKE
        lay.line.strokeWidth = 2.5f
        c.drawRect(x, y, rn + lay.colX[cc2 + 1] - ux, hh + lay.rowY[rr2 + 1] - uy, lay.line)
        lay.line.style = Paint.Style.FILL
    }
    // sticky column letters
    lay.fill.color = HEAD_BG
    c.drawRect(0f, 0f, vw, hh, lay.fill)
    lay.line.color = GRID
    lay.line.strokeWidth = max(1f, lay.density * 0.6f)
    val hb = hh / 2f + lay.head.textSize * 0.35f
    for (cc in c0..c1) {
        val w = lay.colX[cc + 1] - lay.colX[cc]
        if (w <= 0f) continue
        val x = rn + lay.colX[cc] - ux
        c.save()
        c.clipRect(max(x, rn), 0f, x + w, hh)
        c.drawText(colName(cc), x + w / 2f, hb, lay.head)
        c.restore()
        c.drawLine(x + w, 0f, x + w, hh, lay.line)
    }
    // sticky row numbers
    lay.fill.color = HEAD_BG
    c.drawRect(0f, hh, rn, vh, lay.fill)
    if (nR > 0) for (r in r0..r1) {
        val h = lay.rowY[r + 1] - lay.rowY[r]
        if (h <= 0f) continue
        val y = hh + lay.rowY[r] - uy
        c.save()
        c.clipRect(0f, max(y, hh), rn, y + h)
        c.drawText((r + 1).toString(), rn / 2f, y + h / 2f + lay.head.textSize * 0.35f, lay.head)
        c.restore()
        c.drawLine(0f, y + h, rn, y + h, lay.line)
    }
    lay.fill.color = HEAD_BG
    c.drawRect(0f, 0f, rn, hh, lay.fill)
    c.drawLine(rn, 0f, rn, vh, lay.line)
    c.drawLine(0f, hh, vw, hh, lay.line)
    c.restore()
}

private fun colName(i: Int): String {
    var n = i
    val sb = StringBuilder()
    do {
        sb.insert(0, ('A' + n % 26))
        n = n / 26 - 1
    } while (n >= 0)
    return sb.toString()
}

@Composable
fun SheetViewer(vm: AppViewModel, target: ReaderTarget, sheets: List<SheetData>) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val density = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    var sheetIdx by rememberSaveable(target.path) { mutableIntStateOf(target.startPage.coerceIn(0, sheets.size - 1)) }
    val st = remember(target.path) { SheetViewState() }
    val theme = vm.readerTheme
    val sheet = sheets[sheetIdx.coerceIn(0, sheets.size - 1)]
    val lay = remember(sheet, density) { SheetLay(sheet, density, 1f) }
    val layerPaint = remember(theme) { if (theme == 0) null else themedBitmapPaint(theme) }
    val fav = target.path in vm.favorites

    st.contentW = lay.rowNumW + lay.totalW
    st.contentH = lay.headerH + lay.totalH

    LaunchedEffect(sheetIdx) {
        st.fling?.cancel()
        st.ux = 0f
        st.uy = 0f
        st.z = 1f
        st.selR = -1
        st.selC = -1
        vm.recordProgress(target.path, target.name, sheetIdx, sheets.size, -1L)
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged {
                st.w = it.width.toFloat()
                st.h = it.height.toFloat()
                st.clamp()
            }
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .panZoom(sheet, st, scope, 0.4f, 4f)
                .pointerInput(sheet) {
                    detectTapGestures(onTap = { off ->
                        val vx = st.ux + off.x / st.z - lay.rowNumW
                        val vy = st.uy + off.y / st.z - lay.headerH
                        if (vx >= 0f && vy >= 0f && sheet.rows.isNotEmpty()) {
                            val c = lay.index(lay.colX, vx)
                            val r = lay.index(lay.rowY, vy)
                            if (r in 0 until sheet.rows.size && c in 0 until sheet.cols) {
                                // inside a merged block -> select its top-left cell
                                var sr = r
                                var sc = c
                                for (m in sheet.merges ?: emptyList()) {
                                    if (m.size == 4 && r >= m[0] && r <= m[2] && c >= m[1] && c <= m[3]) {
                                        sr = m[0]
                                        sc = m[1]
                                        break
                                    }
                                }
                                st.selR = sr
                                st.selC = sc
                                return@detectTapGestures
                            }
                        }
                        st.selR = -1
                        st.selC = -1
                    })
                }
        ) {
            drawIntoCanvas { cv ->
                val c = cv.nativeCanvas
                if (layerPaint != null) {
                    val sc = c.saveLayer(0f, 0f, size.width, size.height, layerPaint)
                    c.drawColor(0xFFFFFFFF.toInt())
                    drawSheet(c, size.width, size.height, lay, st.z, st.ux, st.uy, st.selR, st.selC)
                    c.restoreToCount(sc)
                } else {
                    c.drawColor(0xFFFFFFFF.toInt())
                    drawSheet(c, size.width, size.height, lay, st.z, st.ux, st.uy, st.selR, st.selC)
                }
            }
        }

        // top bar
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                .padding(10.dp)
                .fillMaxWidth()
                .glass(RoundedCornerShape(24.dp), 0.18f)
                .background(RC.Navy900.copy(alpha = 0.86f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MiniIcon(Icons.AutoMirrored.Rounded.ArrowBack, t.back, Color.White) { vm.closeReader() }
            Spacer(Modifier.width(6.dp))
            Text(
                target.name.replace(BOOK_EXT_REGEX, ""),
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = Color.White
            )
            MiniIcon(Icons.Rounded.Palette, t.theme, RC.OrangeLight) { vm.cycleReaderTheme() }
            MiniIcon(
                if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                t.favorite,
                if (fav) RC.OrangeLight else Color.White
            ) { vm.toggleFavorite(target.path) }
            MiniIcon(Icons.Rounded.Share, t.share, Color.White) { shareBook(ctx, target.path) }
        }

        // bottom: selected cell + sheet tabs
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val sr = st.selR
            val sc = st.selC
            if (sr >= 0 && sc >= 0 && sr < sheet.rows.size) {
                val row = sheet.rows[sr]
                val value = if (sc < row.size) row[sc] else ""
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(18.dp), 0.18f)
                        .background(RC.Navy900.copy(alpha = 0.90f))
                        .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${colLetter(sc)}${sr + 1}",
                        color = RC.OrangeLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (value.isEmpty()) "—" else value,
                        modifier = Modifier.weight(1f),
                        color = Color.White,
                        fontSize = 14.sp,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                    MiniIcon(Icons.Rounded.Close, t.dismiss, RC.Muted) {
                        st.selR = -1
                        st.selC = -1
                    }
                }
            }
            if (sheets.size > 1) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(22.dp), 0.18f)
                        .background(RC.Navy900.copy(alpha = 0.86f))
                        .padding(8.dp)
                ) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(sheets) { i, s ->
                            GlassChip(s.name, i == sheetIdx, { sheetIdx = i })
                        }
                    }
                }
            }
        }
    }
}
