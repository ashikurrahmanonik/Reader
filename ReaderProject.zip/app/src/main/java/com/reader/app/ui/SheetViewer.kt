@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.reader.app.ui

import android.graphics.Paint
import android.text.TextPaint
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reader.app.AppViewModel
import com.reader.app.data.BOOK_EXT_REGEX
import com.reader.app.data.ReaderTarget
import com.reader.app.office.SheetData
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private class SheetColors(
    val bg: Int, val text: Int, val grid: Int, val headBg: Int, val headText: Int, val alt: Int, val accent: Int
)

private fun sheetColors(theme: Int): SheetColors = when (theme) {
    1 -> SheetColors(0xFFF5E6B8.toInt(), 0xFF3B2F1A.toInt(), 0xFFD9C791.toInt(), 0xFFE9D7A1.toInt(), 0xFF6B5A33.toInt(), 0xFFF0DFAE.toInt(), 0xFFB5651D.toInt())
    2 -> SheetColors(0xFF101319.toInt(), 0xFFE6E9EF.toInt(), 0xFF2A2F3A.toInt(), 0xFF1B2029.toInt(), 0xFF9AA3B5.toInt(), 0xFF141820.toInt(), 0xFF4DA3FF.toInt())
    else -> SheetColors(0xFFFFFFFF.toInt(), 0xFF1C1E24.toInt(), 0xFFD6DBE4.toInt(), 0xFFEEF1F7.toInt(), 0xFF46506A.toInt(), 0xFFF8F9FC.toInt(), 0xFF2F6BFF.toInt())
}

/** Pre-computed geometry of one sheet at zoom 1. */
private class SheetLay(sheet: SheetData, density: Float, textPx: Float) {
    val pad = 7f * density
    val rowH = textPx * 2.1f
    val headerH = rowH
    val rowNumW: Float
    val colW = FloatArray(sheet.cols)
    val colX = FloatArray(sheet.cols + 1)
    val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = textPx }
    val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = textPx
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    val line = Paint().apply { strokeWidth = max(1f, density * 0.7f) }
    val fill = Paint()

    init {
        rowNumW = text.measureText((sheet.rows.size + 1).toString().padStart(3, '9')) + pad * 2
        for (c in 0 until sheet.cols) {
            var mx = head.measureText(colLetter(c))
            val limit = min(sheet.rows.size, 200)
            for (r in 0 until limit) {
                val row = sheet.rows[r]
                if (c < row.size) mx = max(mx, text.measureText(row[c].take(50)))
            }
            colW[c] = (mx + pad * 2).coerceIn(56f * density, 260f * density)
        }
        for (c in 0 until sheet.cols) colX[c + 1] = colX[c] + colW[c]
    }

    val totalW: Float get() = colX[colX.size - 1]

    /** first column whose right edge is right of x */
    fun firstCol(x: Float): Int {
        var lo = 0
        var hi = colW.size - 1
        while (lo < hi) {
            val mid = (lo + hi) / 2
            if (colX[mid + 1] <= x) lo = mid + 1 else hi = mid
        }
        return lo
    }
}

private fun colLetter(i: Int): String {
    var n = i
    val sb = StringBuilder()
    do {
        sb.insert(0, ('A' + n % 26))
        n = n / 26 - 1
    } while (n >= 0)
    return sb.toString()
}

@Stable
private class SheetViewState {
    var z by mutableFloatStateOf(1f)
    var ux by mutableFloatStateOf(0f)
    var uy by mutableFloatStateOf(0f)
    var selR by mutableIntStateOf(-1)
    var selC by mutableIntStateOf(-1)
    var w = 0f
    var h = 0f
    var contentW = 0f
    var contentH = 0f
    var fling: Job? = null

    fun clamp() {
        val vw = w / z
        val vh = h / z
        ux = ux.coerceIn(0f, max(0f, contentW - vw))
        uy = uy.coerceIn(0f, max(0f, contentH - vh))
    }
}

private fun drawSheet(
    c: android.graphics.Canvas, W: Float, H: Float, sh: SheetData, lay: SheetLay,
    col: SheetColors, z: Float, ux: Float, uy: Float, selR: Int, selC: Int
) {
    c.drawColor(col.bg)
    c.save()
    c.scale(z, z)
    val vw = W / z
    val vh = H / z
    val rowH = lay.rowH
    val hh = lay.headerH
    val rn = lay.rowNumW
    val cols = sh.cols
    val r0 = max(0, floor(uy / rowH).toInt())
    val r1 = min(sh.rows.size - 1, ceil((uy + vh - hh) / rowH).toInt())
    val c0 = lay.firstCol(ux)
    val textBase = rowH / 2f + lay.text.textSize * 0.35f

    lay.text.color = col.text
    lay.line.color = col.grid
    for (r in r0..r1) {
        val y = hh + r * rowH - uy
        if (r % 2 == 1) {
            lay.fill.color = col.alt
            c.drawRect(rn, y, vw, y + rowH, lay.fill)
        }
        val row = sh.rows[r]
        var cc = c0
        while (cc < cols) {
            val x = rn + lay.colX[cc] - ux
            if (x > vw) break
            if (cc < row.size) {
                val cell = row[cc]
                if (cell.isNotEmpty()) {
                    val txt = if (cell.indexOf('\n') >= 0) cell.replace('\n', ' ') else cell
                    val numeric = cell.length < 24 && cell.toDoubleOrNull() != null
                    c.save()
                    c.clipRect(x, y, x + lay.colW[cc], y + rowH)
                    val tx = if (numeric) x + lay.colW[cc] - lay.pad - lay.text.measureText(txt) else x + lay.pad
                    c.drawText(txt, tx, y + textBase, lay.text)
                    c.restore()
                }
            }
            cc++
        }
        c.drawLine(rn, y + rowH, vw, y + rowH, lay.line)
    }
    // vertical grid lines
    var cc = c0
    while (cc <= cols) {
        val x = rn + lay.colX[cc] - ux
        if (x > vw) break
        c.drawLine(x, hh, x, vh, lay.line)
        cc++
    }
    // selection
    if (selR in 0 until sh.rows.size && selC in 0 until cols) {
        lay.line.color = col.accent
        lay.line.style = Paint.Style.STROKE
        lay.line.strokeWidth = 2.5f
        val x = rn + lay.colX[selC] - ux
        val y = hh + selR * rowH - uy
        c.drawRect(x, y, x + lay.colW[selC], y + rowH, lay.line)
        lay.line.style = Paint.Style.FILL
        lay.line.strokeWidth = max(1f, lay.pad * 0.1f)
    }
    // sticky column letters
    lay.fill.color = col.headBg
    c.drawRect(0f, 0f, vw, hh, lay.fill)
    lay.head.color = col.headText
    cc = c0
    while (cc < cols) {
        val x = rn + lay.colX[cc] - ux
        if (x > vw) break
        c.save()
        c.clipRect(max(x, rn), 0f, x + lay.colW[cc], hh)
        c.drawText(colLetter(cc), x + lay.colW[cc] / 2f, textBase, lay.head)
        c.restore()
        lay.line.color = col.grid
        c.drawLine(x + lay.colW[cc], 0f, x + lay.colW[cc], hh, lay.line)
        cc++
    }
    // sticky row numbers
    lay.fill.color = col.headBg
    c.drawRect(0f, hh, rn, vh, lay.fill)
    lay.head.color = col.headText
    for (r in r0..r1) {
        val y = hh + r * rowH - uy
        c.drawText((r + 1).toString(), rn / 2f, y + textBase, lay.head)
        lay.line.color = col.grid
        c.drawLine(0f, y + rowH, rn, y + rowH, lay.line)
    }
    // corner
    lay.fill.color = col.headBg
    c.drawRect(0f, 0f, rn, hh, lay.fill)
    lay.line.color = col.grid
    c.drawLine(rn, 0f, rn, vh, lay.line)
    c.drawLine(0f, hh, vw, hh, lay.line)
    c.restore()
}

@Composable
fun SheetViewer(vm: AppViewModel, target: ReaderTarget, sheets: List<SheetData>) {
    val ctx = LocalContext.current
    val t = LocalStr.current
    val density = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    var sheetIdx by rememberSaveable(target.path) { mutableIntStateOf(target.startPage.coerceIn(0, sheets.size - 1)) }
    val st = remember(target.path) { SheetViewState() }
    val theme = vm.readerTheme
    val colors = remember(theme) { sheetColors(theme) }
    val sheet = sheets[sheetIdx.coerceIn(0, sheets.size - 1)]
    val textPx = max(10f * density, vm.fontSize * 0.8f * density)
    val lay = remember(sheet, density, textPx) { SheetLay(sheet, density, textPx) }
    val fav = target.path in vm.favorites

    st.contentW = lay.rowNumW + lay.totalW
    st.contentH = lay.headerH + sheet.rows.size * lay.rowH

    LaunchedEffect(sheetIdx) {
        st.fling?.cancel()
        st.ux = 0f
        st.uy = 0f
        st.z = 1f
        st.selR = -1
        st.selC = -1
        vm.recordProgress(target.path, target.name, sheetIdx, sheets.size, -1L)
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged {
                st.w = it.width.toFloat()
                st.h = it.height.toFloat()
                st.clamp()
            }
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(sheet) {
                    detectTapGestures(onTap = { off ->
                        val ux = st.ux + off.x / st.z
                        val uy = st.uy + off.y / st.z
                        if (ux >= lay.rowNumW && uy >= lay.headerH) {
                            val c = lay.firstCol(ux - lay.rowNumW)
                            val r = floor((uy - lay.headerH) / lay.rowH).toInt()
                            if (r in 0 until sheet.rows.size && c in 0 until sheet.cols) {
                                st.selR = r
                                st.selC = c
                                return@detectTapGestures
                            }
                        }
                        st.selR = -1
                        st.selC = -1
                    })
                }
                .pointerInput(sheet) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        st.fling?.cancel()
                        val tracker = VelocityTracker()
                        val slop = viewConfiguration.touchSlop
                        var zoomAcc = 1f
                        var panAcc = Offset.Zero
                        var past = false
                        var multi = false
                        do {
                            val ev = awaitPointerEvent()
                            if (ev.changes.size > 1) multi = true
                            val zc = ev.calculateZoom()
                            val pc = ev.calculatePan()
                            val cen = ev.calculateCentroid(useCurrent = false)
                            if (!past) {
                                zoomAcc *= zc
                                panAcc += pc
                                val zoomMotion = abs(1f - zoomAcc) * ev.calculateCentroidSize(useCurrent = false)
                                if (zoomMotion > slop || panAcc.getDistance() > slop) past = true
                            }
                            if (past) {
                                if (zc != 1f || pc != Offset.Zero) {
                                    val oldZ = st.z
                                    val newZ = (oldZ * zc).coerceIn(0.4f, 4f)
                                    if (cen != Offset.Unspecified) {
                                        val px = st.ux + cen.x / oldZ
                                        val py = st.uy + cen.y / oldZ
                                        st.ux = px - cen.x / newZ
                                        st.uy = py - cen.y / newZ
                                    }
                                    st.z = newZ
                                    st.ux -= pc.x / newZ
                                    st.uy -= pc.y / newZ
                                    st.clamp()
                                }
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                                val first = ev.changes.firstOrNull { it.pressed }
                                if (first != null) tracker.addPosition(first.uptimeMillis, first.position)
                            }
                        } while (ev.changes.any { it.pressed })

                        if (past && !multi) {
                            val v = tracker.calculateVelocity()
                            st.fling = scope.launch {
                                launch {
                                    var last = 0f
                                    animateDecay(0f, -v.x, exponentialDecay()) { value, _ ->
                                        val d = value - last
                                        last = value
                                        st.ux += d / st.z
                                        st.clamp()
                                    }
                                }
                                launch {
                                    var last = 0f
                                    animateDecay(0f, -v.y, exponentialDecay()) { value, _ ->
                                        val d = value - last
                                        last = value
                                        st.uy += d / st.z
                                        st.clamp()
                                    }
                                }
                            }
                        }
                    }
                }
        ) {
            drawIntoCanvas { cv ->
                drawSheet(cv.nativeCanvas, size.width, size.height, sheet, lay, colors, st.z, st.ux, st.uy, st.selR, st.selC)
            }
        }

        // top bar
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                .padding(10.dp)
                .fillMaxWidth()
                .glass(RoundedCornerShape(24.dp), 0.18f)
                .background(RC.Navy900.copy(alpha = 0.86f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MiniIcon(Icons.AutoMirrored.Rounded.ArrowBack, t.back, Color.White) { vm.closeReader() }
            Spacer(Modifier.width(6.dp))
            Text(
                target.name.replace(BOOK_EXT_REGEX, ""),
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = Color.White
            )
            MiniIcon(Icons.Rounded.Palette, t.theme, RC.OrangeLight) { vm.cycleReaderTheme() }
            MiniIcon(
                if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                t.favorite,
                if (fav) RC.OrangeLight else Color.White
            ) { vm.toggleFavorite(target.path) }
            MiniIcon(Icons.Rounded.Share, t.share, Color.White) { shareBook(ctx, target.path) }
        }

        // bottom: selected cell + sheet tabs
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val sr = st.selR
            val sc = st.selC
            if (sr >= 0 && sc >= 0 && sr < sheet.rows.size) {
                val row = sheet.rows[sr]
                val value = if (sc < row.size) row[sc] else ""
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(18.dp), 0.18f)
                        .background(RC.Navy900.copy(alpha = 0.90f))
                        .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${colLetter(sc)}${sr + 1}",
                        color = RC.OrangeLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (value.isEmpty()) "—" else value,
                        modifier = Modifier.weight(1f),
                        color = Color.White,
                        fontSize = 14.sp,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                    MiniIcon(Icons.Rounded.Close, t.dismiss, RC.Muted) {
                        st.selR = -1
                        st.selC = -1
                    }
                }
            }
            if (sheets.size > 1) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(22.dp), 0.18f)
                        .background(RC.Navy900.copy(alpha = 0.86f))
                        .padding(8.dp)
                ) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(sheets) { i, s ->
                            GlassChip(s.name, i == sheetIdx, { sheetIdx = i })
                        }
                    }
                }
            }
        }
    }
}
