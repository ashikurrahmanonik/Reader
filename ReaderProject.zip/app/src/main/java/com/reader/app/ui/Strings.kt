package com.reader.app.ui

import androidx.compose.runtime.staticCompositionLocalOf

/** All user-visible text, in English and Bangla. */
class Str(val bn: Boolean) {
    private fun p(en: String, b: String) = if (bn) b else en

    /** Numbers in Bangla digits when the app language is Bangla. */
    fun n(x: Int): String {
        val s = x.toString()
        if (!bn) return s
        val sb = StringBuilder()
        for (c in s) sb.append(if (c in '0'..'9') '০' + (c - '0') else c)
        return sb.toString()
    }

    val tagline get() = p("Read beautifully", "সুন্দরভাবে পড়ুন")

    // navigation
    val library get() = p("Library", "লাইব্রেরি")
    val recent get() = p("Recent", "সাম্প্রতিক")
    val favorites get() = p("Favorites", "প্রিয়")
    val settings get() = p("Settings", "সেটিংস")

    // home
    val search get() = p("Search", "খুঁজুন")
    val searchHint get() = p("Search your books", "বই খুঁজুন")
    val clear get() = p("Clear", "মুছুন")
    val continueReading get() = p("CONTINUE READING", "পড়া চালিয়ে যান")
    val resume get() = p("Resume", "চালিয়ে যান")
    val newest get() = p("Newest", "নতুন")
    val name get() = p("Name", "নাম")
    val size get() = p("Size", "আকার")
    fun files(c: Int) = p("$c files", "${n(c)}টি ফাইল")
    val rescan get() = p("Rescan", "আবার স্ক্যান")
    val openFile get() = p("Open file", "ফাইল খুলুন")
    val permTitle get() = p("Find every book on your phone", "ফোনের সব বই খুঁজে নিন")
    val permBody get() = p(
        "Allow file access once and Reader will list all your PDF, EPUB, Word, Excel and PowerPoint files automatically. You can also use “Open file” to pick a single one.",
        "একবার ফাইল অ্যাক্সেস দিন, Reader আপনার সব PDF, EPUB, Word, Excel ও PowerPoint ফাইল নিজেই খুঁজে দেখাবে। চাইলে “ফাইল খুলুন” দিয়ে একটি ফাইলও বেছে নিতে পারেন।"
    )
    val allowAccess get() = p("Allow access", "অ্যাক্সেস দিন")
    val emptyScanning get() = p("Looking for books on your phone…", "ফোনে বই খোঁজা হচ্ছে…")
    val emptySearch get() = p("No books match your search", "কোনো বই মেলেনি")
    val emptyRecent get() = p("Books you read will show up here", "যে বই পড়বেন এখানে দেখা যাবে")
    val emptyFav get() = p("Tap the star on a book to keep it here", "বইয়ের তারা চাপুন, এখানে জমা থাকবে")
    val emptyLibrary get() = p("No books found yet", "এখনো কোনো বই পাওয়া যায়নি")
    val favorite get() = p("Favorite", "প্রিয়")
    val share get() = p("Share", "শেয়ার")
    val removeHistory get() = p("Remove from history", "ইতিহাস থেকে সরান")
    val back get() = p("Back", "পেছনে")
    fun pageOf(a: Int, b: Int) = p("Page $a of $b", "পৃষ্ঠা ${n(a)} / ${n(b)}")
    fun percent(v: Int) = p("$v%", "${n(v)}%")
    val langPill get() = p("বাং", "EN")

    // reader
    val contents get() = p("Contents", "সূচি")
    val display get() = p("Display", "ডিসপ্লে")
    val pageCurl get() = p("Page curl", "পেজ কার্ল")
    val theme get() = p("Theme", "থিম")
    val day get() = p("Day", "দিন")
    val sepia get() = p("Sepia", "সেপিয়া")
    val night get() = p("Night", "রাত")
    val brightness get() = p("Brightness", "উজ্জ্বলতা")
    val auto get() = p("Auto", "অটো")
    val pageTurn get() = p("Page turn", "পাতা উল্টানো")
    val curl get() = p("Curl", "কার্ল")
    val slide get() = p("Slide", "স্লাইড")
    val textSize get() = p("Text size", "লেখার আকার")
    val font get() = p("Font", "ফন্ট")
    val serif get() = p("Serif", "সেরিফ")
    val sans get() = p("Sans", "সান্স")
    val zoomHint get() = p("Pinch or double-tap to zoom", "জুম করতে দুই আঙুলে টিপুন বা ডাবল ট্যাপ করুন")
    val preparing get() = p("Preparing your book…", "বই সাজানো হচ্ছে…")
    fun section(i: Int) = p("Section $i", "অংশ ${n(i)}")
    val noContents get() = p("No contents in this book", "এই বইয়ে সূচি নেই")

    // password
    val pwTitle get() = p("Password required", "পাসওয়ার্ড লাগবে")
    val pwBody get() = p("This PDF is protected. Enter its password to open it.", "এই PDF সুরক্ষিত। খুলতে এর পাসওয়ার্ড দিন।")
    val pwHint get() = p("Password", "পাসওয়ার্ড")
    val pwWrong get() = p("Wrong password, please try again", "ভুল পাসওয়ার্ড, আবার চেষ্টা করুন")
    val openAction get() = p("Open", "খুলুন")
    val cancel get() = p("Cancel", "বাতিল")
    val show get() = p("Show", "দেখান")
    val hide get() = p("Hide", "লুকান")
    val unlocking get() = p("Unlocking…", "খোলা হচ্ছে…")

    // errors / toasts
    val errEmpty get() = p("This book has no pages", "এই বইয়ে কোনো পৃষ্ঠা নেই")
    val errOpen get() = p("Couldn't open this file", "ফাইলটি খোলা যায়নি")
    val toastNotFound get() = p("File not found", "ফাইল পাওয়া যায়নি")
    val toastCantOpen get() = p("Couldn't open that file", "ফাইলটি খোলা যায়নি")
    val toastAllowInstall get() = p("Allow installs from Reader, then tap Install again", "Reader-কে ইনস্টলের অনুমতি দিন, তারপর আবার Install চাপুন")
    val toastInstallFail get() = p("Couldn't start the installer", "ইনস্টলার চালু করা যায়নি")

    // settings
    val secLanguage get() = p("LANGUAGE", "ভাষা")
    val secReading get() = p("READING", "পড়া")
    val secStorage get() = p("FILE ACCESS", "ফাইল অ্যাক্সেস")
    val secUpdates get() = p("UPDATES", "আপডেট")
    val secTips get() = p("TIPS", "টিপস")
    val readingTheme get() = p("Reading theme", "পড়ার থিম")
    val curlSwitch get() = p("Page curl animation", "পেজ কার্ল অ্যানিমেশন")
    val curlSwitchHint get() = p("For PDFs and EPUB books. Off = simple slide", "PDF ও EPUB বইয়ের জন্য। বন্ধ করলে সাধারণ স্লাইড")
    val accessOk get() = p("Reader can see all books on your phone.", "Reader আপনার ফোনের সব বই দেখতে পারছে।")
    val accessNo get() = p("Access isn't granted yet, so only files you pick manually can be opened.", "এখনো অ্যাক্সেস দেওয়া হয়নি, তাই শুধু হাতে বাছা ফাইল খোলা যাবে।")
    val checkAuto get() = p("Check for updates automatically", "নিজে নিজে আপডেট খুঁজুন")
    val checkUpdates get() = p("Check for updates", "আপডেট খুঁজুন")
    val checking get() = p("Checking for updates…", "আপডেট খোঁজা হচ্ছে…")
    val upToDate get() = p("You're on the latest version.", "আপনি সর্বশেষ ভার্সনে আছেন।")
    fun updateAvail(v: String) = p("Version $v is available.", "ভার্সন $v পাওয়া যাচ্ছে।")
    fun downloadingPct(pct: Int) = p("Downloading… $pct%", "ডাউনলোড হচ্ছে… ${n(pct)}%")
    val readyInstall get() = p("Update downloaded and ready to install.", "আপডেট ডাউনলোড হয়েছে, ইনস্টলের জন্য তৈরি।")
    val downloadInstall get() = p("Download & install", "ডাউনলোড ও ইনস্টল")
    val installNow get() = p("Install now", "এখনই ইনস্টল করুন")
    fun versionLine(v: String) = p("Reader $v", "Reader $v")
    fun buildLine(c: Int) = p("Build $c", "বিল্ড ${n(c)}")
    val tips get() = p(
        "• In PDFs and books, drag from the page edge to curl it like a real book.\n• Word and PowerPoint files scroll like any document; Excel pans and pinch-zooms.\n" +
            "• Tap the left or right edge to turn a page.\n" +
            "• Tap the middle to show or hide the controls.\n" +
            "• Pinch or double-tap a page to zoom.\n" +
            "• Reader remembers where you stopped in every book.",
        "• PDF ও বইয়ে বইয়ের মতো পাতা ভাঁজ করতে পাতার কিনারা থেকে টানুন।\n• Word ও PowerPoint সাধারণ ডকুমেন্টের মতো স্ক্রল হয়; Excel টেনে ও পিঞ্চ করে দেখা যায়।\n" +
            "• পাতা উল্টাতে বাঁ বা ডান কিনারায় ট্যাপ করুন।\n" +
            "• কন্ট্রোল দেখাতে বা লুকাতে মাঝখানে ট্যাপ করুন।\n" +
            "• PDF জুম করতে দুই আঙুলে টিপুন বা ডাবল ট্যাপ করুন।\n" +
            "• প্রতিটি বইয়ের কোথায় থেমেছিলেন Reader মনে রাখে।"
    )

    // update dialog
    val updTitle get() = p("Update available", "আপডেট এসেছে")
    fun updBody(v: String) = p("Reader $v is ready. Your books and progress stay as they are.", "Reader $v তৈরি। আপনার বই ও পড়ার অগ্রগতি যেমন আছে তেমনই থাকবে।")
    val updNow get() = p("Update now", "এখনই আপডেট")
    val later get() = p("Later", "পরে")
    val downloadingTitle get() = p("Downloading update", "আপডেট ডাউনলোড হচ্ছে")
    val readyTitle get() = p("Ready to install", "ইনস্টলের জন্য তৈরি")
    val readyBody get() = p("Tap Install to update Reader in place.", "Reader আপডেট করতে Install চাপুন।")
    val install get() = p("Install", "ইনস্টল")
    val close get() = p("Close", "বন্ধ")
    val updFailed get() = p("Update failed", "আপডেট হয়নি")
    val ok get() = p("OK", "ঠিক আছে")
    // new in this version
    val filterAll get() = p("All", "সব")
    val filterPdf get() = "PDF"
    val filterEpub get() = "EPUB"
    val filterWord get() = p("Word", "ওয়ার্ড")
    val filterExcel get() = p("Excel", "এক্সেল")
    val filterPpt get() = p("Slides", "স্লাইড")
    val hideDup get() = p("Hide duplicate files", "একই ফাইলের কপি লুকান")
    val hideDupHint get() = p("Identical copies show up once", "হুবহু একই ফাইল একবারই দেখাবে")
    fun copies(c: Int) = p("+$c copy", "+${n(c)}টি কপি")
    val secFonts get() = p("FONTS", "ফন্ট")
    val fontsBody get() = p(
        "Add fonts such as SutonnyMJ, Nikosh or Kalpurush so Word files look exactly like on a computer. You can also copy font files into  Reader/Fonts  on your phone storage.",
        "SutonnyMJ, নিকস বা কালপুরুষের মতো ফন্ট যোগ করুন, যাতে Word ফাইল কম্পিউটারের মতোই দেখায়। চাইলে ফোনের স্টোরেজে  Reader/Fonts  ফোল্ডারে ফন্ট ফাইল রেখে দিতে পারেন।"
    )
    val addFonts get() = p("Add fonts", "ফন্ট যোগ করুন")
    val noFonts get() = p("No fonts added yet", "এখনো কোনো ফন্ট যোগ করা হয়নি")
    val deleteFont get() = p("Remove font", "ফন্ট সরান")
    fun fontsAdded(n: Int) = if (n > 0) p("$n font(s) added", "${this.n(n)}টি ফন্ট যোগ হয়েছে") else p("No font files found (use .ttf or .otf)", "কোনো ফন্ট ফাইল পাওয়া যায়নি (.ttf বা .otf দিন)")
    fun missingFonts(names: String) = p("Missing font: $names. Add it in Settings → Fonts to read this file correctly.", "ফন্ট নেই: $names। ঠিকভাবে পড়তে সেটিংস → ফন্ট থেকে যোগ করুন।")
    val dismiss get() = p("Dismiss", "বন্ধ করুন")
    val goFonts get() = p("Add", "যোগ করুন")
    val sheetHint get() = p("Wide sheets continue on the next pages", "চওড়া শিট পরের পৃষ্ঠায় চলতে থাকে")

    // file manager
    val tabFiles get() = p("Files", "ফাইল")
    val internalStorage get() = p("Internal storage", "ইন্টারনাল স্টোরেজ")
    val up get() = p("Up", "উপরে")
    val newFolder get() = p("New folder", "নতুন ফোল্ডার")
    val folderName get() = p("Folder name", "ফোল্ডারের নাম")
    val create get() = p("Create", "তৈরি করুন")
    val rename get() = p("Rename", "নাম বদলান")
    val newName get() = p("New name", "নতুন নাম")
    val delete get() = p("Delete", "মুছুন")
    val copy get() = p("Copy", "কপি")
    val move get() = p("Move", "সরান")
    val paste get() = p("Paste here", "এখানে বসান")
    val details get() = p("Details", "বিবরণ")
    val selectAll get() = p("Select all", "সব বাছুন")
    val showHidden get() = p("Show hidden files", "লুকানো ফাইল দেখান")
    val emptyFolder get() = p("This folder is empty", "ফোল্ডারটি খালি")
    val openWith get() = p("Open with…", "অন্য অ্যাপে খুলুন")
    val noAppToOpen get() = p("No app can open this file", "এই ফাইল খোলার মতো অ্যাপ নেই")
    fun selected(c: Int) = p("$c selected", "${n(c)}টি বাছা হয়েছে")
    fun items(c: Int) = p("$c items", "${n(c)}টি আইটেম")
    fun pasteInfo(c: Int, move: Boolean) = if (move) p("$c item(s) to move", "${n(c)}টি সরানো হবে") else p("$c item(s) to copy", "${n(c)}টি কপি হবে")
    fun deleteAsk(c: Int) = p("Delete $c item(s)? This cannot be undone.", "${n(c)}টি আইটেম মুছবেন? এটি আর ফেরানো যাবে না।")
    fun deleteOne(name: String) = p("Delete “$name”? This cannot be undone.", "“$name” মুছবেন? এটি আর ফেরানো যাবে না।")
    fun deleted(c: Int) = p("$c deleted", "${n(c)}টি মোছা হয়েছে")
    fun pasted(c: Int) = p("$c done", "${n(c)}টি সম্পন্ন")
    val renamed get() = p("Renamed", "নাম বদলানো হয়েছে")
    val errBadName get() = p("That name isn't allowed", "এই নামটি দেওয়া যাবে না")
    val errExists get() = p("A file with this name already exists", "এই নামে আগেই একটি ফাইল আছে")
    val errRenameFail get() = p("Couldn't rename it", "নাম বদলানো যায়নি")
    val errMkdirFail get() = p("Couldn't create the folder", "ফোল্ডার তৈরি করা যায়নি")
    val dName get() = p("Name", "নাম")
    val dPath get() = p("Location", "অবস্থান")
    val dType get() = p("Type", "ধরন")
    val dSize get() = p("Size", "আকার")
    val dModified get() = p("Modified", "পরিবর্তন")
    val dFolder get() = p("Folder", "ফোল্ডার")
    val dCalculating get() = p("Calculating…", "হিসাব হচ্ছে…")
    val permFilesBody get() = p("Allow file access to browse, rename and delete files.", "ফাইল দেখতে, নাম বদলাতে ও মুছতে ফাইল অ্যাক্সেস দিন।")
    val actions get() = p("Actions", "অ্যাকশন")
    val fitWidth get() = p("Fit width", "প্রস্থে ফিট করুন")
    // fonts folder
    val fontsFolderLine get() = p("Fonts folder:  Reader/Fonts  (internal storage)", "ফন্ট ফোল্ডার:  Reader/Fonts  (ইন্টারনাল স্টোরেজ)")
    val showFontsFolder get() = p("Show folder", "ফোল্ডার দেখান")
    val rescanFonts get() = p("Scan folder", "ফোল্ডার স্ক্যান")
    val fontsFolderNeedsAccess get() = p("Allow file access first, then the Reader/Fonts folder is created for you.", "আগে ফাইল অ্যাক্সেস দিন, তারপর Reader/Fonts ফোল্ডার নিজেই তৈরি হবে।")
}

val LocalStr = staticCompositionLocalOf { Str(false) }
