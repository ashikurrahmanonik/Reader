package com.reader.app.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

object RC {
    val Navy950 = Color(0xFF040918)
    val Navy900 = Color(0xFF071029)
    val Navy800 = Color(0xFF0C1B45)
    val Blue = Color(0xFF2F6BFF)
    val BlueLight = Color(0xFF4DA3FF)
    val Orange = Color(0xFFFF8A00)
    val OrangeLight = Color(0xFFFFB020)
    val Muted = Color(0xFFA9B6D6)
    val Danger = Color(0xFFE5484D)
}

@Composable
fun ReaderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = RC.Blue,
            onPrimary = Color.White,
            secondary = RC.Orange,
            background = RC.Navy900,
            surface = RC.Navy800,
            onSurface = Color.White,
            onBackground = Color.White
        )
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            content()
        }
    }
}
